/*
SQLyog Ultimate v12.14 (64 bit)
MySQL - 5.7.30 : Database - gulimall_sms
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`gulimall_sms` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `gulimall_sms`;

/*Table structure for table `sms_coupon` */

DROP TABLE IF EXISTS `sms_coupon`;

CREATE TABLE `sms_coupon` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `coupon_type` tinyint(1) DEFAULT NULL COMMENT '优惠卷类型[0->全场赠券；1->会员赠券；2->购物赠券；3->注册赠券]',
  `coupon_img` varchar(2000) DEFAULT NULL COMMENT '优惠券图片',
  `coupon_name` varchar(100) DEFAULT NULL COMMENT '优惠卷名字',
  `num` int(11) DEFAULT NULL COMMENT '数量',
  `amount` decimal(18,4) DEFAULT NULL COMMENT '金额',
  `per_limit` int(11) DEFAULT NULL COMMENT '每人限领张数',
  `min_point` decimal(18,4) DEFAULT NULL COMMENT '使用门槛',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `use_type` tinyint(1) DEFAULT NULL COMMENT '使用类型[0->全场通用；1->指定分类；2->指定商品]',
  `note` varchar(200) DEFAULT NULL COMMENT '备注',
  `publish_count` int(11) DEFAULT NULL COMMENT '发行数量',
  `use_count` int(11) DEFAULT NULL COMMENT '已使用数量',
  `receive_count` int(11) DEFAULT NULL COMMENT '领取数量',
  `enable_start_time` datetime DEFAULT NULL COMMENT '可以领取的开始日期',
  `enable_end_time` datetime DEFAULT NULL COMMENT '可以领取的结束日期',
  `code` varchar(64) DEFAULT NULL COMMENT '优惠码',
  `member_level` tinyint(1) DEFAULT NULL COMMENT '可以领取的会员等级[0->不限等级，其他-对应等级]',
  `publish` tinyint(1) DEFAULT NULL COMMENT '发布状态[0-未发布，1-已发布]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='优惠券信息';

/*Data for the table `sms_coupon` */

/*Table structure for table `sms_coupon_history` */

DROP TABLE IF EXISTS `sms_coupon_history`;

CREATE TABLE `sms_coupon_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `coupon_id` bigint(20) DEFAULT NULL COMMENT '优惠券id',
  `member_id` bigint(20) DEFAULT NULL COMMENT '会员id',
  `member_nick_name` varchar(64) DEFAULT NULL COMMENT '会员名字',
  `get_type` tinyint(1) DEFAULT NULL COMMENT '获取方式[0->后台赠送；1->主动领取]',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `use_type` tinyint(1) DEFAULT NULL COMMENT '使用状态[0->未使用；1->已使用；2->已过期]',
  `use_time` datetime DEFAULT NULL COMMENT '使用时间',
  `order_id` bigint(20) DEFAULT NULL COMMENT '订单id',
  `order_sn` bigint(20) DEFAULT NULL COMMENT '订单号',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='优惠券领取历史记录';

/*Data for the table `sms_coupon_history` */

/*Table structure for table `sms_coupon_spu_category_relation` */

DROP TABLE IF EXISTS `sms_coupon_spu_category_relation`;

CREATE TABLE `sms_coupon_spu_category_relation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `coupon_id` bigint(20) DEFAULT NULL COMMENT '优惠券id',
  `category_id` bigint(20) DEFAULT NULL COMMENT '产品分类id',
  `category_name` varchar(64) DEFAULT NULL COMMENT '产品分类名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='优惠券分类关联';

/*Data for the table `sms_coupon_spu_category_relation` */

/*Table structure for table `sms_coupon_spu_relation` */

DROP TABLE IF EXISTS `sms_coupon_spu_relation`;

CREATE TABLE `sms_coupon_spu_relation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `coupon_id` bigint(20) DEFAULT NULL COMMENT '优惠券id',
  `spu_id` bigint(20) DEFAULT NULL COMMENT 'spu_id',
  `spu_name` varchar(255) DEFAULT NULL COMMENT 'spu_name',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='优惠券与产品关联';

/*Data for the table `sms_coupon_spu_relation` */

/*Table structure for table `sms_home_adv` */

DROP TABLE IF EXISTS `sms_home_adv`;

CREATE TABLE `sms_home_adv` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(100) DEFAULT NULL COMMENT '名字',
  `pic` varchar(500) DEFAULT NULL COMMENT '图片地址',
  `start_time` datetime DEFAULT NULL COMMENT '开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '结束时间',
  `status` tinyint(1) DEFAULT NULL COMMENT '状态',
  `click_count` int(11) DEFAULT NULL COMMENT '点击数',
  `url` varchar(500) DEFAULT NULL COMMENT '广告详情连接地址',
  `note` varchar(500) DEFAULT NULL COMMENT '备注',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  `publisher_id` bigint(20) DEFAULT NULL COMMENT '发布者',
  `auth_id` bigint(20) DEFAULT NULL COMMENT '审核者',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='首页轮播广告';

/*Data for the table `sms_home_adv` */

/*Table structure for table `sms_home_subject` */

DROP TABLE IF EXISTS `sms_home_subject`;

CREATE TABLE `sms_home_subject` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(200) DEFAULT NULL COMMENT '专题名字',
  `title` varchar(255) DEFAULT NULL COMMENT '专题标题',
  `sub_title` varchar(255) DEFAULT NULL COMMENT '专题副标题',
  `status` tinyint(1) DEFAULT NULL COMMENT '显示状态',
  `url` varchar(500) DEFAULT NULL COMMENT '详情连接',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  `img` varchar(500) DEFAULT NULL COMMENT '专题图片地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='首页专题表【jd首页下面很多专题，每个专题链接新的页面，展示专题商品信息】';

/*Data for the table `sms_home_subject` */

/*Table structure for table `sms_home_subject_spu` */

DROP TABLE IF EXISTS `sms_home_subject_spu`;

CREATE TABLE `sms_home_subject_spu` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(200) DEFAULT NULL COMMENT '专题名字',
  `subject_id` bigint(20) DEFAULT NULL COMMENT '专题id',
  `spu_id` bigint(20) DEFAULT NULL COMMENT 'spu_id',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='专题商品';

/*Data for the table `sms_home_subject_spu` */

/*Table structure for table `sms_member_price` */

DROP TABLE IF EXISTS `sms_member_price`;

CREATE TABLE `sms_member_price` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sku_id` bigint(20) DEFAULT NULL COMMENT 'sku_id',
  `member_level_id` bigint(20) DEFAULT NULL COMMENT '会员等级id',
  `member_level_name` varchar(100) DEFAULT NULL COMMENT '会员等级名',
  `member_price` decimal(18,4) DEFAULT NULL COMMENT '会员对应价格',
  `add_other` tinyint(1) DEFAULT NULL COMMENT '可否叠加其他优惠[0-不可叠加优惠，1-可叠加]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=198 DEFAULT CHARSET=utf8mb4 COMMENT='商品会员价格';

/*Data for the table `sms_member_price` */

insert  into `sms_member_price`(`id`,`sku_id`,`member_level_id`,`member_level_name`,`member_price`,`add_other`) values 
(101,71,2,'铜牌会员','4999.0000',1),
(102,71,3,'银牌会员','4990.0000',1),
(103,71,4,'黄金会员','4900.0000',1),
(104,72,2,'铜牌会员','5999.0000',1),
(105,73,2,'铜牌会员','4999.0000',1),
(106,73,4,'黄金会员','4900.0000',1),
(107,74,2,'铜牌会员','5999.0000',1),
(108,74,3,'银牌会员','5990.0000',1),
(109,74,4,'黄金会员','5900.0000',1),
(110,75,2,'铜牌会员','4999.0000',1),
(111,75,3,'银牌会员','4900.0000',1),
(112,76,2,'铜牌会员','5999.0000',1),
(113,76,4,'黄金会员','5900.0000',1),
(114,77,2,'铜牌会员','4999.0000',1),
(115,77,3,'银牌会员','4990.0000',1),
(116,77,4,'黄金会员','4900.0000',1),
(117,78,2,'铜牌会员','5999.0000',1),
(118,78,3,'银牌会员','5990.0000',1),
(119,79,2,'铜牌会员','5000.0000',1),
(120,79,3,'银牌会员','4900.0000',1),
(121,79,4,'黄金会员','4800.0000',1),
(122,80,2,'铜牌会员','4000.0000',1),
(123,80,3,'银牌会员','3900.0000',1),
(124,80,4,'黄金会员','3800.0000',1),
(125,81,2,'铜牌会员','5000.0000',1),
(126,81,4,'黄金会员','4800.0000',1),
(127,83,2,'铜牌会员','5000.0000',1),
(128,89,2,'铜牌会员','5000.0000',1),
(129,89,3,'银牌会员','4599.0000',1),
(130,89,4,'黄金会员','4099.0000',1),
(131,90,2,'铜牌会员','6000.0000',1),
(132,90,3,'银牌会员','5599.0000',1),
(133,90,4,'黄金会员','5099.0000',1),
(134,91,2,'铜牌会员','5000.0000',1),
(135,91,3,'银牌会员','4599.0000',1),
(136,91,4,'黄金会员','4099.0000',1),
(137,92,4,'黄金会员','5099.0000',1),
(138,93,2,'铜牌会员','3399.0000',1),
(139,93,3,'银牌会员','3299.0000',1),
(140,93,4,'黄金会员','3199.0000',1),
(141,94,2,'铜牌会员','3699.0000',1),
(142,94,3,'银牌会员','3599.0000',1),
(143,94,4,'黄金会员','3499.0000',1),
(144,95,2,'铜牌会员','3399.0000',1),
(145,95,3,'银牌会员','3299.0000',1),
(146,95,4,'黄金会员','3199.0000',1),
(147,96,2,'铜牌会员','3699.0000',1),
(148,96,3,'银牌会员','3599.0000',1),
(149,96,4,'黄金会员','3499.0000',1),
(150,97,2,'铜牌会员','5999.0000',1),
(151,97,3,'银牌会员','5899.0000',1),
(152,97,4,'黄金会员','5799.0000',1),
(153,98,2,'铜牌会员','5999.0000',1),
(154,98,3,'银牌会员','5899.0000',1),
(155,98,4,'黄金会员','5799.0000',1),
(156,99,2,'铜牌会员','5999.0000',1),
(157,99,3,'银牌会员','5899.0000',1),
(158,99,4,'黄金会员','5799.0000',1),
(159,100,2,'铜牌会员','3599.0000',1),
(160,100,3,'银牌会员','3599.0000',1),
(161,100,4,'黄金会员','3599.0000',1),
(162,101,2,'铜牌会员','3199.0000',1),
(163,101,3,'银牌会员','3199.0000',1),
(164,101,4,'黄金会员','3199.0000',1),
(165,102,2,'铜牌会员','2899.0000',1),
(166,102,3,'银牌会员','2899.0000',1),
(167,102,4,'黄金会员','2899.0000',1),
(168,103,2,'铜牌会员','3599.0000',1),
(169,103,3,'银牌会员','3599.0000',1),
(170,103,4,'黄金会员','3599.0000',1),
(171,104,2,'铜牌会员','3199.0000',1),
(172,104,3,'银牌会员','3199.0000',1),
(173,104,4,'黄金会员','3199.0000',1),
(174,105,2,'铜牌会员','2899.0000',1),
(175,105,3,'银牌会员','2899.0000',1),
(176,105,4,'黄金会员','2899.0000',1),
(177,107,2,'铜牌会员','249.0000',1),
(178,107,3,'银牌会员','249.0000',1),
(179,107,4,'黄金会员','249.0000',1),
(180,108,2,'铜牌会员','269.0000',1),
(181,110,2,'铜牌会员','269.0000',1),
(182,111,2,'铜牌会员','249.0000',1),
(183,112,2,'铜牌会员','269.0000',1),
(184,113,2,'铜牌会员','4999.0000',1),
(185,113,3,'银牌会员','4899.0000',1),
(186,113,4,'黄金会员','4799.0000',1),
(187,114,2,'铜牌会员','4499.0000',1),
(188,115,2,'铜牌会员','4999.0000',1),
(189,115,3,'银牌会员','4999.0000',1),
(190,115,4,'黄金会员','4999.0000',1),
(191,116,2,'铜牌会员','4499.0000',1),
(192,116,3,'银牌会员','4499.0000',1),
(193,116,4,'黄金会员','4499.0000',1),
(194,117,2,'铜牌会员','4999.0000',1),
(195,117,3,'银牌会员','4999.0000',1),
(196,117,4,'黄金会员','4999.0000',1),
(197,118,2,'铜牌会员','4499.0000',1);

/*Table structure for table `sms_seckill_promotion` */

DROP TABLE IF EXISTS `sms_seckill_promotion`;

CREATE TABLE `sms_seckill_promotion` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `title` varchar(255) DEFAULT NULL COMMENT '活动标题',
  `start_time` datetime DEFAULT NULL COMMENT '开始日期',
  `end_time` datetime DEFAULT NULL COMMENT '结束日期',
  `status` tinyint(4) DEFAULT NULL COMMENT '上下线状态',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `user_id` bigint(20) DEFAULT NULL COMMENT '创建人',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='秒杀活动';

/*Data for the table `sms_seckill_promotion` */

/*Table structure for table `sms_seckill_session` */

DROP TABLE IF EXISTS `sms_seckill_session`;

CREATE TABLE `sms_seckill_session` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(200) DEFAULT NULL COMMENT '场次名称',
  `start_time` datetime DEFAULT NULL COMMENT '每日开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '每日结束时间',
  `status` tinyint(1) DEFAULT NULL COMMENT '启用状态',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COMMENT='秒杀活动场次';

/*Data for the table `sms_seckill_session` */

insert  into `sms_seckill_session`(`id`,`name`,`start_time`,`end_time`,`status`,`create_time`) values 
(6,'23:00','2020-11-07 12:00:00','2020-11-07 23:59:59',1,'2020-11-06 21:24:17'),
(7,'20:00','2020-11-07 20:00:00','2020-11-07 23:00:00',1,'2020-11-06 21:25:10');

/*Table structure for table `sms_seckill_sku_notice` */

DROP TABLE IF EXISTS `sms_seckill_sku_notice`;

CREATE TABLE `sms_seckill_sku_notice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `member_id` bigint(20) DEFAULT NULL COMMENT 'member_id',
  `sku_id` bigint(20) DEFAULT NULL COMMENT 'sku_id',
  `session_id` bigint(20) DEFAULT NULL COMMENT '活动场次id',
  `subcribe_time` datetime DEFAULT NULL COMMENT '订阅时间',
  `send_time` datetime DEFAULT NULL COMMENT '发送时间',
  `notice_type` tinyint(1) DEFAULT NULL COMMENT '通知方式[0-短信，1-邮件]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='秒杀商品通知订阅';

/*Data for the table `sms_seckill_sku_notice` */

/*Table structure for table `sms_seckill_sku_relation` */

DROP TABLE IF EXISTS `sms_seckill_sku_relation`;

CREATE TABLE `sms_seckill_sku_relation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `promotion_id` bigint(20) DEFAULT NULL COMMENT '活动id',
  `promotion_session_id` bigint(20) DEFAULT NULL COMMENT '活动场次id',
  `sku_id` bigint(20) DEFAULT NULL COMMENT '商品id',
  `seckill_price` decimal(10,2) DEFAULT NULL COMMENT '秒杀价格',
  `seckill_count` decimal(10,0) DEFAULT NULL COMMENT '秒杀总量',
  `seckill_limit` decimal(10,0) DEFAULT NULL COMMENT '每人限购数量',
  `seckill_sort` int(11) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COMMENT='秒杀活动商品关联';

/*Data for the table `sms_seckill_sku_relation` */

insert  into `sms_seckill_sku_relation`(`id`,`promotion_id`,`promotion_session_id`,`sku_id`,`seckill_price`,`seckill_count`,`seckill_limit`,`seckill_sort`) values 
(9,NULL,6,81,'0.99','10','1',1),
(10,NULL,6,71,'1.00','5','1',1),
(11,NULL,7,113,'0.10','9','1',1),
(12,NULL,7,114,'1.90','7','10',1);

/*Table structure for table `sms_sku_full_reduction` */

DROP TABLE IF EXISTS `sms_sku_full_reduction`;

CREATE TABLE `sms_sku_full_reduction` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sku_id` bigint(20) DEFAULT NULL COMMENT 'spu_id',
  `full_price` decimal(18,4) DEFAULT NULL COMMENT '满多少',
  `reduce_price` decimal(18,4) DEFAULT NULL COMMENT '减多少',
  `add_other` tinyint(1) DEFAULT NULL COMMENT '是否参与其他优惠',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COMMENT='商品满减信息';

/*Data for the table `sms_sku_full_reduction` */

insert  into `sms_sku_full_reduction`(`id`,`sku_id`,`full_price`,`reduce_price`,`add_other`) values 
(44,71,'10000.0000','1000.0000',NULL),
(45,72,'2345.0000','111.0000',NULL),
(46,73,'10000.0000','1111.0000',NULL),
(47,74,'15000.0000','1000.0000',NULL),
(48,77,'10000.0000','2333.0000',NULL),
(49,79,'10000.0000','100.0000',NULL),
(50,81,'10000.0000','100.0000',NULL),
(51,89,'10000.0000','100.0000',NULL),
(52,90,'10000.0000','1000.0000',NULL),
(53,91,'10000.0000','100.0000',NULL),
(54,92,'10000.0000','1000.0000',NULL),
(55,93,'20000.0000','1000.0000',NULL),
(56,94,'25000.0000','1000.0000',NULL),
(57,95,'20000.0000','1000.0000',NULL),
(58,96,'25000.0000','1000.0000',NULL),
(59,97,'20000.0000','1001.0000',NULL),
(60,98,'20000.0000','1001.0000',NULL),
(61,99,'20000.0000','1001.0000',NULL),
(62,113,'20900.0000','900.0000',NULL);

/*Table structure for table `sms_sku_ladder` */

DROP TABLE IF EXISTS `sms_sku_ladder`;

CREATE TABLE `sms_sku_ladder` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sku_id` bigint(20) DEFAULT NULL COMMENT 'spu_id',
  `full_count` int(11) DEFAULT NULL COMMENT '满几件',
  `discount` decimal(4,2) DEFAULT NULL COMMENT '打几折',
  `price` decimal(18,4) DEFAULT NULL COMMENT '折后价',
  `add_other` tinyint(1) DEFAULT NULL COMMENT '是否叠加其他优惠[0-不可叠加，1-可叠加]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COMMENT='商品阶梯价格';

/*Data for the table `sms_sku_ladder` */

insert  into `sms_sku_ladder`(`id`,`sku_id`,`full_count`,`discount`,`price`,`add_other`) values 
(50,71,10,'0.90',NULL,NULL),
(51,73,10,'0.00',NULL,NULL),
(52,74,10,'0.90',NULL,NULL),
(53,76,10,'0.90',NULL,NULL),
(54,77,120,'0.10',NULL,NULL),
(55,78,12000,'0.01',NULL,NULL),
(56,79,3,'0.90',NULL,NULL),
(57,81,3,'0.90',NULL,NULL),
(58,83,3,'0.90',NULL,NULL),
(59,90,10,'0.98',NULL,NULL),
(60,91,10,'0.98',NULL,NULL),
(61,92,10,'0.98',NULL,NULL),
(62,93,10,'0.90',NULL,NULL),
(63,94,15,'0.90',NULL,NULL),
(64,95,10,'0.90',NULL,NULL),
(65,96,15,'0.90',NULL,NULL),
(66,97,3,'0.98',NULL,NULL),
(67,98,3,'0.98',NULL,NULL),
(68,99,3,'0.98',NULL,NULL),
(69,113,10,'0.98',NULL,NULL);

/*Table structure for table `sms_spu_bounds` */

DROP TABLE IF EXISTS `sms_spu_bounds`;

CREATE TABLE `sms_spu_bounds` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `spu_id` bigint(20) DEFAULT NULL,
  `grow_bounds` decimal(18,4) DEFAULT NULL COMMENT '成长积分',
  `buy_bounds` decimal(18,4) DEFAULT NULL COMMENT '购物积分',
  `work` tinyint(1) DEFAULT NULL COMMENT '优惠生效情况[1111（四个状态位，从右到左）;0 - 无优惠，成长积分是否赠送;1 - 无优惠，购物积分是否赠送;2 - 有优惠，成长积分是否赠送;3 - 有优惠，购物积分是否赠送【状态位0：不赠送，1：赠送】]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COMMENT='商品spu积分设置';

/*Data for the table `sms_spu_bounds` */

insert  into `sms_spu_bounds`(`id`,`spu_id`,`grow_bounds`,`buy_bounds`,`work`) values 
(12,15,'550.0000','340.0000',NULL),
(13,16,'330.0000','300.0000',NULL),
(14,17,'400.0000','300.0000',NULL),
(15,18,'350.0000','300.0000',NULL),
(16,19,'124.0000','123.0000',NULL),
(17,20,'122.0000','234.0000',NULL),
(18,21,'1.0000','1.0000',NULL),
(19,22,'300.0000','700.0000',NULL),
(20,23,'288.0000','600.0000',NULL),
(21,24,'188.0000','600.0000',NULL),
(22,25,'289.0000','500.0000',NULL),
(23,26,'20.0000','100.0000',NULL),
(24,27,'117.0000','489.0000',NULL);

/*Table structure for table `undo_log` */

DROP TABLE IF EXISTS `undo_log`;

CREATE TABLE `undo_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `branch_id` bigint(20) NOT NULL,
  `xid` varchar(100) NOT NULL,
  `context` varchar(128) NOT NULL,
  `rollback_info` longblob NOT NULL,
  `log_status` int(11) NOT NULL,
  `log_created` datetime NOT NULL,
  `log_modified` datetime NOT NULL,
  `ext` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_undo_log` (`xid`,`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `undo_log` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
