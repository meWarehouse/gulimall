/*
SQLyog Ultimate v12.14 (64 bit)
MySQL - 5.7.30 : Database - gulimall_oms
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`gulimall_oms` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `gulimall_oms`;

/*Table structure for table `group_capacity` */

DROP TABLE IF EXISTS `group_capacity`;

CREATE TABLE `group_capacity` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `group_id` varchar(128) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT 'Group ID，空字符表示整个集群',
  `quota` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '配额，0表示使用默认值',
  `usage` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '使用量',
  `max_size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '单个配置大小上限，单位为字节，0表示使用默认值',
  `max_aggr_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '聚合子配置最大个数，，0表示使用默认值',
  `max_aggr_size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '单个聚合数据的子配置大小上限，单位为字节，0表示使用默认值',
  `max_history_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最大变更历史数量',
  `gmt_create` datetime NOT NULL DEFAULT '2010-05-05 00:00:00' COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT '2010-05-05 00:00:00' COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='集群、各Group容量信息表';

/*Data for the table `group_capacity` */

/*Table structure for table `his_config_info` */

DROP TABLE IF EXISTS `his_config_info`;

CREATE TABLE `his_config_info` (
  `id` bigint(64) unsigned NOT NULL,
  `nid` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `data_id` varchar(255) COLLATE utf8_bin NOT NULL,
  `group_id` varchar(128) COLLATE utf8_bin NOT NULL,
  `app_name` varchar(128) COLLATE utf8_bin DEFAULT NULL COMMENT 'app_name',
  `content` longtext COLLATE utf8_bin NOT NULL,
  `md5` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `gmt_create` datetime NOT NULL DEFAULT '2010-05-05 00:00:00',
  `gmt_modified` datetime NOT NULL DEFAULT '2010-05-05 00:00:00',
  `src_user` text COLLATE utf8_bin,
  `src_ip` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `op_type` char(10) COLLATE utf8_bin DEFAULT NULL,
  `tenant_id` varchar(128) COLLATE utf8_bin DEFAULT '' COMMENT '租户字段',
  PRIMARY KEY (`nid`),
  KEY `idx_gmt_create` (`gmt_create`),
  KEY `idx_gmt_modified` (`gmt_modified`),
  KEY `idx_did` (`data_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='多租户改造';

/*Data for the table `his_config_info` */

/*Table structure for table `oms_order` */

DROP TABLE IF EXISTS `oms_order`;

CREATE TABLE `oms_order` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `member_id` bigint(20) DEFAULT NULL COMMENT 'member_id',
  `order_sn` char(64) DEFAULT NULL COMMENT '订单号',
  `coupon_id` bigint(20) unsigned DEFAULT NULL COMMENT '使用的优惠券',
  `create_time` datetime DEFAULT NULL COMMENT 'create_time',
  `member_username` varchar(200) DEFAULT NULL COMMENT '用户名',
  `total_amount` decimal(18,4) DEFAULT NULL COMMENT '订单总额',
  `pay_amount` decimal(18,4) DEFAULT NULL COMMENT '应付总额',
  `freight_amount` decimal(18,4) DEFAULT NULL COMMENT '运费金额',
  `promotion_amount` decimal(18,4) DEFAULT NULL COMMENT '促销优化金额（促销价、满减、阶梯价）',
  `integration_amount` decimal(18,4) DEFAULT NULL COMMENT '积分抵扣金额',
  `coupon_amount` decimal(18,4) DEFAULT NULL COMMENT '优惠券抵扣金额',
  `discount_amount` decimal(18,4) DEFAULT NULL COMMENT '后台调整订单使用的折扣金额',
  `pay_type` tinyint(4) DEFAULT NULL COMMENT '支付方式【1->支付宝；2->微信；3->银联； 4->货到付款；】',
  `source_type` tinyint(4) DEFAULT NULL COMMENT '订单来源[0->PC订单；1->app订单]',
  `status` tinyint(4) DEFAULT NULL COMMENT '订单状态【0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单】',
  `delivery_company` varchar(64) DEFAULT NULL COMMENT '物流公司(配送方式)',
  `delivery_sn` varchar(64) DEFAULT NULL COMMENT '物流单号',
  `auto_confirm_day` int(11) DEFAULT NULL COMMENT '自动确认时间（天）',
  `integration` int(11) DEFAULT NULL COMMENT '可以获得的积分',
  `growth` int(11) DEFAULT NULL COMMENT '可以获得的成长值',
  `bill_type` tinyint(4) DEFAULT NULL COMMENT '发票类型[0->不开发票；1->电子发票；2->纸质发票]',
  `bill_header` varchar(255) DEFAULT NULL COMMENT '发票抬头',
  `bill_content` varchar(255) DEFAULT NULL COMMENT '发票内容',
  `bill_receiver_phone` varchar(32) DEFAULT NULL COMMENT '收票人电话',
  `bill_receiver_email` varchar(64) DEFAULT NULL COMMENT '收票人邮箱',
  `receiver_name` varchar(100) DEFAULT NULL COMMENT '收货人姓名',
  `receiver_phone` varchar(32) DEFAULT NULL COMMENT '收货人电话',
  `receiver_post_code` varchar(32) DEFAULT NULL COMMENT '收货人邮编',
  `receiver_province` varchar(32) DEFAULT NULL COMMENT '省份/直辖市',
  `receiver_city` varchar(32) DEFAULT NULL COMMENT '城市',
  `receiver_region` varchar(32) DEFAULT NULL COMMENT '区',
  `receiver_detail_address` varchar(200) DEFAULT NULL COMMENT '详细地址',
  `note` varchar(500) DEFAULT NULL COMMENT '订单备注',
  `confirm_status` tinyint(4) DEFAULT NULL COMMENT '确认收货状态[0->未确认；1->已确认]',
  `delete_status` tinyint(4) DEFAULT NULL COMMENT '删除状态【0->未删除；1->已删除】',
  `use_integration` int(11) DEFAULT NULL COMMENT '下单时使用的积分',
  `payment_time` datetime DEFAULT NULL COMMENT '支付时间',
  `delivery_time` datetime DEFAULT NULL COMMENT '发货时间',
  `receive_time` datetime DEFAULT NULL COMMENT '确认收货时间',
  `comment_time` datetime DEFAULT NULL COMMENT '评价时间',
  `modify_time` datetime DEFAULT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_sn` (`order_sn`)
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8mb4 COMMENT='订单';

/*Data for the table `oms_order` */

insert  into `oms_order`(`id`,`member_id`,`order_sn`,`coupon_id`,`create_time`,`member_username`,`total_amount`,`pay_amount`,`freight_amount`,`promotion_amount`,`integration_amount`,`coupon_amount`,`discount_amount`,`pay_type`,`source_type`,`status`,`delivery_company`,`delivery_sn`,`auto_confirm_day`,`integration`,`growth`,`bill_type`,`bill_header`,`bill_content`,`bill_receiver_phone`,`bill_receiver_email`,`receiver_name`,`receiver_phone`,`receiver_post_code`,`receiver_province`,`receiver_city`,`receiver_region`,`receiver_detail_address`,`note`,`confirm_status`,`delete_status`,`use_integration`,`payment_time`,`delivery_time`,`receive_time`,`comment_time`,`modify_time`) values 
(168,8,'1323865825799196672',NULL,'2020-11-04 13:53:04',NULL,'14998.0000','15002.0000','4.0000','0.0000','0.0000','0.0000',NULL,NULL,NULL,4,NULL,NULL,7,18,13,NULL,NULL,NULL,NULL,NULL,'意义','12345678904','000002','北京','北京',NULL,'北京市中关村1001号',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(169,8,'1323884842681257984',NULL,'2020-11-04 15:08:38',NULL,'14998.0000','15007.0000','9.0000','0.0000','0.0000','0.0000',NULL,NULL,NULL,4,NULL,NULL,7,18,13,NULL,NULL,NULL,NULL,NULL,'意义','12345678909','000001','上海','上海',NULL,'上海浦东国贸大厦一楼330',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(170,8,'1323884943965310976',NULL,'2020-11-04 15:09:02',NULL,'14998.0000','15002.0000','4.0000','0.0000','0.0000','0.0000',NULL,NULL,NULL,4,NULL,NULL,7,18,13,NULL,NULL,NULL,NULL,NULL,'意义','12345678904','000002','北京','北京',NULL,'北京市中关村1001号',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(171,8,'1323885333217693696',NULL,'2020-11-04 15:10:35',NULL,'5000.0000','5009.0000','9.0000','0.0000','0.0000','0.0000',NULL,NULL,NULL,4,NULL,NULL,7,0,5,NULL,NULL,NULL,NULL,NULL,'意义','12345678909','000001','上海','上海',NULL,'上海浦东国贸大厦一楼330',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(172,8,'1323886791988236288',NULL,'2020-11-04 15:16:22',NULL,'9998.0000','10007.0000','9.0000','0.0000','0.0000','0.0000',NULL,NULL,NULL,1,NULL,NULL,7,18,8,NULL,NULL,NULL,NULL,NULL,'意义','12345678909','000001','上海','上海',NULL,'上海浦东国贸大厦一楼330',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(173,8,'1324333633465110528',NULL,'2020-11-05 20:55:38',NULL,NULL,'1.0000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(174,8,'1324333633213452288',NULL,'2020-11-05 20:55:38',NULL,NULL,'1.0000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(175,8,'1324365849461149696',NULL,'2020-11-05 22:59:59',NULL,NULL,'1.9000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(176,8,'1324367991311847424',NULL,'2020-11-05 23:08:31',NULL,NULL,'1.0000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(177,8,'1324368269981405184',NULL,'2020-11-05 23:09:54',NULL,NULL,'1.0000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(178,8,'1324369671436783616',NULL,'2020-11-05 23:15:11',NULL,NULL,'1.0000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(179,8,'1324369921610240000',NULL,'2020-11-05 23:16:10',NULL,NULL,'0.9900',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(180,8,'1324370277568237568',NULL,'2020-11-05 23:17:34',NULL,NULL,'1.0000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(181,8,'1324370818625064960',NULL,'2020-11-05 23:19:43',NULL,NULL,'0.9900',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(182,8,'1324371040352751616',NULL,'2020-11-05 23:20:36',NULL,NULL,'0.9900',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(183,8,'1324371127292284928',NULL,'2020-11-05 23:20:57',NULL,NULL,'1.0000',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(184,8,'1324696969880948736',NULL,'2020-11-06 20:55:44',NULL,'4999.0000','5003.0000','4.0000','0.0000','0.0000','0.0000',NULL,NULL,NULL,1,NULL,NULL,7,9,4,NULL,NULL,NULL,NULL,NULL,'意义','12345678904','000002','北京','北京',NULL,'北京市中关村1001号',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(185,8,'1324736182903001088',NULL,'2020-11-06 23:31:33',NULL,NULL,'0.9900',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(187,8,'202011072153181691325073845765382146',NULL,NULL,NULL,'9998.0000','10002.0000','4.0000','0.0000','0.0000','0.0000','0.0000',NULL,NULL,4,NULL,NULL,7,999,666,NULL,NULL,NULL,NULL,NULL,'意义','12345678904','000002','北京','北京',NULL,'北京市中关村1001号',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(190,8,'202011072154147061325074082890358786',NULL,NULL,NULL,'5000.0000','5004.0000','4.0000','0.0000','0.0000','0.0000','0.0000',NULL,NULL,4,NULL,NULL,7,500,333,NULL,NULL,NULL,NULL,NULL,'意义','12345678904','000002','北京','北京',NULL,'北京市中关村1001号',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL),
(191,8,'202011072158362041325075179713343489',NULL,NULL,NULL,'5000.0000','5004.0000','4.0000','0.0000','0.0000','0.0000','0.0000',NULL,NULL,4,NULL,NULL,7,500,333,NULL,NULL,NULL,NULL,NULL,'意义','12345678904','000002','北京','北京',NULL,'北京市中关村1001号',NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL);

/*Table structure for table `oms_order_item` */

DROP TABLE IF EXISTS `oms_order_item`;

CREATE TABLE `oms_order_item` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `order_id` bigint(20) DEFAULT NULL COMMENT 'order_id',
  `order_sn` char(64) DEFAULT NULL COMMENT 'order_sn',
  `spu_id` bigint(20) DEFAULT NULL COMMENT 'spu_id',
  `spu_name` varchar(255) DEFAULT NULL COMMENT 'spu_name',
  `spu_pic` varchar(500) DEFAULT NULL COMMENT 'spu_pic',
  `spu_brand` varchar(200) DEFAULT NULL COMMENT '品牌',
  `category_id` bigint(20) DEFAULT NULL COMMENT '商品分类id',
  `sku_id` bigint(20) DEFAULT NULL COMMENT '商品sku编号',
  `sku_name` varchar(255) DEFAULT NULL COMMENT '商品sku名字',
  `sku_pic` varchar(500) DEFAULT NULL COMMENT '商品sku图片',
  `sku_price` decimal(18,4) DEFAULT NULL COMMENT '商品sku价格',
  `sku_quantity` int(11) DEFAULT NULL COMMENT '商品购买的数量',
  `sku_attrs_vals` varchar(500) DEFAULT NULL COMMENT '商品销售属性组合（JSON）',
  `promotion_amount` decimal(18,4) DEFAULT NULL COMMENT '商品促销分解金额',
  `coupon_amount` decimal(18,4) DEFAULT NULL COMMENT '优惠券优惠分解金额',
  `integration_amount` decimal(18,4) DEFAULT NULL COMMENT '积分优惠分解金额',
  `real_amount` decimal(18,4) DEFAULT NULL COMMENT '该商品经过优惠后的分解金额',
  `gift_integration` int(11) DEFAULT NULL COMMENT '赠送积分',
  `gift_growth` int(11) DEFAULT NULL COMMENT '赠送成长值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=302 DEFAULT CHARSET=utf8mb4 COMMENT='订单项信息';

/*Data for the table `oms_order_item` */

insert  into `oms_order_item`(`id`,`order_id`,`order_sn`,`spu_id`,`spu_name`,`spu_pic`,`spu_brand`,`category_id`,`sku_id`,`sku_name`,`sku_pic`,`sku_price`,`sku_quantity`,`sku_attrs_vals`,`promotion_amount`,`coupon_amount`,`integration_amount`,`real_amount`,`gift_integration`,`gift_growth`) values 
(286,168,'1323865825799196672',20,'小米10pro ',NULL,'5',225,89,'小米10pro  珍珠白 12G+128G 双模5G游戏手机【12期分期0首付可选】','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//f3cceea3-a36f-45f2-89c4-b69b52fe9952_u=2489139277,1741824967&fm=179&app=42&f=JPEG.jpg','5000.0000',1,'颜色;珍珠白;型号;12G+128G','0.0000','0.0000','0.0000','5000.0000',0,5),
(287,168,'1323865825799196672',15,'华为 HUAWEI Mate 30 ',NULL,'8',225,71,'华为 HUAWEI Mate 30   翡冷翠 8+128 5G 麒麟990 4000万超感光徕卡影像双超级快充','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//b405e70f-b21c-48f1-81f0-e58fd401a4ac_a83bf5250e14caf2.jpg','4999.0000',2,'颜色; 翡冷翠;型号;8+128','0.0000','0.0000','0.0000','4999.0000',9,4),
(288,169,'1323884842681257984',20,'小米10pro ',NULL,'5',225,89,'小米10pro  珍珠白 12G+128G 双模5G游戏手机【12期分期0首付可选】','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//f3cceea3-a36f-45f2-89c4-b69b52fe9952_u=2489139277,1741824967&fm=179&app=42&f=JPEG.jpg','5000.0000',1,'颜色;珍珠白;型号;12G+128G','0.0000','0.0000','0.0000','5000.0000',0,5),
(289,169,'1323884842681257984',15,'华为 HUAWEI Mate 30 ',NULL,'8',225,71,'华为 HUAWEI Mate 30   翡冷翠 8+128 5G 麒麟990 4000万超感光徕卡影像双超级快充','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//b405e70f-b21c-48f1-81f0-e58fd401a4ac_a83bf5250e14caf2.jpg','4999.0000',2,'颜色; 翡冷翠;型号;8+128','0.0000','0.0000','0.0000','4999.0000',9,4),
(290,170,'1323884943965310976',20,'小米10pro ',NULL,'5',225,89,'小米10pro  珍珠白 12G+128G 双模5G游戏手机【12期分期0首付可选】','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//f3cceea3-a36f-45f2-89c4-b69b52fe9952_u=2489139277,1741824967&fm=179&app=42&f=JPEG.jpg','5000.0000',1,'颜色;珍珠白;型号;12G+128G','0.0000','0.0000','0.0000','5000.0000',0,5),
(291,170,'1323884943965310976',15,'华为 HUAWEI Mate 30 ',NULL,'8',225,71,'华为 HUAWEI Mate 30   翡冷翠 8+128 5G 麒麟990 4000万超感光徕卡影像双超级快充','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//b405e70f-b21c-48f1-81f0-e58fd401a4ac_a83bf5250e14caf2.jpg','4999.0000',2,'颜色; 翡冷翠;型号;8+128','0.0000','0.0000','0.0000','4999.0000',9,4),
(292,171,'1323885333217693696',20,'小米10pro ',NULL,'5',225,89,'小米10pro  珍珠白 12G+128G 双模5G游戏手机【12期分期0首付可选】','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//f3cceea3-a36f-45f2-89c4-b69b52fe9952_u=2489139277,1741824967&fm=179&app=42&f=JPEG.jpg','5000.0000',1,'颜色;珍珠白;型号;12G+128G','0.0000','0.0000','0.0000','5000.0000',0,5),
(293,172,'1323886791988236288',15,'华为 HUAWEI Mate 30 ',NULL,'8',225,71,'华为 HUAWEI Mate 30   翡冷翠 8+128 5G 麒麟990 4000万超感光徕卡影像双超级快充','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//b405e70f-b21c-48f1-81f0-e58fd401a4ac_a83bf5250e14caf2.jpg','4999.0000',2,'颜色; 翡冷翠;型号;8+128','0.0000','0.0000','0.0000','4999.0000',9,4),
(294,184,'1324696969880948736',15,'华为 HUAWEI Mate 30 ',NULL,'8',225,71,'华为 HUAWEI Mate 30   翡冷翠 8+128 5G 麒麟990 4000万超感光徕卡影像双超级快充','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//b405e70f-b21c-48f1-81f0-e58fd401a4ac_a83bf5250e14caf2.jpg','4999.0000',1,'颜色; 翡冷翠;型号;8+128','0.0000','0.0000','0.0000','4999.0000',9,4),
(297,187,'202011072153181691325073845765382146',15,'华为 HUAWEI Mate 30 ',NULL,'8',225,71,'华为 HUAWEI Mate 30   翡冷翠 8+128 5G 麒麟990 4000万超感光徕卡影像双超级快充','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//b405e70f-b21c-48f1-81f0-e58fd401a4ac_a83bf5250e14caf2.jpg','4999.0000',2,'颜色: 翡冷翠;型号:8+128','0.0000','0.0000','0.0000','4999.0000',999,666),
(300,190,'202011072154147061325074082890358786',20,'小米10pro ',NULL,'5',225,89,'小米10pro  珍珠白 12G+128G 双模5G游戏手机【12期分期0首付可选】','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//f3cceea3-a36f-45f2-89c4-b69b52fe9952_u=2489139277,1741824967&fm=179&app=42&f=JPEG.jpg','5000.0000',1,'颜色:珍珠白;型号:12G+128G','0.0000','0.0000','0.0000','5000.0000',500,333),
(301,191,'202011072158362041325075179713343489',20,'小米10pro ',NULL,'5',225,89,'小米10pro  珍珠白 12G+128G 双模5G游戏手机【12期分期0首付可选】','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//f3cceea3-a36f-45f2-89c4-b69b52fe9952_u=2489139277,1741824967&fm=179&app=42&f=JPEG.jpg','5000.0000',1,'颜色:珍珠白;型号:12G+128G','0.0000','0.0000','0.0000','5000.0000',500,333);

/*Table structure for table `oms_order_operate_history` */

DROP TABLE IF EXISTS `oms_order_operate_history`;

CREATE TABLE `oms_order_operate_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `order_id` bigint(20) DEFAULT NULL COMMENT '订单id',
  `operate_man` varchar(100) DEFAULT NULL COMMENT '操作人[用户；系统；后台管理员]',
  `create_time` datetime DEFAULT NULL COMMENT '操作时间',
  `order_status` tinyint(4) DEFAULT NULL COMMENT '订单状态【0->待付款；1->待发货；2->已发货；3->已完成；4->已关闭；5->无效订单】',
  `note` varchar(500) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单操作历史记录';

/*Data for the table `oms_order_operate_history` */

/*Table structure for table `oms_order_return_apply` */

DROP TABLE IF EXISTS `oms_order_return_apply`;

CREATE TABLE `oms_order_return_apply` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `order_id` bigint(20) DEFAULT NULL COMMENT 'order_id',
  `sku_id` bigint(20) DEFAULT NULL COMMENT '退货商品id',
  `order_sn` char(32) DEFAULT NULL COMMENT '订单编号',
  `create_time` datetime DEFAULT NULL COMMENT '申请时间',
  `member_username` varchar(64) DEFAULT NULL COMMENT '会员用户名',
  `return_amount` decimal(18,4) DEFAULT NULL COMMENT '退款金额',
  `return_name` varchar(100) DEFAULT NULL COMMENT '退货人姓名',
  `return_phone` varchar(20) DEFAULT NULL COMMENT '退货人电话',
  `status` tinyint(1) DEFAULT NULL COMMENT '申请状态[0->待处理；1->退货中；2->已完成；3->已拒绝]',
  `handle_time` datetime DEFAULT NULL COMMENT '处理时间',
  `sku_img` varchar(500) DEFAULT NULL COMMENT '商品图片',
  `sku_name` varchar(200) DEFAULT NULL COMMENT '商品名称',
  `sku_brand` varchar(200) DEFAULT NULL COMMENT '商品品牌',
  `sku_attrs_vals` varchar(500) DEFAULT NULL COMMENT '商品销售属性(JSON)',
  `sku_count` int(11) DEFAULT NULL COMMENT '退货数量',
  `sku_price` decimal(18,4) DEFAULT NULL COMMENT '商品单价',
  `sku_real_price` decimal(18,4) DEFAULT NULL COMMENT '商品实际支付单价',
  `reason` varchar(200) DEFAULT NULL COMMENT '原因',
  `description述` varchar(500) DEFAULT NULL COMMENT '描述',
  `desc_pics` varchar(2000) DEFAULT NULL COMMENT '凭证图片，以逗号隔开',
  `handle_note` varchar(500) DEFAULT NULL COMMENT '处理备注',
  `handle_man` varchar(200) DEFAULT NULL COMMENT '处理人员',
  `receive_man` varchar(100) DEFAULT NULL COMMENT '收货人',
  `receive_time` datetime DEFAULT NULL COMMENT '收货时间',
  `receive_note` varchar(500) DEFAULT NULL COMMENT '收货备注',
  `receive_phone` varchar(20) DEFAULT NULL COMMENT '收货电话',
  `company_address` varchar(500) DEFAULT NULL COMMENT '公司收货地址',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单退货申请';

/*Data for the table `oms_order_return_apply` */

/*Table structure for table `oms_order_return_reason` */

DROP TABLE IF EXISTS `oms_order_return_reason`;

CREATE TABLE `oms_order_return_reason` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `name` varchar(200) DEFAULT NULL COMMENT '退货原因名',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  `status` tinyint(1) DEFAULT NULL COMMENT '启用状态',
  `create_time` datetime DEFAULT NULL COMMENT 'create_time',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='退货原因';

/*Data for the table `oms_order_return_reason` */

/*Table structure for table `oms_order_setting` */

DROP TABLE IF EXISTS `oms_order_setting`;

CREATE TABLE `oms_order_setting` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `flash_order_overtime` int(11) DEFAULT NULL COMMENT '秒杀订单超时关闭时间(分)',
  `normal_order_overtime` int(11) DEFAULT NULL COMMENT '正常订单超时时间(分)',
  `confirm_overtime` int(11) DEFAULT NULL COMMENT '发货后自动确认收货时间（天）',
  `finish_overtime` int(11) DEFAULT NULL COMMENT '自动完成交易时间，不能申请退货（天）',
  `comment_overtime` int(11) DEFAULT NULL COMMENT '订单完成后自动好评时间（天）',
  `member_level` tinyint(2) DEFAULT NULL COMMENT '会员等级【0-不限会员等级，全部通用；其他-对应的其他会员等级】',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='订单配置信息';

/*Data for the table `oms_order_setting` */

/*Table structure for table `oms_payment_info` */

DROP TABLE IF EXISTS `oms_payment_info`;

CREATE TABLE `oms_payment_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `order_sn` char(64) DEFAULT NULL COMMENT '订单号（对外业务号）',
  `order_id` bigint(20) DEFAULT NULL COMMENT '订单id',
  `alipay_trade_no` varchar(50) DEFAULT NULL COMMENT '支付宝交易流水号',
  `total_amount` decimal(18,4) DEFAULT NULL COMMENT '支付总金额',
  `subject` varchar(200) DEFAULT NULL COMMENT '交易内容',
  `payment_status` varchar(20) DEFAULT NULL COMMENT '支付状态',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `confirm_time` datetime DEFAULT NULL COMMENT '确认时间',
  `callback_content` varchar(4000) DEFAULT NULL COMMENT '回调内容',
  `callback_time` datetime DEFAULT NULL COMMENT '回调时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `order_sn` (`order_sn`),
  UNIQUE KEY `alipay_trade_no` (`alipay_trade_no`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COMMENT='支付信息表';

/*Data for the table `oms_payment_info` */

insert  into `oms_payment_info`(`id`,`order_sn`,`order_id`,`alipay_trade_no`,`total_amount`,`subject`,`payment_status`,`create_time`,`confirm_time`,`callback_content`,`callback_time`) values 
(1,'202010131430064351315902615321604098',NULL,'2020101322001403620501437683','10009.0000',NULL,'TRADE_SUCCESS',NULL,NULL,NULL,NULL),
(2,'202010131436471311315904295949856769',NULL,'2020101322001403620501438653','10009.0000',NULL,'TRADE_SUCCESS',NULL,NULL,NULL,NULL),
(3,'202010161426305881316988873603063809',NULL,'2020101622001403620501441297','999.0000',NULL,'TRADE_SUCCESS',NULL,NULL,NULL,NULL),
(4,'1323886791988236288',NULL,'2020110422001403620501453054','10007.0000',NULL,'TRADE_SUCCESS',NULL,NULL,NULL,NULL),
(5,'1324696969880948736',NULL,'2020110622001403620501453781','5003.0000',NULL,'TRADE_SUCCESS',NULL,NULL,NULL,NULL);

/*Table structure for table `oms_refund_info` */

DROP TABLE IF EXISTS `oms_refund_info`;

CREATE TABLE `oms_refund_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `order_return_id` bigint(20) DEFAULT NULL COMMENT '退款的订单',
  `refund` decimal(18,4) DEFAULT NULL COMMENT '退款金额',
  `refund_sn` varchar(64) DEFAULT NULL COMMENT '退款交易流水号',
  `refund_status` tinyint(1) DEFAULT NULL COMMENT '退款状态',
  `refund_channel` tinyint(4) DEFAULT NULL COMMENT '退款渠道[1-支付宝，2-微信，3-银联，4-汇款]',
  `refund_content` varchar(5000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='退款信息';

/*Data for the table `oms_refund_info` */

/*Table structure for table `roles` */

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `username` varchar(50) NOT NULL,
  `role` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `roles` */

insert  into `roles`(`username`,`role`) values 
('nacos','ROLE_ADMIN');

/*Table structure for table `tenant_capacity` */

DROP TABLE IF EXISTS `tenant_capacity`;

CREATE TABLE `tenant_capacity` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `tenant_id` varchar(128) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT 'Tenant ID',
  `quota` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '配额，0表示使用默认值',
  `usage` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '使用量',
  `max_size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '单个配置大小上限，单位为字节，0表示使用默认值',
  `max_aggr_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '聚合子配置最大个数',
  `max_aggr_size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '单个聚合数据的子配置大小上限，单位为字节，0表示使用默认值',
  `max_history_count` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最大变更历史数量',
  `gmt_create` datetime NOT NULL DEFAULT '2010-05-05 00:00:00' COMMENT '创建时间',
  `gmt_modified` datetime NOT NULL DEFAULT '2010-05-05 00:00:00' COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='租户容量信息表';

/*Data for the table `tenant_capacity` */

/*Table structure for table `tenant_info` */

DROP TABLE IF EXISTS `tenant_info`;

CREATE TABLE `tenant_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `kp` varchar(128) COLLATE utf8_bin NOT NULL COMMENT 'kp',
  `tenant_id` varchar(128) COLLATE utf8_bin DEFAULT '' COMMENT 'tenant_id',
  `tenant_name` varchar(128) COLLATE utf8_bin DEFAULT '' COMMENT 'tenant_name',
  `tenant_desc` varchar(256) COLLATE utf8_bin DEFAULT NULL COMMENT 'tenant_desc',
  `create_source` varchar(32) COLLATE utf8_bin DEFAULT NULL COMMENT 'create_source',
  `gmt_create` bigint(20) NOT NULL COMMENT '创建时间',
  `gmt_modified` bigint(20) NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_info_kptenantid` (`kp`,`tenant_id`),
  KEY `idx_tenant_id` (`tenant_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='tenant_info';

/*Data for the table `tenant_info` */

/*Table structure for table `undo_log` */

DROP TABLE IF EXISTS `undo_log`;

CREATE TABLE `undo_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `branch_id` bigint(20) NOT NULL,
  `xid` varchar(100) NOT NULL,
  `context` varchar(128) NOT NULL,
  `rollback_info` longblob NOT NULL,
  `log_status` int(11) NOT NULL,
  `log_created` datetime NOT NULL,
  `log_modified` datetime NOT NULL,
  `ext` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_undo_log` (`xid`,`branch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

/*Data for the table `undo_log` */

insert  into `undo_log`(`id`,`branch_id`,`xid`,`context`,`rollback_info`,`log_status`,`log_created`,`log_modified`,`ext`) values 
(5,66637052476657665,'192.168.44.1:8091:66637048919887872','serializer=jackson','{}',1,'2020-11-02 13:11:54','2020-11-02 13:11:54',NULL),
(6,66637051658768384,'192.168.44.1:8091:66637048919887872','serializer=jackson','{}',1,'2020-11-02 13:11:54','2020-11-02 13:11:54',NULL),
(11,66638505014464513,'192.168.44.1:8091:66638447934181376','serializer=jackson','{}',1,'2020-11-02 13:19:19','2020-11-02 13:19:19',NULL),
(12,66638502372052993,'192.168.44.1:8091:66638447934181376','serializer=jackson','{}',1,'2020-11-02 13:19:19','2020-11-02 13:19:19',NULL);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `username` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `users` */

insert  into `users`(`username`,`password`,`enabled`) values 
('nacos','$2a$10$EuWPZHzz32dJN7jexM34MOeYirDdFAZm2kuWj7VEOJhhZkDrxfvUu',1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
