/*
SQLyog Ultimate v12.14 (64 bit)
MySQL - 5.7.30 : Database - gulimall_pms
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`gulimall_pms` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `gulimall_pms`;

/*Table structure for table `pms_attr` */

DROP TABLE IF EXISTS `pms_attr`;

CREATE TABLE `pms_attr` (
  `attr_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '属性id',
  `attr_name` char(30) DEFAULT NULL COMMENT '属性名',
  `search_type` tinyint(4) DEFAULT NULL COMMENT '是否需要检索[0-不需要，1-需要]',
  `icon` varchar(255) DEFAULT NULL COMMENT '属性图标',
  `value_select` char(255) DEFAULT NULL COMMENT '可选值列表[用逗号分隔]',
  `attr_type` tinyint(4) DEFAULT NULL COMMENT '属性类型[0-销售属性，1-基本属性，2-既是销售属性又是基本属性]',
  `enable` bigint(20) DEFAULT NULL COMMENT '启用状态[0 - 禁用，1 - 启用]',
  `catelog_id` bigint(20) DEFAULT NULL COMMENT '所属分类',
  `show_desc` tinyint(4) DEFAULT NULL COMMENT '快速展示【是否展示在介绍上；0-否 1-是】，在sku中仍然可以调整',
  `value_type` tinyint(4) DEFAULT NULL COMMENT '值类型【1-多值，0-单值】',
  PRIMARY KEY (`attr_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COMMENT='商品属性';

/*Data for the table `pms_attr` */

insert  into `pms_attr`(`attr_id`,`attr_name`,`search_type`,`icon`,`value_select`,`attr_type`,`enable`,`catelog_id`,`show_desc`,`value_type`) values 
(9,'入网型号',1,'cccc','移动;联通;电信',1,1,225,1,0),
(10,'上市年份',1,'xxx','2020;2019;2018',1,1,225,0,1),
(11,'机身长度（mm）',0,'xxx','',1,1,225,0,0),
(12,'机身材质工艺',1,'xxx','AG.高亮',1,1,225,0,1),
(13,'屏幕材质类型',0,'xxx','AMOLED',1,1,225,0,1),
(14,'屏幕刷新率',0,'xxx','120Hz;90Hz;60Hz',1,1,225,0,1),
(15,'主屏幕尺寸（英寸）',0,'xxx','6.78;6.67',1,1,225,0,1),
(16,'机身材质分类',0,'xxx','玻璃后盖;蓝宝石',1,1,225,0,1),
(17,'CPU品牌',1,'xxx','高通(Qualcomm);麒麟990 5G;天玑1000plus',1,1,225,1,1),
(18,'颜色',0,'xxx','黑色;白色;蓝色',0,0,225,NULL,1),
(19,'5G网络',1,'xxx','移动5G;联通5G;电信5G',1,1,225,1,1),
(20,'4G网络',0,'xxx','4G FDD-LTE(联通);4G TD-LTE(移动);4G FDD-LTE(联通、电信)',1,1,225,0,1),
(21,'SIM卡类型',0,'xxx','Nano SIM',1,1,225,0,1),
(23,'充电接口类型',0,'xxx','Type-C',1,1,226,0,1),
(25,'NFC/NFC模式',0,'xxx','不支持NFC;支持NFC',1,1,226,0,1),
(26,'电池是否可拆卸',0,'ccc','电池不可拆卸',1,1,226,0,1),
(27,'价格',0,'xxx','3999;4999;5999',0,1,225,0,0),
(28,'型号',0,'cccc','6+128;8+256',0,1,225,0,1),
(29,'机身颜色',0,'ccc','',1,1,225,0,1),
(30,'GPU型号',0,'ccc','',1,1,225,0,1),
(34,'001R',0,'W','0.1;0.2;0.3',1,1,225,0,1),
(35,'002R',0,'R','。;1;v',1,1,225,0,1),
(36,'003R',0,'E','1;2',1,1,225,0,1),
(37,'WW',1,'W','w1;w2;w3',1,1,225,1,0),
(38,'Q1',0,'QQ','Q1Q;Q2Q',0,1,1450,0,0),
(40,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(41,'RR',0,'RR','R1;R2',1,1,225,0,NULL);

/*Table structure for table `pms_attr_attrgroup_relation` */

DROP TABLE IF EXISTS `pms_attr_attrgroup_relation`;

CREATE TABLE `pms_attr_attrgroup_relation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `attr_id` bigint(20) DEFAULT NULL COMMENT '属性id',
  `attr_group_id` bigint(20) DEFAULT NULL COMMENT '属性分组id',
  `attr_sort` int(11) DEFAULT NULL COMMENT '属性组内排序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=utf8mb4 COMMENT='属性&属性分组关联';

/*Data for the table `pms_attr_attrgroup_relation` */

insert  into `pms_attr_attrgroup_relation`(`id`,`attr_id`,`attr_group_id`,`attr_sort`) values 
(10,16,7,NULL),
(11,3,8,NULL),
(12,8,8,NULL),
(44,NULL,9,NULL),
(60,37,NULL,NULL),
(67,9,7,NULL),
(68,10,7,NULL),
(69,11,8,NULL),
(70,16,8,NULL),
(71,30,11,NULL),
(72,17,11,NULL),
(73,12,NULL,NULL),
(74,25,12,NULL),
(75,35,14,NULL);

/*Table structure for table `pms_attr_group` */

DROP TABLE IF EXISTS `pms_attr_group`;

CREATE TABLE `pms_attr_group` (
  `attr_group_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '分组id',
  `attr_group_name` char(20) DEFAULT NULL COMMENT '组名',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  `descript` varchar(255) DEFAULT NULL COMMENT '描述',
  `icon` varchar(255) DEFAULT NULL COMMENT '组图标',
  `catelog_id` bigint(20) DEFAULT NULL COMMENT '所属分类id',
  PRIMARY KEY (`attr_group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COMMENT='属性分组';

/*Data for the table `pms_attr_group` */

insert  into `pms_attr_group`(`attr_group_id`,`attr_group_name`,`sort`,`descript`,`icon`,`catelog_id`) values 
(7,'主体',1,'主体','xxx',225),
(8,'基本信息',1,'基本信息','xxx',225),
(9,'屏幕',1,'屏幕','xxx',250),
(11,'主芯片',1,'主芯片','xxx',225),
(12,'网络支持',1,'网络支持','xxx',226),
(14,'包装清单',1,'包装清单','xxx',225);

/*Table structure for table `pms_brand` */

DROP TABLE IF EXISTS `pms_brand`;

CREATE TABLE `pms_brand` (
  `brand_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '品牌id',
  `name` char(50) DEFAULT NULL COMMENT '品牌名',
  `logo` varchar(2000) DEFAULT NULL COMMENT '品牌logo地址',
  `descript` longtext COMMENT '介绍',
  `show_status` tinyint(4) DEFAULT NULL COMMENT '显示状态[0-不显示；1-显示]',
  `first_letter` char(1) DEFAULT NULL COMMENT '检索首字母',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COMMENT='品牌';

/*Data for the table `pms_brand` */

insert  into `pms_brand`(`brand_id`,`name`,`logo`,`descript`,`show_status`,`first_letter`,`sort`) values 
(5,'小米','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-08-23/90e86224-3a9f-4c38-8987-c9476a8e2aec_xiaomi.png','小米',1,'x',2),
(6,'oppo','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-08-23/fad1ef2b-3e08-4529-833b-bbf59252975e_oppo.png','oppo',1,'o',2),
(7,'Apple','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-08-23/9071cdf3-62da-478c-8a25-43bbd7a32524_u=1965296284,1644599058&fm=26&gp=0.jpg','苹果',1,'a',1),
(8,'华为','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-08-24/8df9a916-49f0-4466-8cff-33756873bf0c_huawei.png','华为',0,'h',1),
(17,'格力','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-04//597d7a0f-b6a8-407f-82a1-a512b7bbc747_u=191736875,1977477024&fm=26&gp=0.jpg','格力',1,'g',2),
(18,'smartisan','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//d37aa720-53c9-48c5-8138-53db7e2eefcb_5631ccdene8df5efb.png','锤子',1,'c',1),
(19,'三星','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//b3f21f32-fc40-4d62-8106-621a9da5c877_5716e2c4nc925baf3.png','三星',1,'s',1),
(20,'努比亚 nubia','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//e4ed8510-819b-4af5-83d4-5482d3c45b3d_5631cd12n7548352d.jpg','努比亚 nubia',1,'n',0),
(21,'中兴','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//6ee9f040-041b-4298-8d57-ff83a7431863_56a855a3ne38ee719.jpg','中兴',1,'z',1),
(22,'诺基亚','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//56036d12-7aa9-47aa-8f28-3d9ee64453e4_563b33d4n6c59780c.jpg','诺基亚',1,'n',1),
(23,'一加','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//ed937c2a-a61c-4b7f-85da-c72360d29d59_563b33ffn9c288c6c.jpg','一加',1,'y',0),
(24,'vivo','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//0bf2fad8-2ade-40d1-8e0f-6cdc7b487db9_563b3484n9ba68e13.jpg','vovo',1,'v',0),
(25,'魅族','https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//2a8eaf8d-d9dd-4f79-853c-2596d1e29e07_57fdf4b8n6e95624d.jpg','魅族',1,'m',0);

/*Table structure for table `pms_category` */

DROP TABLE IF EXISTS `pms_category`;

CREATE TABLE `pms_category` (
  `cat_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '分类id',
  `name` char(50) DEFAULT NULL COMMENT '分类名称',
  `parent_cid` bigint(20) DEFAULT NULL COMMENT '父分类id',
  `cat_level` int(11) DEFAULT NULL COMMENT '层级',
  `show_status` tinyint(4) DEFAULT NULL COMMENT '是否显示[0-不显示，1显示]',
  `sort` int(11) DEFAULT NULL COMMENT '排序',
  `icon` char(255) DEFAULT NULL COMMENT '图标地址',
  `product_unit` char(50) DEFAULT NULL COMMENT '计量单位',
  `product_count` int(11) DEFAULT NULL COMMENT '商品数量',
  PRIMARY KEY (`cat_id`),
  KEY `parent_cid` (`parent_cid`)
) ENGINE=InnoDB AUTO_INCREMENT=1451 DEFAULT CHARSET=utf8mb4 COMMENT='商品三级分类';

/*Data for the table `pms_category` */

insert  into `pms_category`(`cat_id`,`name`,`parent_cid`,`cat_level`,`show_status`,`sort`,`icon`,`product_unit`,`product_count`) values 
(1,'图书、音像、电子书刊',0,1,1,0,'',NULL,0),
(2,'手机',0,1,1,1,'QQQ33',NULL,0),
(3,'家用电器',0,1,1,2,NULL,NULL,0),
(4,'数码',0,1,1,3,NULL,NULL,0),
(5,'家居家装',0,1,1,4,'11',NULL,0),
(6,'电脑办公',0,1,1,5,NULL,NULL,0),
(7,'厨具',0,1,1,6,NULL,NULL,0),
(8,'个护化妆',0,1,1,7,NULL,NULL,0),
(9,'服饰内衣',0,1,1,8,NULL,NULL,0),
(10,'钟表',0,1,1,9,NULL,NULL,0),
(11,'鞋靴',0,1,1,10,NULL,NULL,0),
(12,'母婴',0,1,1,11,NULL,NULL,0),
(13,'礼品箱包',0,1,1,12,NULL,NULL,0),
(14,'食品饮料、保健食品',0,1,1,13,NULL,NULL,0),
(15,'珠宝',0,1,1,14,NULL,NULL,0),
(16,'汽车用品',0,1,1,15,NULL,NULL,0),
(17,'运动健康',0,1,1,16,NULL,NULL,0),
(18,'玩具乐器',0,1,1,17,NULL,NULL,0),
(19,'彩票、旅行、充值、票务',0,1,1,18,NULL,NULL,0),
(20,'生鲜',0,1,1,19,NULL,NULL,0),
(21,'整车',0,1,1,20,NULL,NULL,0),
(22,'电子书刊',1,2,1,0,NULL,NULL,0),
(23,'音像',1,2,1,0,NULL,NULL,0),
(24,'英文原版',1,2,1,0,NULL,NULL,0),
(25,'文艺',1,2,1,0,NULL,NULL,0),
(26,'少儿',1,2,1,0,NULL,NULL,0),
(27,'人文社科',1,2,1,0,NULL,NULL,0),
(28,'经管励志',1,2,1,0,NULL,NULL,0),
(29,'生活',1,2,1,0,NULL,NULL,0),
(30,'科技',1,2,1,0,NULL,NULL,0),
(31,'教育',1,2,1,0,NULL,NULL,0),
(32,'港台图书',1,2,1,0,NULL,NULL,0),
(33,'其他',1,2,1,0,NULL,NULL,0),
(34,'手机通讯',2,2,1,0,NULL,NULL,0),
(35,'运营商',2,2,1,1,NULL,NULL,0),
(36,'手机配件',2,2,1,4,NULL,NULL,0),
(37,'大 家 电',3,2,1,0,NULL,NULL,0),
(38,'厨卫大电',3,2,1,0,NULL,NULL,0),
(39,'厨房小电',3,2,1,0,NULL,NULL,0),
(40,'生活电器',3,2,1,0,NULL,NULL,0),
(41,'个护健康',3,2,1,0,NULL,NULL,0),
(42,'五金家装',3,2,1,0,NULL,NULL,0),
(43,'摄影摄像',4,2,1,0,NULL,NULL,0),
(44,'数码配件',4,2,1,0,NULL,NULL,0),
(45,'智能设备',4,2,1,0,NULL,NULL,0),
(46,'影音娱乐',4,2,1,0,NULL,NULL,0),
(47,'电子教育',4,2,1,0,NULL,NULL,0),
(48,'虚拟商品',4,2,1,0,NULL,NULL,0),
(49,'家纺',5,2,1,0,NULL,NULL,0),
(50,'灯具',5,2,1,0,NULL,NULL,0),
(51,'生活日用',5,2,1,0,NULL,NULL,0),
(52,'家装软饰',5,2,1,0,NULL,NULL,0),
(53,'宠物生活',5,2,1,0,NULL,NULL,0),
(54,'电脑整机',6,2,1,0,NULL,NULL,0),
(55,'电脑配件',6,2,1,0,NULL,NULL,0),
(56,'外设产品',6,2,1,0,NULL,NULL,0),
(57,'游戏设备',6,2,1,0,NULL,NULL,0),
(58,'网络产品',6,2,1,0,NULL,NULL,0),
(59,'办公设备',6,2,1,0,NULL,NULL,0),
(60,'文具/耗材',6,2,1,0,NULL,NULL,0),
(61,'服务产品',6,2,1,0,NULL,NULL,0),
(62,'烹饪锅具',7,2,1,0,NULL,NULL,0),
(63,'刀剪菜板',7,2,1,0,NULL,NULL,0),
(64,'厨房配件',7,2,1,0,NULL,NULL,0),
(65,'水具酒具',7,2,1,0,NULL,NULL,0),
(66,'餐具',7,2,1,0,NULL,NULL,0),
(67,'酒店用品',7,2,1,0,NULL,NULL,0),
(68,'茶具/咖啡具',7,2,1,0,NULL,NULL,0),
(69,'清洁用品',8,2,1,0,NULL,NULL,0),
(70,'面部护肤',8,2,1,0,NULL,NULL,0),
(71,'身体护理',8,2,1,0,NULL,NULL,0),
(72,'口腔护理',8,2,1,0,NULL,NULL,0),
(73,'女性护理',8,2,1,0,NULL,NULL,0),
(74,'洗发护发',8,2,1,0,NULL,NULL,0),
(75,'香水彩妆',8,2,1,0,NULL,NULL,0),
(76,'女装',9,2,1,0,NULL,NULL,0),
(77,'男装',9,2,1,0,NULL,NULL,0),
(78,'内衣',9,2,1,0,NULL,NULL,0),
(79,'洗衣服务',9,2,1,0,NULL,NULL,0),
(80,'服饰配件',9,2,1,0,NULL,NULL,0),
(81,'钟表',10,2,1,0,NULL,NULL,0),
(82,'流行男鞋',11,2,1,0,NULL,NULL,0),
(83,'时尚女鞋',11,2,1,0,NULL,NULL,0),
(84,'奶粉',12,2,1,0,NULL,NULL,0),
(85,'营养辅食',12,2,1,0,NULL,NULL,0),
(86,'尿裤湿巾',12,2,1,0,NULL,NULL,0),
(87,'喂养用品',12,2,1,0,NULL,NULL,0),
(88,'洗护用品',12,2,1,0,NULL,NULL,0),
(89,'童车童床',12,2,1,0,NULL,NULL,0),
(90,'寝居服饰',12,2,1,0,NULL,NULL,0),
(91,'妈妈专区',12,2,1,0,NULL,NULL,0),
(92,'童装童鞋',12,2,1,0,NULL,NULL,0),
(93,'安全座椅',12,2,1,0,NULL,NULL,0),
(94,'潮流女包',13,2,1,0,NULL,NULL,0),
(95,'精品男包',13,2,1,0,NULL,NULL,0),
(96,'功能箱包',13,2,1,0,NULL,NULL,0),
(97,'礼品',13,2,1,0,NULL,NULL,0),
(98,'奢侈品',13,2,1,0,NULL,NULL,0),
(99,'婚庆',13,2,1,0,NULL,NULL,0),
(100,'进口食品',14,2,1,0,NULL,NULL,0),
(101,'地方特产',14,2,1,0,NULL,NULL,0),
(102,'休闲食品',14,2,1,0,NULL,NULL,0),
(103,'粮油调味',14,2,1,0,NULL,NULL,0),
(104,'饮料冲调',14,2,1,0,NULL,NULL,0),
(105,'食品礼券',14,2,1,0,NULL,NULL,0),
(106,'茗茶',14,2,1,0,NULL,NULL,0),
(107,'时尚饰品',15,2,1,0,NULL,NULL,0),
(108,'黄金',15,2,1,0,NULL,NULL,0),
(109,'K金饰品',15,2,1,0,NULL,NULL,0),
(110,'金银投资',15,2,1,0,NULL,NULL,0),
(111,'银饰',15,2,1,0,NULL,NULL,0),
(112,'钻石',15,2,1,0,NULL,NULL,0),
(113,'翡翠玉石',15,2,1,0,NULL,NULL,0),
(114,'水晶玛瑙',15,2,1,0,NULL,NULL,0),
(115,'彩宝',15,2,1,0,NULL,NULL,0),
(116,'铂金',15,2,1,0,NULL,NULL,0),
(117,'木手串/把件',15,2,1,0,NULL,NULL,0),
(118,'珍珠',15,2,1,0,NULL,NULL,0),
(119,'维修保养',16,2,1,0,NULL,NULL,0),
(120,'车载电器',16,2,1,0,NULL,NULL,0),
(121,'美容清洗',16,2,1,0,NULL,NULL,0),
(122,'汽车装饰',16,2,1,0,NULL,NULL,0),
(123,'安全自驾',16,2,1,0,NULL,NULL,0),
(124,'汽车服务',16,2,1,0,NULL,NULL,0),
(125,'赛事改装',16,2,1,0,NULL,NULL,0),
(126,'运动鞋包',17,2,1,0,NULL,NULL,0),
(127,'运动服饰',17,2,1,0,NULL,NULL,0),
(128,'骑行运动',17,2,1,0,NULL,NULL,0),
(129,'垂钓用品',17,2,1,0,NULL,NULL,0),
(130,'游泳用品',17,2,1,0,NULL,NULL,0),
(131,'户外鞋服',17,2,1,0,NULL,NULL,0),
(132,'户外装备',17,2,1,0,NULL,NULL,0),
(133,'健身训练',17,2,1,0,NULL,NULL,0),
(134,'体育用品',17,2,1,0,NULL,NULL,0),
(135,'适用年龄',18,2,1,0,NULL,NULL,0),
(136,'遥控/电动',18,2,1,0,NULL,NULL,0),
(137,'毛绒布艺',18,2,1,0,NULL,NULL,0),
(138,'娃娃玩具',18,2,1,0,NULL,NULL,0),
(139,'模型玩具',18,2,1,0,NULL,NULL,0),
(140,'健身玩具',18,2,1,0,NULL,NULL,0),
(141,'动漫玩具',18,2,1,0,NULL,NULL,0),
(142,'益智玩具',18,2,1,0,NULL,NULL,0),
(143,'积木拼插',18,2,1,0,NULL,NULL,0),
(144,'DIY玩具',18,2,1,0,NULL,NULL,0),
(145,'创意减压',18,2,1,0,NULL,NULL,0),
(146,'乐器',18,2,1,0,NULL,NULL,0),
(147,'彩票',19,2,1,0,NULL,NULL,0),
(148,'机票',19,2,1,0,NULL,NULL,0),
(149,'酒店',19,2,1,0,NULL,NULL,0),
(150,'旅行',19,2,1,0,NULL,NULL,0),
(151,'充值',19,2,1,0,NULL,NULL,0),
(152,'游戏',19,2,1,0,NULL,NULL,0),
(153,'票务',19,2,1,0,NULL,NULL,0),
(154,'产地直供',20,2,1,0,NULL,NULL,0),
(155,'水果',20,2,1,0,NULL,NULL,0),
(156,'猪牛羊肉',20,2,1,0,NULL,NULL,0),
(157,'海鲜水产',20,2,1,0,NULL,NULL,0),
(158,'禽肉蛋品',20,2,1,0,NULL,NULL,0),
(159,'冷冻食品',20,2,1,0,NULL,NULL,0),
(160,'熟食腊味',20,2,1,0,NULL,NULL,0),
(161,'饮品甜品',20,2,1,0,NULL,NULL,0),
(162,'蔬菜',20,2,1,0,NULL,NULL,0),
(163,'全新整车',21,2,1,0,NULL,NULL,0),
(164,'二手车',21,2,1,0,NULL,NULL,0),
(165,'电子书',22,3,1,0,NULL,NULL,0),
(166,'网络原创',22,3,1,0,NULL,NULL,0),
(167,'数字杂志',22,3,1,0,NULL,NULL,0),
(168,'多媒体图书',22,3,1,0,NULL,NULL,0),
(169,'音乐',23,3,1,0,NULL,NULL,0),
(170,'影视',23,3,1,0,NULL,NULL,0),
(171,'教育音像',23,3,1,0,NULL,NULL,0),
(172,'少儿',24,3,1,0,NULL,NULL,0),
(173,'商务投资',24,3,1,0,NULL,NULL,0),
(174,'英语学习与考试',24,3,1,0,NULL,NULL,0),
(175,'文学',24,3,1,0,NULL,NULL,0),
(176,'传记',24,3,1,0,NULL,NULL,0),
(177,'励志',24,3,1,0,NULL,NULL,0),
(178,'小说',25,3,1,0,NULL,NULL,0),
(179,'文学',25,3,1,0,NULL,NULL,0),
(180,'青春文学',25,3,1,0,NULL,NULL,0),
(181,'传记',25,3,1,0,NULL,NULL,0),
(182,'艺术',25,3,1,0,NULL,NULL,0),
(183,'少儿',26,3,1,0,NULL,NULL,0),
(184,'0-2岁',26,3,1,0,NULL,NULL,0),
(185,'3-6岁',26,3,1,0,NULL,NULL,0),
(186,'7-10岁',26,3,1,0,NULL,NULL,0),
(187,'11-14岁',26,3,1,0,NULL,NULL,0),
(188,'历史',27,3,1,0,NULL,NULL,0),
(189,'哲学',27,3,1,0,NULL,NULL,0),
(190,'国学',27,3,1,0,NULL,NULL,0),
(191,'政治/军事',27,3,1,0,NULL,NULL,0),
(192,'法律',27,3,1,0,NULL,NULL,0),
(193,'人文社科',27,3,1,0,NULL,NULL,0),
(194,'心理学',27,3,1,0,NULL,NULL,0),
(195,'文化',27,3,1,0,NULL,NULL,0),
(196,'社会科学',27,3,1,0,NULL,NULL,0),
(197,'经济',28,3,1,0,NULL,NULL,0),
(198,'金融与投资',28,3,1,0,NULL,NULL,0),
(199,'管理',28,3,1,0,NULL,NULL,0),
(200,'励志与成功',28,3,1,0,NULL,NULL,0),
(201,'生活',29,3,1,0,NULL,NULL,0),
(202,'健身与保健',29,3,1,0,NULL,NULL,0),
(203,'家庭与育儿',29,3,1,0,NULL,NULL,0),
(204,'旅游',29,3,1,0,NULL,NULL,0),
(205,'烹饪美食',29,3,1,0,NULL,NULL,0),
(206,'工业技术',30,3,1,0,NULL,NULL,0),
(207,'科普读物',30,3,1,0,NULL,NULL,0),
(208,'建筑',30,3,1,0,NULL,NULL,0),
(209,'医学',30,3,1,0,NULL,NULL,0),
(210,'科学与自然',30,3,1,0,NULL,NULL,0),
(211,'计算机与互联网',30,3,1,0,NULL,NULL,0),
(212,'电子通信',30,3,1,0,NULL,NULL,0),
(213,'中小学教辅',31,3,1,0,NULL,NULL,0),
(214,'教育与考试',31,3,1,0,NULL,NULL,0),
(215,'外语学习',31,3,1,0,NULL,NULL,0),
(216,'大中专教材',31,3,1,0,NULL,NULL,0),
(217,'字典词典',31,3,1,0,NULL,NULL,0),
(218,'艺术/设计/收藏',32,3,1,0,NULL,NULL,0),
(219,'经济管理',32,3,1,0,NULL,NULL,0),
(220,'文化/学术',32,3,1,0,NULL,NULL,0),
(221,'少儿',32,3,1,0,NULL,NULL,0),
(222,'工具书',33,3,1,0,NULL,NULL,0),
(223,'杂志/期刊',33,3,1,0,NULL,NULL,0),
(224,'套装书',33,3,1,0,NULL,NULL,0),
(225,'手机',34,3,1,0,NULL,NULL,0),
(226,'对讲机',34,3,1,0,NULL,NULL,0),
(227,'合约机',35,3,1,0,NULL,NULL,0),
(228,'选号中心',35,3,1,0,NULL,NULL,0),
(229,'装宽带',35,3,1,0,NULL,NULL,0),
(230,'办套餐',35,3,1,0,NULL,NULL,0),
(231,'移动电源',36,3,1,0,NULL,NULL,0),
(232,'电池/移动电源',36,3,1,0,NULL,NULL,0),
(233,'蓝牙耳机',36,3,1,0,NULL,NULL,0),
(234,'充电器/数据线',36,3,1,0,NULL,NULL,0),
(235,'苹果周边',36,3,1,0,NULL,NULL,0),
(236,'手机耳机',36,3,1,0,NULL,NULL,0),
(237,'手机贴膜',36,3,1,0,NULL,NULL,0),
(238,'手机存储卡',36,3,1,0,NULL,NULL,0),
(239,'充电器',36,3,1,0,NULL,NULL,0),
(240,'数据线',36,3,1,0,NULL,NULL,0),
(241,'手机保护套',36,3,1,0,NULL,NULL,0),
(242,'车载配件',36,3,1,0,NULL,NULL,0),
(243,'iPhone 配件',36,3,1,0,NULL,NULL,0),
(244,'手机电池',36,3,1,0,NULL,NULL,0),
(245,'创意配件',36,3,1,0,NULL,NULL,0),
(246,'便携/无线音响',36,3,1,0,NULL,NULL,0),
(247,'手机饰品',36,3,1,0,NULL,NULL,0),
(248,'拍照配件',36,3,1,0,NULL,NULL,0),
(249,'手机支架',36,3,1,0,NULL,NULL,0),
(250,'平板电视',37,3,1,0,NULL,NULL,0),
(251,'空调',37,3,1,0,NULL,NULL,0),
(252,'冰箱',37,3,1,0,NULL,NULL,0),
(253,'洗衣机',37,3,1,0,NULL,NULL,0),
(254,'家庭影院',37,3,1,0,NULL,NULL,0),
(255,'DVD/电视盒子',37,3,1,0,NULL,NULL,0),
(256,'迷你音响',37,3,1,0,NULL,NULL,0),
(257,'冷柜/冰吧',37,3,1,0,NULL,NULL,0),
(258,'家电配件',37,3,1,0,NULL,NULL,0),
(259,'功放',37,3,1,0,NULL,NULL,0),
(260,'回音壁/Soundbar',37,3,1,0,NULL,NULL,0),
(261,'Hi-Fi专区',37,3,1,0,NULL,NULL,0),
(262,'电视盒子',37,3,1,0,NULL,NULL,0),
(263,'酒柜',37,3,1,0,NULL,NULL,0),
(264,'燃气灶',38,3,1,0,NULL,NULL,0),
(265,'油烟机',38,3,1,0,NULL,NULL,0),
(266,'热水器',38,3,1,0,NULL,NULL,0),
(267,'消毒柜',38,3,1,0,NULL,NULL,0),
(268,'洗碗机',38,3,1,0,NULL,NULL,0),
(269,'料理机',39,3,1,0,NULL,NULL,0),
(270,'榨汁机',39,3,1,0,NULL,NULL,0),
(271,'电饭煲',39,3,1,0,NULL,NULL,0),
(272,'电压力锅',39,3,1,0,NULL,NULL,0),
(273,'豆浆机',39,3,1,0,NULL,NULL,0),
(274,'咖啡机',39,3,1,0,NULL,NULL,0),
(275,'微波炉',39,3,1,0,NULL,NULL,0),
(276,'电烤箱',39,3,1,0,NULL,NULL,0),
(277,'电磁炉',39,3,1,0,NULL,NULL,0),
(278,'面包机',39,3,1,0,NULL,NULL,0),
(279,'煮蛋器',39,3,1,0,NULL,NULL,0),
(280,'酸奶机',39,3,1,0,NULL,NULL,0),
(281,'电炖锅',39,3,1,0,NULL,NULL,0),
(282,'电水壶/热水瓶',39,3,1,0,NULL,NULL,0),
(283,'电饼铛',39,3,1,0,NULL,NULL,0),
(284,'多用途锅',39,3,1,0,NULL,NULL,0),
(285,'电烧烤炉',39,3,1,0,NULL,NULL,0),
(286,'果蔬解毒机',39,3,1,0,NULL,NULL,0),
(287,'其它厨房电器',39,3,1,0,NULL,NULL,0),
(288,'养生壶/煎药壶',39,3,1,0,NULL,NULL,0),
(289,'电热饭盒',39,3,1,0,NULL,NULL,0),
(290,'取暖电器',40,3,1,0,NULL,NULL,0),
(291,'净化器',40,3,1,0,NULL,NULL,0),
(292,'加湿器',40,3,1,0,NULL,NULL,0),
(293,'扫地机器人',40,3,1,0,NULL,NULL,0),
(294,'吸尘器',40,3,1,0,NULL,NULL,0),
(295,'挂烫机/熨斗',40,3,1,0,NULL,NULL,0),
(296,'插座',40,3,1,0,NULL,NULL,0),
(297,'电话机',40,3,1,0,NULL,NULL,0),
(298,'清洁机',40,3,1,0,NULL,NULL,0),
(299,'除湿机',40,3,1,0,NULL,NULL,0),
(300,'干衣机',40,3,1,0,NULL,NULL,0),
(301,'收录/音机',40,3,1,0,NULL,NULL,0),
(302,'电风扇',40,3,1,0,NULL,NULL,0),
(303,'冷风扇',40,3,1,0,NULL,NULL,0),
(304,'其它生活电器',40,3,1,0,NULL,NULL,0),
(305,'生活电器配件',40,3,1,0,NULL,NULL,0),
(306,'净水器',40,3,1,0,NULL,NULL,0),
(307,'饮水机',40,3,1,0,NULL,NULL,0),
(308,'剃须刀',41,3,1,0,NULL,NULL,0),
(309,'剃/脱毛器',41,3,1,0,NULL,NULL,0),
(310,'口腔护理',41,3,1,0,NULL,NULL,0),
(311,'电吹风',41,3,1,0,NULL,NULL,0),
(312,'美容器',41,3,1,0,NULL,NULL,0),
(313,'理发器',41,3,1,0,NULL,NULL,0),
(314,'卷/直发器',41,3,1,0,NULL,NULL,0),
(315,'按摩椅',41,3,1,0,NULL,NULL,0),
(316,'按摩器',41,3,1,0,NULL,NULL,0),
(317,'足浴盆',41,3,1,0,NULL,NULL,0),
(318,'血压计',41,3,1,0,NULL,NULL,0),
(319,'电子秤/厨房秤',41,3,1,0,NULL,NULL,0),
(320,'血糖仪',41,3,1,0,NULL,NULL,0),
(321,'体温计',41,3,1,0,NULL,NULL,0),
(322,'其它健康电器',41,3,1,0,NULL,NULL,0),
(323,'计步器/脂肪检测仪',41,3,1,0,NULL,NULL,0),
(324,'电动工具',42,3,1,0,NULL,NULL,0),
(325,'手动工具',42,3,1,0,NULL,NULL,0),
(326,'仪器仪表',42,3,1,0,NULL,NULL,0),
(327,'浴霸/排气扇',42,3,1,0,NULL,NULL,0),
(328,'灯具',42,3,1,0,NULL,NULL,0),
(329,'LED灯',42,3,1,0,NULL,NULL,0),
(330,'洁身器',42,3,1,0,NULL,NULL,0),
(331,'水槽',42,3,1,0,NULL,NULL,0),
(332,'龙头',42,3,1,0,NULL,NULL,0),
(333,'淋浴花洒',42,3,1,0,NULL,NULL,0),
(334,'厨卫五金',42,3,1,0,NULL,NULL,0),
(335,'家具五金',42,3,1,0,NULL,NULL,0),
(336,'门铃',42,3,1,0,NULL,NULL,0),
(337,'电气开关',42,3,1,0,NULL,NULL,0),
(338,'插座',42,3,1,0,NULL,NULL,0),
(339,'电工电料',42,3,1,0,NULL,NULL,0),
(340,'监控安防',42,3,1,0,NULL,NULL,0),
(341,'电线/线缆',42,3,1,0,NULL,NULL,0),
(342,'数码相机',43,3,1,0,NULL,NULL,0),
(343,'单电/微单相机',43,3,1,0,NULL,NULL,0),
(344,'单反相机',43,3,1,0,NULL,NULL,0),
(345,'摄像机',43,3,1,0,NULL,NULL,0),
(346,'拍立得',43,3,1,0,NULL,NULL,0),
(347,'运动相机',43,3,1,0,NULL,NULL,0),
(348,'镜头',43,3,1,0,NULL,NULL,0),
(349,'户外器材',43,3,1,0,NULL,NULL,0),
(350,'影棚器材',43,3,1,0,NULL,NULL,0),
(351,'冲印服务',43,3,1,0,NULL,NULL,0),
(352,'数码相框',43,3,1,0,NULL,NULL,0),
(353,'存储卡',44,3,1,0,NULL,NULL,0),
(354,'读卡器',44,3,1,0,NULL,NULL,0),
(355,'滤镜',44,3,1,0,NULL,NULL,0),
(356,'闪光灯/手柄',44,3,1,0,NULL,NULL,0),
(357,'相机包',44,3,1,0,NULL,NULL,0),
(358,'三脚架/云台',44,3,1,0,NULL,NULL,0),
(359,'相机清洁/贴膜',44,3,1,0,NULL,NULL,0),
(360,'机身附件',44,3,1,0,NULL,NULL,0),
(361,'镜头附件',44,3,1,0,NULL,NULL,0),
(362,'电池/充电器',44,3,1,0,NULL,NULL,0),
(363,'移动电源',44,3,1,0,NULL,NULL,0),
(364,'数码支架',44,3,1,0,NULL,NULL,0),
(365,'智能手环',45,3,1,0,NULL,NULL,0),
(366,'智能手表',45,3,1,0,NULL,NULL,0),
(367,'智能眼镜',45,3,1,0,NULL,NULL,0),
(368,'运动跟踪器',45,3,1,0,NULL,NULL,0),
(369,'健康监测',45,3,1,0,NULL,NULL,0),
(370,'智能配饰',45,3,1,0,NULL,NULL,0),
(371,'智能家居',45,3,1,0,NULL,NULL,0),
(372,'体感车',45,3,1,0,NULL,NULL,0),
(373,'其他配件',45,3,1,0,NULL,NULL,0),
(374,'智能机器人',45,3,1,0,NULL,NULL,0),
(375,'无人机',45,3,1,0,NULL,NULL,0),
(376,'MP3/MP4',46,3,1,0,NULL,NULL,0),
(377,'智能设备',46,3,1,0,NULL,NULL,0),
(378,'耳机/耳麦',46,3,1,0,NULL,NULL,0),
(379,'便携/无线音箱',46,3,1,0,NULL,NULL,0),
(380,'音箱/音响',46,3,1,0,NULL,NULL,0),
(381,'高清播放器',46,3,1,0,NULL,NULL,0),
(382,'收音机',46,3,1,0,NULL,NULL,0),
(383,'MP3/MP4配件',46,3,1,0,NULL,NULL,0),
(384,'麦克风',46,3,1,0,NULL,NULL,0),
(385,'专业音频',46,3,1,0,NULL,NULL,0),
(386,'苹果配件',46,3,1,0,NULL,NULL,0),
(387,'学生平板',47,3,1,0,NULL,NULL,0),
(388,'点读机/笔',47,3,1,0,NULL,NULL,0),
(389,'早教益智',47,3,1,0,NULL,NULL,0),
(390,'录音笔',47,3,1,0,NULL,NULL,0),
(391,'电纸书',47,3,1,0,NULL,NULL,0),
(392,'电子词典',47,3,1,0,NULL,NULL,0),
(393,'复读机',47,3,1,0,NULL,NULL,0),
(394,'延保服务',48,3,1,0,NULL,NULL,0),
(395,'杀毒软件',48,3,1,0,NULL,NULL,0),
(396,'积分商品',48,3,1,0,NULL,NULL,0),
(397,'桌布/罩件',49,3,1,0,NULL,NULL,0),
(398,'地毯地垫',49,3,1,0,NULL,NULL,0),
(399,'沙发垫套/椅垫',49,3,1,0,NULL,NULL,0),
(400,'床品套件',49,3,1,0,NULL,NULL,0),
(401,'被子',49,3,1,0,NULL,NULL,0),
(402,'枕芯',49,3,1,0,NULL,NULL,0),
(403,'床单被罩',49,3,1,0,NULL,NULL,0),
(404,'毯子',49,3,1,0,NULL,NULL,0),
(405,'床垫/床褥',49,3,1,0,NULL,NULL,0),
(406,'蚊帐',49,3,1,0,NULL,NULL,0),
(407,'抱枕靠垫',49,3,1,0,NULL,NULL,0),
(408,'毛巾浴巾',49,3,1,0,NULL,NULL,0),
(409,'电热毯',49,3,1,0,NULL,NULL,0),
(410,'窗帘/窗纱',49,3,1,0,NULL,NULL,0),
(411,'布艺软饰',49,3,1,0,NULL,NULL,0),
(412,'凉席',49,3,1,0,NULL,NULL,0),
(413,'台灯',50,3,1,0,NULL,NULL,0),
(414,'节能灯',50,3,1,0,NULL,NULL,0),
(415,'装饰灯',50,3,1,0,NULL,NULL,0),
(416,'落地灯',50,3,1,0,NULL,NULL,0),
(417,'应急灯/手电',50,3,1,0,NULL,NULL,0),
(418,'LED灯',50,3,1,0,NULL,NULL,0),
(419,'吸顶灯',50,3,1,0,NULL,NULL,0),
(420,'五金电器',50,3,1,0,NULL,NULL,0),
(421,'筒灯射灯',50,3,1,0,NULL,NULL,0),
(422,'吊灯',50,3,1,0,NULL,NULL,0),
(423,'氛围照明',50,3,1,0,NULL,NULL,0),
(424,'保暖防护',51,3,1,0,NULL,NULL,0),
(425,'收纳用品',51,3,1,0,NULL,NULL,0),
(426,'雨伞雨具',51,3,1,0,NULL,NULL,0),
(427,'浴室用品',51,3,1,0,NULL,NULL,0),
(428,'缝纫/针织用品',51,3,1,0,NULL,NULL,0),
(429,'洗晒/熨烫',51,3,1,0,NULL,NULL,0),
(430,'净化除味',51,3,1,0,NULL,NULL,0),
(431,'相框/照片墙',52,3,1,0,NULL,NULL,0),
(432,'装饰字画',52,3,1,0,NULL,NULL,0),
(433,'节庆饰品',52,3,1,0,NULL,NULL,0),
(434,'手工/十字绣',52,3,1,0,NULL,NULL,0),
(435,'装饰摆件',52,3,1,0,NULL,NULL,0),
(436,'帘艺隔断',52,3,1,0,NULL,NULL,0),
(437,'墙贴/装饰贴',52,3,1,0,NULL,NULL,0),
(438,'钟饰',52,3,1,0,NULL,NULL,0),
(439,'花瓶花艺',52,3,1,0,NULL,NULL,0),
(440,'香薰蜡烛',52,3,1,0,NULL,NULL,0),
(441,'创意家居',52,3,1,0,NULL,NULL,0),
(442,'宠物主粮',53,3,1,0,NULL,NULL,0),
(443,'宠物零食',53,3,1,0,NULL,NULL,0),
(444,'医疗保健',53,3,1,0,NULL,NULL,0),
(445,'家居日用',53,3,1,0,NULL,NULL,0),
(446,'宠物玩具',53,3,1,0,NULL,NULL,0),
(447,'出行装备',53,3,1,0,NULL,NULL,0),
(448,'洗护美容',53,3,1,0,NULL,NULL,0),
(449,'笔记本',54,3,1,0,NULL,NULL,0),
(450,'超极本',54,3,1,0,NULL,NULL,0),
(451,'游戏本',54,3,1,0,NULL,NULL,0),
(452,'平板电脑',54,3,1,0,NULL,NULL,0),
(453,'平板电脑配件',54,3,1,0,NULL,NULL,0),
(454,'台式机',54,3,1,0,NULL,NULL,0),
(455,'服务器/工作站',54,3,1,0,NULL,NULL,0),
(456,'笔记本配件',54,3,1,0,NULL,NULL,0),
(457,'一体机',54,3,1,0,NULL,NULL,0),
(458,'CPU',55,3,1,0,NULL,NULL,0),
(459,'主板',55,3,1,0,NULL,NULL,0),
(460,'显卡',55,3,1,0,NULL,NULL,0),
(461,'硬盘',55,3,1,0,NULL,NULL,0),
(462,'SSD固态硬盘',55,3,1,0,NULL,NULL,0),
(463,'内存',55,3,1,0,NULL,NULL,0),
(464,'机箱',55,3,1,0,NULL,NULL,0),
(465,'电源',55,3,1,0,NULL,NULL,0),
(466,'显示器',55,3,1,0,NULL,NULL,0),
(467,'刻录机/光驱',55,3,1,0,NULL,NULL,0),
(468,'散热器',55,3,1,0,NULL,NULL,0),
(469,'声卡/扩展卡',55,3,1,0,NULL,NULL,0),
(470,'装机配件',55,3,1,0,NULL,NULL,0),
(471,'组装电脑',55,3,1,0,NULL,NULL,0),
(472,'移动硬盘',56,3,1,0,NULL,NULL,0),
(473,'U盘',56,3,1,0,NULL,NULL,0),
(474,'鼠标',56,3,1,0,NULL,NULL,0),
(475,'键盘',56,3,1,0,NULL,NULL,0),
(476,'鼠标垫',56,3,1,0,NULL,NULL,0),
(477,'摄像头',56,3,1,0,NULL,NULL,0),
(478,'手写板',56,3,1,0,NULL,NULL,0),
(479,'硬盘盒',56,3,1,0,NULL,NULL,0),
(480,'插座',56,3,1,0,NULL,NULL,0),
(481,'线缆',56,3,1,0,NULL,NULL,0),
(482,'UPS电源',56,3,1,0,NULL,NULL,0),
(483,'电脑工具',56,3,1,0,NULL,NULL,0),
(484,'游戏设备',56,3,1,0,NULL,NULL,0),
(485,'电玩',56,3,1,0,NULL,NULL,0),
(486,'电脑清洁',56,3,1,0,NULL,NULL,0),
(487,'网络仪表仪器',56,3,1,0,NULL,NULL,0),
(488,'游戏机',57,3,1,0,NULL,NULL,0),
(489,'游戏耳机',57,3,1,0,NULL,NULL,0),
(490,'手柄/方向盘',57,3,1,0,NULL,NULL,0),
(491,'游戏软件',57,3,1,0,NULL,NULL,0),
(492,'游戏周边',57,3,1,0,NULL,NULL,0),
(493,'路由器',58,3,1,0,NULL,NULL,0),
(494,'网卡',58,3,1,0,NULL,NULL,0),
(495,'交换机',58,3,1,0,NULL,NULL,0),
(496,'网络存储',58,3,1,0,NULL,NULL,0),
(497,'4G/3G上网',58,3,1,0,NULL,NULL,0),
(498,'网络盒子',58,3,1,0,NULL,NULL,0),
(499,'网络配件',58,3,1,0,NULL,NULL,0),
(500,'投影机',59,3,1,0,NULL,NULL,0),
(501,'投影配件',59,3,1,0,NULL,NULL,0),
(502,'多功能一体机',59,3,1,0,NULL,NULL,0),
(503,'打印机',59,3,1,0,NULL,NULL,0),
(504,'传真设备',59,3,1,0,NULL,NULL,0),
(505,'验钞/点钞机',59,3,1,0,NULL,NULL,0),
(506,'扫描设备',59,3,1,0,NULL,NULL,0),
(507,'复合机',59,3,1,0,NULL,NULL,0),
(508,'碎纸机',59,3,1,0,NULL,NULL,0),
(509,'考勤机',59,3,1,0,NULL,NULL,0),
(510,'收款/POS机',59,3,1,0,NULL,NULL,0),
(511,'会议音频视频',59,3,1,0,NULL,NULL,0),
(512,'保险柜',59,3,1,0,NULL,NULL,0),
(513,'装订/封装机',59,3,1,0,NULL,NULL,0),
(514,'安防监控',59,3,1,0,NULL,NULL,0),
(515,'办公家具',59,3,1,0,NULL,NULL,0),
(516,'白板',59,3,1,0,NULL,NULL,0),
(517,'硒鼓/墨粉',60,3,1,0,NULL,NULL,0),
(518,'墨盒',60,3,1,0,NULL,NULL,0),
(519,'色带',60,3,1,0,NULL,NULL,0),
(520,'纸类',60,3,1,0,NULL,NULL,0),
(521,'办公文具',60,3,1,0,NULL,NULL,0),
(522,'学生文具',60,3,1,0,NULL,NULL,0),
(523,'财会用品',60,3,1,0,NULL,NULL,0),
(524,'文件管理',60,3,1,0,NULL,NULL,0),
(525,'本册/便签',60,3,1,0,NULL,NULL,0),
(526,'计算器',60,3,1,0,NULL,NULL,0),
(527,'笔类',60,3,1,0,NULL,NULL,0),
(528,'画具画材',60,3,1,0,NULL,NULL,0),
(529,'刻录碟片/附件',60,3,1,0,NULL,NULL,0),
(530,'上门安装',61,3,1,0,NULL,NULL,0),
(531,'延保服务',61,3,1,0,NULL,NULL,0),
(532,'维修保养',61,3,1,0,NULL,NULL,0),
(533,'电脑软件',61,3,1,0,NULL,NULL,0),
(534,'京东服务',61,3,1,0,NULL,NULL,0),
(535,'炒锅',62,3,1,0,NULL,NULL,0),
(536,'煎锅',62,3,1,0,NULL,NULL,0),
(537,'压力锅',62,3,1,0,NULL,NULL,0),
(538,'蒸锅',62,3,1,0,NULL,NULL,0),
(539,'汤锅',62,3,1,0,NULL,NULL,0),
(540,'奶锅',62,3,1,0,NULL,NULL,0),
(541,'锅具套装',62,3,1,0,NULL,NULL,0),
(542,'煲类',62,3,1,0,NULL,NULL,0),
(543,'水壶',62,3,1,0,NULL,NULL,0),
(544,'火锅',62,3,1,0,NULL,NULL,0),
(545,'菜刀',63,3,1,0,NULL,NULL,0),
(546,'剪刀',63,3,1,0,NULL,NULL,0),
(547,'刀具套装',63,3,1,0,NULL,NULL,0),
(548,'砧板',63,3,1,0,NULL,NULL,0),
(549,'瓜果刀/刨',63,3,1,0,NULL,NULL,0),
(550,'多功能刀',63,3,1,0,NULL,NULL,0),
(551,'保鲜盒',64,3,1,0,NULL,NULL,0),
(552,'烘焙/烧烤',64,3,1,0,NULL,NULL,0),
(553,'饭盒/提锅',64,3,1,0,NULL,NULL,0),
(554,'储物/置物架',64,3,1,0,NULL,NULL,0),
(555,'厨房DIY/小工具',64,3,1,0,NULL,NULL,0),
(556,'塑料杯',65,3,1,0,NULL,NULL,0),
(557,'运动水壶',65,3,1,0,NULL,NULL,0),
(558,'玻璃杯',65,3,1,0,NULL,NULL,0),
(559,'陶瓷/马克杯',65,3,1,0,NULL,NULL,0),
(560,'保温杯',65,3,1,0,NULL,NULL,0),
(561,'保温壶',65,3,1,0,NULL,NULL,0),
(562,'酒杯/酒具',65,3,1,0,NULL,NULL,0),
(563,'杯具套装',65,3,1,0,NULL,NULL,0),
(564,'餐具套装',66,3,1,0,NULL,NULL,0),
(565,'碗/碟/盘',66,3,1,0,NULL,NULL,0),
(566,'筷勺/刀叉',66,3,1,0,NULL,NULL,0),
(567,'一次性用品',66,3,1,0,NULL,NULL,0),
(568,'果盘/果篮',66,3,1,0,NULL,NULL,0),
(569,'自助餐炉',67,3,1,0,NULL,NULL,0),
(570,'酒店餐具',67,3,1,0,NULL,NULL,0),
(571,'酒店水具',67,3,1,0,NULL,NULL,0),
(572,'整套茶具',68,3,1,0,NULL,NULL,0),
(573,'茶杯',68,3,1,0,NULL,NULL,0),
(574,'茶壶',68,3,1,0,NULL,NULL,0),
(575,'茶盘茶托',68,3,1,0,NULL,NULL,0),
(576,'茶叶罐',68,3,1,0,NULL,NULL,0),
(577,'茶具配件',68,3,1,0,NULL,NULL,0),
(578,'茶宠摆件',68,3,1,0,NULL,NULL,0),
(579,'咖啡具',68,3,1,0,NULL,NULL,0),
(580,'其他',68,3,1,0,NULL,NULL,0),
(581,'纸品湿巾',69,3,1,0,NULL,NULL,0),
(582,'衣物清洁',69,3,1,0,NULL,NULL,0),
(583,'清洁工具',69,3,1,0,NULL,NULL,0),
(584,'驱虫用品',69,3,1,0,NULL,NULL,0),
(585,'家庭清洁',69,3,1,0,NULL,NULL,0),
(586,'皮具护理',69,3,1,0,NULL,NULL,0),
(587,'一次性用品',69,3,1,0,NULL,NULL,0),
(588,'洁面',70,3,1,0,NULL,NULL,0),
(589,'乳液面霜',70,3,1,0,NULL,NULL,0),
(590,'面膜',70,3,1,0,NULL,NULL,0),
(591,'剃须',70,3,1,0,NULL,NULL,0),
(592,'套装',70,3,1,0,NULL,NULL,0),
(593,'精华',70,3,1,0,NULL,NULL,0),
(594,'眼霜',70,3,1,0,NULL,NULL,0),
(595,'卸妆',70,3,1,0,NULL,NULL,0),
(596,'防晒',70,3,1,0,NULL,NULL,0),
(597,'防晒隔离',70,3,1,0,NULL,NULL,0),
(598,'T区护理',70,3,1,0,NULL,NULL,0),
(599,'眼部护理',70,3,1,0,NULL,NULL,0),
(600,'精华露',70,3,1,0,NULL,NULL,0),
(601,'爽肤水',70,3,1,0,NULL,NULL,0),
(602,'沐浴',71,3,1,0,NULL,NULL,0),
(603,'润肤',71,3,1,0,NULL,NULL,0),
(604,'颈部',71,3,1,0,NULL,NULL,0),
(605,'手足',71,3,1,0,NULL,NULL,0),
(606,'纤体塑形',71,3,1,0,NULL,NULL,0),
(607,'美胸',71,3,1,0,NULL,NULL,0),
(608,'套装',71,3,1,0,NULL,NULL,0),
(609,'精油',71,3,1,0,NULL,NULL,0),
(610,'洗发护发',71,3,1,0,NULL,NULL,0),
(611,'染发/造型',71,3,1,0,NULL,NULL,0),
(612,'香薰精油',71,3,1,0,NULL,NULL,0),
(613,'磨砂/浴盐',71,3,1,0,NULL,NULL,0),
(614,'手工/香皂',71,3,1,0,NULL,NULL,0),
(615,'洗发',71,3,1,0,NULL,NULL,0),
(616,'护发',71,3,1,0,NULL,NULL,0),
(617,'染发',71,3,1,0,NULL,NULL,0),
(618,'磨砂膏',71,3,1,0,NULL,NULL,0),
(619,'香皂',71,3,1,0,NULL,NULL,0),
(620,'牙膏/牙粉',72,3,1,0,NULL,NULL,0),
(621,'牙刷/牙线',72,3,1,0,NULL,NULL,0),
(622,'漱口水',72,3,1,0,NULL,NULL,0),
(623,'套装',72,3,1,0,NULL,NULL,0),
(624,'卫生巾',73,3,1,0,NULL,NULL,0),
(625,'卫生护垫',73,3,1,0,NULL,NULL,0),
(626,'私密护理',73,3,1,0,NULL,NULL,0),
(627,'脱毛膏',73,3,1,0,NULL,NULL,0),
(628,'其他',73,3,1,0,NULL,NULL,0),
(629,'洗发',74,3,1,0,NULL,NULL,0),
(630,'护发',74,3,1,0,NULL,NULL,0),
(631,'染发',74,3,1,0,NULL,NULL,0),
(632,'造型',74,3,1,0,NULL,NULL,0),
(633,'假发',74,3,1,0,NULL,NULL,0),
(634,'套装',74,3,1,0,NULL,NULL,0),
(635,'美发工具',74,3,1,0,NULL,NULL,0),
(636,'脸部护理',74,3,1,0,NULL,NULL,0),
(637,'香水',75,3,1,0,NULL,NULL,0),
(638,'底妆',75,3,1,0,NULL,NULL,0),
(639,'腮红',75,3,1,0,NULL,NULL,0),
(640,'眼影',75,3,1,0,NULL,NULL,0),
(641,'唇部',75,3,1,0,NULL,NULL,0),
(642,'美甲',75,3,1,0,NULL,NULL,0),
(643,'眼线',75,3,1,0,NULL,NULL,0),
(644,'美妆工具',75,3,1,0,NULL,NULL,0),
(645,'套装',75,3,1,0,NULL,NULL,0),
(646,'防晒隔离',75,3,1,0,NULL,NULL,0),
(647,'卸妆',75,3,1,0,NULL,NULL,0),
(648,'眉笔',75,3,1,0,NULL,NULL,0),
(649,'睫毛膏',75,3,1,0,NULL,NULL,0),
(650,'T恤',76,3,1,0,NULL,NULL,0),
(651,'衬衫',76,3,1,0,NULL,NULL,0),
(652,'针织衫',76,3,1,0,NULL,NULL,0),
(653,'雪纺衫',76,3,1,0,NULL,NULL,0),
(654,'卫衣',76,3,1,0,NULL,NULL,0),
(655,'马甲',76,3,1,0,NULL,NULL,0),
(656,'连衣裙',76,3,1,0,NULL,NULL,0),
(657,'半身裙',76,3,1,0,NULL,NULL,0),
(658,'牛仔裤',76,3,1,0,NULL,NULL,0),
(659,'休闲裤',76,3,1,0,NULL,NULL,0),
(660,'打底裤',76,3,1,0,NULL,NULL,0),
(661,'正装裤',76,3,1,0,NULL,NULL,0),
(662,'小西装',76,3,1,0,NULL,NULL,0),
(663,'短外套',76,3,1,0,NULL,NULL,0),
(664,'风衣',76,3,1,0,NULL,NULL,0),
(665,'毛呢大衣',76,3,1,0,NULL,NULL,0),
(666,'真皮皮衣',76,3,1,0,NULL,NULL,0),
(667,'棉服',76,3,1,0,NULL,NULL,0),
(668,'羽绒服',76,3,1,0,NULL,NULL,0),
(669,'大码女装',76,3,1,0,NULL,NULL,0),
(670,'中老年女装',76,3,1,0,NULL,NULL,0),
(671,'婚纱',76,3,1,0,NULL,NULL,0),
(672,'打底衫',76,3,1,0,NULL,NULL,0),
(673,'旗袍/唐装',76,3,1,0,NULL,NULL,0),
(674,'加绒裤',76,3,1,0,NULL,NULL,0),
(675,'吊带/背心',76,3,1,0,NULL,NULL,0),
(676,'羊绒衫',76,3,1,0,NULL,NULL,0),
(677,'短裤',76,3,1,0,NULL,NULL,0),
(678,'皮草',76,3,1,0,NULL,NULL,0),
(679,'礼服',76,3,1,0,NULL,NULL,0),
(680,'仿皮皮衣',76,3,1,0,NULL,NULL,0),
(681,'羊毛衫',76,3,1,0,NULL,NULL,0),
(682,'设计师/潮牌',76,3,1,0,NULL,NULL,0),
(683,'衬衫',77,3,1,0,NULL,NULL,0),
(684,'T恤',77,3,1,0,NULL,NULL,0),
(685,'POLO衫',77,3,1,0,NULL,NULL,0),
(686,'针织衫',77,3,1,0,NULL,NULL,0),
(687,'羊绒衫',77,3,1,0,NULL,NULL,0),
(688,'卫衣',77,3,1,0,NULL,NULL,0),
(689,'马甲/背心',77,3,1,0,NULL,NULL,0),
(690,'夹克',77,3,1,0,NULL,NULL,0),
(691,'风衣',77,3,1,0,NULL,NULL,0),
(692,'毛呢大衣',77,3,1,0,NULL,NULL,0),
(693,'仿皮皮衣',77,3,1,0,NULL,NULL,0),
(694,'西服',77,3,1,0,NULL,NULL,0),
(695,'棉服',77,3,1,0,NULL,NULL,0),
(696,'羽绒服',77,3,1,0,NULL,NULL,0),
(697,'牛仔裤',77,3,1,0,NULL,NULL,0),
(698,'休闲裤',77,3,1,0,NULL,NULL,0),
(699,'西裤',77,3,1,0,NULL,NULL,0),
(700,'西服套装',77,3,1,0,NULL,NULL,0),
(701,'大码男装',77,3,1,0,NULL,NULL,0),
(702,'中老年男装',77,3,1,0,NULL,NULL,0),
(703,'唐装/中山装',77,3,1,0,NULL,NULL,0),
(704,'工装',77,3,1,0,NULL,NULL,0),
(705,'真皮皮衣',77,3,1,0,NULL,NULL,0),
(706,'加绒裤',77,3,1,0,NULL,NULL,0),
(707,'卫裤/运动裤',77,3,1,0,NULL,NULL,0),
(708,'短裤',77,3,1,0,NULL,NULL,0),
(709,'设计师/潮牌',77,3,1,0,NULL,NULL,0),
(710,'羊毛衫',77,3,1,0,NULL,NULL,0),
(711,'文胸',78,3,1,0,NULL,NULL,0),
(712,'女式内裤',78,3,1,0,NULL,NULL,0),
(713,'男式内裤',78,3,1,0,NULL,NULL,0),
(714,'睡衣/家居服',78,3,1,0,NULL,NULL,0),
(715,'塑身美体',78,3,1,0,NULL,NULL,0),
(716,'泳衣',78,3,1,0,NULL,NULL,0),
(717,'吊带/背心',78,3,1,0,NULL,NULL,0),
(718,'抹胸',78,3,1,0,NULL,NULL,0),
(719,'连裤袜/丝袜',78,3,1,0,NULL,NULL,0),
(720,'美腿袜',78,3,1,0,NULL,NULL,0),
(721,'商务男袜',78,3,1,0,NULL,NULL,0),
(722,'保暖内衣',78,3,1,0,NULL,NULL,0),
(723,'情侣睡衣',78,3,1,0,NULL,NULL,0),
(724,'文胸套装',78,3,1,0,NULL,NULL,0),
(725,'少女文胸',78,3,1,0,NULL,NULL,0),
(726,'休闲棉袜',78,3,1,0,NULL,NULL,0),
(727,'大码内衣',78,3,1,0,NULL,NULL,0),
(728,'内衣配件',78,3,1,0,NULL,NULL,0),
(729,'打底裤袜',78,3,1,0,NULL,NULL,0),
(730,'打底衫',78,3,1,0,NULL,NULL,0),
(731,'秋衣秋裤',78,3,1,0,NULL,NULL,0),
(732,'情趣内衣',78,3,1,0,NULL,NULL,0),
(733,'服装洗护',79,3,1,0,NULL,NULL,0),
(734,'太阳镜',80,3,1,0,NULL,NULL,0),
(735,'光学镜架/镜片',80,3,1,0,NULL,NULL,0),
(736,'围巾/手套/帽子套装',80,3,1,0,NULL,NULL,0),
(737,'袖扣',80,3,1,0,NULL,NULL,0),
(738,'棒球帽',80,3,1,0,NULL,NULL,0),
(739,'毛线帽',80,3,1,0,NULL,NULL,0),
(740,'遮阳帽',80,3,1,0,NULL,NULL,0),
(741,'老花镜',80,3,1,0,NULL,NULL,0),
(742,'装饰眼镜',80,3,1,0,NULL,NULL,0),
(743,'防辐射眼镜',80,3,1,0,NULL,NULL,0),
(744,'游泳镜',80,3,1,0,NULL,NULL,0),
(745,'女士丝巾/围巾/披肩',80,3,1,0,NULL,NULL,0),
(746,'男士丝巾/围巾',80,3,1,0,NULL,NULL,0),
(747,'鸭舌帽',80,3,1,0,NULL,NULL,0),
(748,'贝雷帽',80,3,1,0,NULL,NULL,0),
(749,'礼帽',80,3,1,0,NULL,NULL,0),
(750,'真皮手套',80,3,1,0,NULL,NULL,0),
(751,'毛线手套',80,3,1,0,NULL,NULL,0),
(752,'防晒手套',80,3,1,0,NULL,NULL,0),
(753,'男士腰带/礼盒',80,3,1,0,NULL,NULL,0),
(754,'女士腰带/礼盒',80,3,1,0,NULL,NULL,0),
(755,'钥匙扣',80,3,1,0,NULL,NULL,0),
(756,'遮阳伞/雨伞',80,3,1,0,NULL,NULL,0),
(757,'口罩',80,3,1,0,NULL,NULL,0),
(758,'耳罩/耳包',80,3,1,0,NULL,NULL,0),
(759,'假领',80,3,1,0,NULL,NULL,0),
(760,'毛线/布面料',80,3,1,0,NULL,NULL,0),
(761,'领带/领结/领带夹',80,3,1,0,NULL,NULL,0),
(762,'男表',81,3,1,0,NULL,NULL,0),
(763,'瑞表',81,3,1,0,NULL,NULL,0),
(764,'女表',81,3,1,0,NULL,NULL,0),
(765,'国表',81,3,1,0,NULL,NULL,0),
(766,'日韩表',81,3,1,0,NULL,NULL,0),
(767,'欧美表',81,3,1,0,NULL,NULL,0),
(768,'德表',81,3,1,0,NULL,NULL,0),
(769,'儿童手表',81,3,1,0,NULL,NULL,0),
(770,'智能手表',81,3,1,0,NULL,NULL,0),
(771,'闹钟',81,3,1,0,NULL,NULL,0),
(772,'座钟挂钟',81,3,1,0,NULL,NULL,0),
(773,'钟表配件',81,3,1,0,NULL,NULL,0),
(774,'商务休闲鞋',82,3,1,0,NULL,NULL,0),
(775,'正装鞋',82,3,1,0,NULL,NULL,0),
(776,'休闲鞋',82,3,1,0,NULL,NULL,0),
(777,'凉鞋/沙滩鞋',82,3,1,0,NULL,NULL,0),
(778,'男靴',82,3,1,0,NULL,NULL,0),
(779,'功能鞋',82,3,1,0,NULL,NULL,0),
(780,'拖鞋/人字拖',82,3,1,0,NULL,NULL,0),
(781,'雨鞋/雨靴',82,3,1,0,NULL,NULL,0),
(782,'传统布鞋',82,3,1,0,NULL,NULL,0),
(783,'鞋配件',82,3,1,0,NULL,NULL,0),
(784,'帆布鞋',82,3,1,0,NULL,NULL,0),
(785,'增高鞋',82,3,1,0,NULL,NULL,0),
(786,'工装鞋',82,3,1,0,NULL,NULL,0),
(787,'定制鞋',82,3,1,0,NULL,NULL,0),
(788,'高跟鞋',83,3,1,0,NULL,NULL,0),
(789,'单鞋',83,3,1,0,NULL,NULL,0),
(790,'休闲鞋',83,3,1,0,NULL,NULL,0),
(791,'凉鞋',83,3,1,0,NULL,NULL,0),
(792,'女靴',83,3,1,0,NULL,NULL,0),
(793,'雪地靴',83,3,1,0,NULL,NULL,0),
(794,'拖鞋/人字拖',83,3,1,0,NULL,NULL,0),
(795,'踝靴',83,3,1,0,NULL,NULL,0),
(796,'筒靴',83,3,1,0,NULL,NULL,0),
(797,'帆布鞋',83,3,1,0,NULL,NULL,0),
(798,'雨鞋/雨靴',83,3,1,0,NULL,NULL,0),
(799,'妈妈鞋',83,3,1,0,NULL,NULL,0),
(800,'鞋配件',83,3,1,0,NULL,NULL,0),
(801,'特色鞋',83,3,1,0,NULL,NULL,0),
(802,'鱼嘴鞋',83,3,1,0,NULL,NULL,0),
(803,'布鞋/绣花鞋',83,3,1,0,NULL,NULL,0),
(804,'马丁靴',83,3,1,0,NULL,NULL,0),
(805,'坡跟鞋',83,3,1,0,NULL,NULL,0),
(806,'松糕鞋',83,3,1,0,NULL,NULL,0),
(807,'内增高',83,3,1,0,NULL,NULL,0),
(808,'防水台',83,3,1,0,NULL,NULL,0),
(809,'婴幼奶粉',84,3,1,0,NULL,NULL,0),
(810,'孕妈奶粉',84,3,1,0,NULL,NULL,0),
(811,'益生菌/初乳',85,3,1,0,NULL,NULL,0),
(812,'米粉/菜粉',85,3,1,0,NULL,NULL,0),
(813,'果泥/果汁',85,3,1,0,NULL,NULL,0),
(814,'DHA',85,3,1,0,NULL,NULL,0),
(815,'宝宝零食',85,3,1,0,NULL,NULL,0),
(816,'钙铁锌/维生素',85,3,1,0,NULL,NULL,0),
(817,'清火/开胃',85,3,1,0,NULL,NULL,0),
(818,'面条/粥',85,3,1,0,NULL,NULL,0),
(819,'婴儿尿裤',86,3,1,0,NULL,NULL,0),
(820,'拉拉裤',86,3,1,0,NULL,NULL,0),
(821,'婴儿湿巾',86,3,1,0,NULL,NULL,0),
(822,'成人尿裤',86,3,1,0,NULL,NULL,0),
(823,'奶瓶奶嘴',87,3,1,0,NULL,NULL,0),
(824,'吸奶器',87,3,1,0,NULL,NULL,0),
(825,'暖奶消毒',87,3,1,0,NULL,NULL,0),
(826,'儿童餐具',87,3,1,0,NULL,NULL,0),
(827,'水壶/水杯',87,3,1,0,NULL,NULL,0),
(828,'牙胶安抚',87,3,1,0,NULL,NULL,0),
(829,'围兜/防溅衣',87,3,1,0,NULL,NULL,0),
(830,'辅食料理机',87,3,1,0,NULL,NULL,0),
(831,'食物存储',87,3,1,0,NULL,NULL,0),
(832,'宝宝护肤',88,3,1,0,NULL,NULL,0),
(833,'洗发沐浴',88,3,1,0,NULL,NULL,0),
(834,'奶瓶清洗',88,3,1,0,NULL,NULL,0),
(835,'驱蚊防晒',88,3,1,0,NULL,NULL,0),
(836,'理发器',88,3,1,0,NULL,NULL,0),
(837,'洗澡用具',88,3,1,0,NULL,NULL,0),
(838,'婴儿口腔清洁',88,3,1,0,NULL,NULL,0),
(839,'洗衣液/皂',88,3,1,0,NULL,NULL,0),
(840,'日常护理',88,3,1,0,NULL,NULL,0),
(841,'座便器',88,3,1,0,NULL,NULL,0),
(842,'婴儿推车',89,3,1,0,NULL,NULL,0),
(843,'餐椅摇椅',89,3,1,0,NULL,NULL,0),
(844,'婴儿床',89,3,1,0,NULL,NULL,0),
(845,'学步车',89,3,1,0,NULL,NULL,0),
(846,'三轮车',89,3,1,0,NULL,NULL,0),
(847,'自行车',89,3,1,0,NULL,NULL,0),
(848,'电动车',89,3,1,0,NULL,NULL,0),
(849,'扭扭车',89,3,1,0,NULL,NULL,0),
(850,'滑板车',89,3,1,0,NULL,NULL,0),
(851,'婴儿床垫',89,3,1,0,NULL,NULL,0),
(852,'婴儿外出服',90,3,1,0,NULL,NULL,0),
(853,'婴儿内衣',90,3,1,0,NULL,NULL,0),
(854,'婴儿礼盒',90,3,1,0,NULL,NULL,0),
(855,'婴儿鞋帽袜',90,3,1,0,NULL,NULL,0),
(856,'安全防护',90,3,1,0,NULL,NULL,0),
(857,'家居床品',90,3,1,0,NULL,NULL,0),
(858,'睡袋/抱被',90,3,1,0,NULL,NULL,0),
(859,'爬行垫',90,3,1,0,NULL,NULL,0),
(860,'妈咪包/背婴带',91,3,1,0,NULL,NULL,0),
(861,'产后塑身',91,3,1,0,NULL,NULL,0),
(862,'文胸/内裤',91,3,1,0,NULL,NULL,0),
(863,'防辐射服',91,3,1,0,NULL,NULL,0),
(864,'孕妈装',91,3,1,0,NULL,NULL,0),
(865,'孕期营养',91,3,1,0,NULL,NULL,0),
(866,'孕妇护肤',91,3,1,0,NULL,NULL,0),
(867,'待产护理',91,3,1,0,NULL,NULL,0),
(868,'月子装',91,3,1,0,NULL,NULL,0),
(869,'防溢乳垫',91,3,1,0,NULL,NULL,0),
(870,'套装',92,3,1,0,NULL,NULL,0),
(871,'上衣',92,3,1,0,NULL,NULL,0),
(872,'裤子',92,3,1,0,NULL,NULL,0),
(873,'裙子',92,3,1,0,NULL,NULL,0),
(874,'内衣/家居服',92,3,1,0,NULL,NULL,0),
(875,'羽绒服/棉服',92,3,1,0,NULL,NULL,0),
(876,'亲子装',92,3,1,0,NULL,NULL,0),
(877,'儿童配饰',92,3,1,0,NULL,NULL,0),
(878,'礼服/演出服',92,3,1,0,NULL,NULL,0),
(879,'运动鞋',92,3,1,0,NULL,NULL,0),
(880,'皮鞋/帆布鞋',92,3,1,0,NULL,NULL,0),
(881,'靴子',92,3,1,0,NULL,NULL,0),
(882,'凉鞋',92,3,1,0,NULL,NULL,0),
(883,'功能鞋',92,3,1,0,NULL,NULL,0),
(884,'户外/运动服',92,3,1,0,NULL,NULL,0),
(885,'提篮式',93,3,1,0,NULL,NULL,0),
(886,'安全座椅',93,3,1,0,NULL,NULL,0),
(887,'增高垫',93,3,1,0,NULL,NULL,0),
(888,'钱包',94,3,1,0,NULL,NULL,0),
(889,'手拿包',94,3,1,0,NULL,NULL,0),
(890,'单肩包',94,3,1,0,NULL,NULL,0),
(891,'双肩包',94,3,1,0,NULL,NULL,0),
(892,'手提包',94,3,1,0,NULL,NULL,0),
(893,'斜挎包',94,3,1,0,NULL,NULL,0),
(894,'钥匙包',94,3,1,0,NULL,NULL,0),
(895,'卡包/零钱包',94,3,1,0,NULL,NULL,0),
(896,'男士钱包',95,3,1,0,NULL,NULL,0),
(897,'男士手包',95,3,1,0,NULL,NULL,0),
(898,'卡包名片夹',95,3,1,0,NULL,NULL,0),
(899,'商务公文包',95,3,1,0,NULL,NULL,0),
(900,'双肩包',95,3,1,0,NULL,NULL,0),
(901,'单肩/斜挎包',95,3,1,0,NULL,NULL,0),
(902,'钥匙包',95,3,1,0,NULL,NULL,0),
(903,'电脑包',96,3,1,0,NULL,NULL,0),
(904,'拉杆箱',96,3,1,0,NULL,NULL,0),
(905,'旅行包',96,3,1,0,NULL,NULL,0),
(906,'旅行配件',96,3,1,0,NULL,NULL,0),
(907,'休闲运动包',96,3,1,0,NULL,NULL,0),
(908,'拉杆包',96,3,1,0,NULL,NULL,0),
(909,'登山包',96,3,1,0,NULL,NULL,0),
(910,'妈咪包',96,3,1,0,NULL,NULL,0),
(911,'书包',96,3,1,0,NULL,NULL,0),
(912,'相机包',96,3,1,0,NULL,NULL,0),
(913,'腰包/胸包',96,3,1,0,NULL,NULL,0),
(914,'火机烟具',97,3,1,0,NULL,NULL,0),
(915,'礼品文具',97,3,1,0,NULL,NULL,0),
(916,'军刀军具',97,3,1,0,NULL,NULL,0),
(917,'收藏品',97,3,1,0,NULL,NULL,0),
(918,'工艺礼品',97,3,1,0,NULL,NULL,0),
(919,'创意礼品',97,3,1,0,NULL,NULL,0),
(920,'礼盒礼券',97,3,1,0,NULL,NULL,0),
(921,'鲜花绿植',97,3,1,0,NULL,NULL,0),
(922,'婚庆节庆',97,3,1,0,NULL,NULL,0),
(923,'京东卡',97,3,1,0,NULL,NULL,0),
(924,'美妆礼品',97,3,1,0,NULL,NULL,0),
(925,'礼品定制',97,3,1,0,NULL,NULL,0),
(926,'京东福卡',97,3,1,0,NULL,NULL,0),
(927,'古董文玩',97,3,1,0,NULL,NULL,0),
(928,'箱包',98,3,1,0,NULL,NULL,0),
(929,'钱包',98,3,1,0,NULL,NULL,0),
(930,'服饰',98,3,1,0,NULL,NULL,0),
(931,'腰带',98,3,1,0,NULL,NULL,0),
(932,'太阳镜/眼镜框',98,3,1,0,NULL,NULL,0),
(933,'配件',98,3,1,0,NULL,NULL,0),
(934,'鞋靴',98,3,1,0,NULL,NULL,0),
(935,'饰品',98,3,1,0,NULL,NULL,0),
(936,'名品腕表',98,3,1,0,NULL,NULL,0),
(937,'高档化妆品',98,3,1,0,NULL,NULL,0),
(938,'婚嫁首饰',99,3,1,0,NULL,NULL,0),
(939,'婚纱摄影',99,3,1,0,NULL,NULL,0),
(940,'婚纱礼服',99,3,1,0,NULL,NULL,0),
(941,'婚庆服务',99,3,1,0,NULL,NULL,0),
(942,'婚庆礼品/用品',99,3,1,0,NULL,NULL,0),
(943,'婚宴',99,3,1,0,NULL,NULL,0),
(944,'饼干蛋糕',100,3,1,0,NULL,NULL,0),
(945,'糖果/巧克力',100,3,1,0,NULL,NULL,0),
(946,'休闲零食',100,3,1,0,NULL,NULL,0),
(947,'冲调饮品',100,3,1,0,NULL,NULL,0),
(948,'粮油调味',100,3,1,0,NULL,NULL,0),
(949,'牛奶',100,3,1,0,NULL,NULL,0),
(950,'其他特产',101,3,1,0,NULL,NULL,0),
(951,'新疆',101,3,1,0,NULL,NULL,0),
(952,'北京',101,3,1,0,NULL,NULL,0),
(953,'山西',101,3,1,0,NULL,NULL,0),
(954,'内蒙古',101,3,1,0,NULL,NULL,0),
(955,'福建',101,3,1,0,NULL,NULL,0),
(956,'湖南',101,3,1,0,NULL,NULL,0),
(957,'四川',101,3,1,0,NULL,NULL,0),
(958,'云南',101,3,1,0,NULL,NULL,0),
(959,'东北',101,3,1,0,NULL,NULL,0),
(960,'休闲零食',102,3,1,0,NULL,NULL,0),
(961,'坚果炒货',102,3,1,0,NULL,NULL,0),
(962,'肉干肉脯',102,3,1,0,NULL,NULL,0),
(963,'蜜饯果干',102,3,1,0,NULL,NULL,0),
(964,'糖果/巧克力',102,3,1,0,NULL,NULL,0),
(965,'饼干蛋糕',102,3,1,0,NULL,NULL,0),
(966,'无糖食品',102,3,1,0,NULL,NULL,0),
(967,'米面杂粮',103,3,1,0,NULL,NULL,0),
(968,'食用油',103,3,1,0,NULL,NULL,0),
(969,'调味品',103,3,1,0,NULL,NULL,0),
(970,'南北干货',103,3,1,0,NULL,NULL,0),
(971,'方便食品',103,3,1,0,NULL,NULL,0),
(972,'有机食品',103,3,1,0,NULL,NULL,0),
(973,'饮用水',104,3,1,0,NULL,NULL,0),
(974,'饮料',104,3,1,0,NULL,NULL,0),
(975,'牛奶乳品',104,3,1,0,NULL,NULL,0),
(976,'咖啡/奶茶',104,3,1,0,NULL,NULL,0),
(977,'冲饮谷物',104,3,1,0,NULL,NULL,0),
(978,'蜂蜜/柚子茶',104,3,1,0,NULL,NULL,0),
(979,'成人奶粉',104,3,1,0,NULL,NULL,0),
(980,'月饼',105,3,1,0,NULL,NULL,0),
(981,'大闸蟹',105,3,1,0,NULL,NULL,0),
(982,'粽子',105,3,1,0,NULL,NULL,0),
(983,'卡券',105,3,1,0,NULL,NULL,0),
(984,'铁观音',106,3,1,0,NULL,NULL,0),
(985,'普洱',106,3,1,0,NULL,NULL,0),
(986,'龙井',106,3,1,0,NULL,NULL,0),
(987,'绿茶',106,3,1,0,NULL,NULL,0),
(988,'红茶',106,3,1,0,NULL,NULL,0),
(989,'乌龙茶',106,3,1,0,NULL,NULL,0),
(990,'花草茶',106,3,1,0,NULL,NULL,0),
(991,'花果茶',106,3,1,0,NULL,NULL,0),
(992,'养生茶',106,3,1,0,NULL,NULL,0),
(993,'黑茶',106,3,1,0,NULL,NULL,0),
(994,'白茶',106,3,1,0,NULL,NULL,0),
(995,'其它茶',106,3,1,0,NULL,NULL,0),
(996,'项链',107,3,1,0,NULL,NULL,0),
(997,'手链/脚链',107,3,1,0,NULL,NULL,0),
(998,'戒指',107,3,1,0,NULL,NULL,0),
(999,'耳饰',107,3,1,0,NULL,NULL,0),
(1000,'毛衣链',107,3,1,0,NULL,NULL,0),
(1001,'发饰/发卡',107,3,1,0,NULL,NULL,0),
(1002,'胸针',107,3,1,0,NULL,NULL,0),
(1003,'饰品配件',107,3,1,0,NULL,NULL,0),
(1004,'婚庆饰品',107,3,1,0,NULL,NULL,0),
(1005,'黄金吊坠',108,3,1,0,NULL,NULL,0),
(1006,'黄金项链',108,3,1,0,NULL,NULL,0),
(1007,'黄金转运珠',108,3,1,0,NULL,NULL,0),
(1008,'黄金手镯/手链/脚链',108,3,1,0,NULL,NULL,0),
(1009,'黄金耳饰',108,3,1,0,NULL,NULL,0),
(1010,'黄金戒指',108,3,1,0,NULL,NULL,0),
(1011,'K金吊坠',109,3,1,0,NULL,NULL,0),
(1012,'K金项链',109,3,1,0,NULL,NULL,0),
(1013,'K金手镯/手链/脚链',109,3,1,0,NULL,NULL,0),
(1014,'K金戒指',109,3,1,0,NULL,NULL,0),
(1015,'K金耳饰',109,3,1,0,NULL,NULL,0),
(1016,'投资金',110,3,1,0,NULL,NULL,0),
(1017,'投资银',110,3,1,0,NULL,NULL,0),
(1018,'投资收藏',110,3,1,0,NULL,NULL,0),
(1019,'银吊坠/项链',111,3,1,0,NULL,NULL,0),
(1020,'银手镯/手链/脚链',111,3,1,0,NULL,NULL,0),
(1021,'银戒指',111,3,1,0,NULL,NULL,0),
(1022,'银耳饰',111,3,1,0,NULL,NULL,0),
(1023,'足银手镯',111,3,1,0,NULL,NULL,0),
(1024,'宝宝银饰',111,3,1,0,NULL,NULL,0),
(1025,'裸钻',112,3,1,0,NULL,NULL,0),
(1026,'钻戒',112,3,1,0,NULL,NULL,0),
(1027,'钻石项链/吊坠',112,3,1,0,NULL,NULL,0),
(1028,'钻石耳饰',112,3,1,0,NULL,NULL,0),
(1029,'钻石手镯/手链',112,3,1,0,NULL,NULL,0),
(1030,'项链/吊坠',113,3,1,0,NULL,NULL,0),
(1031,'手镯/手串',113,3,1,0,NULL,NULL,0),
(1032,'戒指',113,3,1,0,NULL,NULL,0),
(1033,'耳饰',113,3,1,0,NULL,NULL,0),
(1034,'挂件/摆件/把件',113,3,1,0,NULL,NULL,0),
(1035,'玉石孤品',113,3,1,0,NULL,NULL,0),
(1036,'项链/吊坠',114,3,1,0,NULL,NULL,0),
(1037,'耳饰',114,3,1,0,NULL,NULL,0),
(1038,'手镯/手链/脚链',114,3,1,0,NULL,NULL,0),
(1039,'戒指',114,3,1,0,NULL,NULL,0),
(1040,'头饰/胸针',114,3,1,0,NULL,NULL,0),
(1041,'摆件/挂件',114,3,1,0,NULL,NULL,0),
(1042,'琥珀/蜜蜡',115,3,1,0,NULL,NULL,0),
(1043,'碧玺',115,3,1,0,NULL,NULL,0),
(1044,'红宝石/蓝宝石',115,3,1,0,NULL,NULL,0),
(1045,'坦桑石',115,3,1,0,NULL,NULL,0),
(1046,'珊瑚',115,3,1,0,NULL,NULL,0),
(1047,'祖母绿',115,3,1,0,NULL,NULL,0),
(1048,'葡萄石',115,3,1,0,NULL,NULL,0),
(1049,'其他天然宝石',115,3,1,0,NULL,NULL,0),
(1050,'项链/吊坠',115,3,1,0,NULL,NULL,0),
(1051,'耳饰',115,3,1,0,NULL,NULL,0),
(1052,'手镯/手链',115,3,1,0,NULL,NULL,0),
(1053,'戒指',115,3,1,0,NULL,NULL,0),
(1054,'铂金项链/吊坠',116,3,1,0,NULL,NULL,0),
(1055,'铂金手镯/手链/脚链',116,3,1,0,NULL,NULL,0),
(1056,'铂金戒指',116,3,1,0,NULL,NULL,0),
(1057,'铂金耳饰',116,3,1,0,NULL,NULL,0),
(1058,'小叶紫檀',117,3,1,0,NULL,NULL,0),
(1059,'黄花梨',117,3,1,0,NULL,NULL,0),
(1060,'沉香木',117,3,1,0,NULL,NULL,0),
(1061,'金丝楠',117,3,1,0,NULL,NULL,0),
(1062,'菩提',117,3,1,0,NULL,NULL,0),
(1063,'其他',117,3,1,0,NULL,NULL,0),
(1064,'橄榄核/核桃',117,3,1,0,NULL,NULL,0),
(1065,'檀香',117,3,1,0,NULL,NULL,0),
(1066,'珍珠项链',118,3,1,0,NULL,NULL,0),
(1067,'珍珠吊坠',118,3,1,0,NULL,NULL,0),
(1068,'珍珠耳饰',118,3,1,0,NULL,NULL,0),
(1069,'珍珠手链',118,3,1,0,NULL,NULL,0),
(1070,'珍珠戒指',118,3,1,0,NULL,NULL,0),
(1071,'珍珠胸针',118,3,1,0,NULL,NULL,0),
(1072,'机油',119,3,1,0,NULL,NULL,0),
(1073,'正时皮带',119,3,1,0,NULL,NULL,0),
(1074,'添加剂',119,3,1,0,NULL,NULL,0),
(1075,'汽车喇叭',119,3,1,0,NULL,NULL,0),
(1076,'防冻液',119,3,1,0,NULL,NULL,0),
(1077,'汽车玻璃',119,3,1,0,NULL,NULL,0),
(1078,'滤清器',119,3,1,0,NULL,NULL,0),
(1079,'火花塞',119,3,1,0,NULL,NULL,0),
(1080,'减震器',119,3,1,0,NULL,NULL,0),
(1081,'柴机油/辅助油',119,3,1,0,NULL,NULL,0),
(1082,'雨刷',119,3,1,0,NULL,NULL,0),
(1083,'车灯',119,3,1,0,NULL,NULL,0),
(1084,'后视镜',119,3,1,0,NULL,NULL,0),
(1085,'轮胎',119,3,1,0,NULL,NULL,0),
(1086,'轮毂',119,3,1,0,NULL,NULL,0),
(1087,'刹车片/盘',119,3,1,0,NULL,NULL,0),
(1088,'维修配件',119,3,1,0,NULL,NULL,0),
(1089,'蓄电池',119,3,1,0,NULL,NULL,0),
(1090,'底盘装甲/护板',119,3,1,0,NULL,NULL,0),
(1091,'贴膜',119,3,1,0,NULL,NULL,0),
(1092,'汽修工具',119,3,1,0,NULL,NULL,0),
(1093,'改装配件',119,3,1,0,NULL,NULL,0),
(1094,'导航仪',120,3,1,0,NULL,NULL,0),
(1095,'安全预警仪',120,3,1,0,NULL,NULL,0),
(1096,'行车记录仪',120,3,1,0,NULL,NULL,0),
(1097,'倒车雷达',120,3,1,0,NULL,NULL,0),
(1098,'蓝牙设备',120,3,1,0,NULL,NULL,0),
(1099,'车载影音',120,3,1,0,NULL,NULL,0),
(1100,'净化器',120,3,1,0,NULL,NULL,0),
(1101,'电源',120,3,1,0,NULL,NULL,0),
(1102,'智能驾驶',120,3,1,0,NULL,NULL,0),
(1103,'车载电台',120,3,1,0,NULL,NULL,0),
(1104,'车载电器配件',120,3,1,0,NULL,NULL,0),
(1105,'吸尘器',120,3,1,0,NULL,NULL,0),
(1106,'智能车机',120,3,1,0,NULL,NULL,0),
(1107,'冰箱',120,3,1,0,NULL,NULL,0),
(1108,'汽车音响',120,3,1,0,NULL,NULL,0),
(1109,'车载生活电器',120,3,1,0,NULL,NULL,0),
(1110,'车蜡',121,3,1,0,NULL,NULL,0),
(1111,'补漆笔',121,3,1,0,NULL,NULL,0),
(1112,'玻璃水',121,3,1,0,NULL,NULL,0),
(1113,'清洁剂',121,3,1,0,NULL,NULL,0),
(1114,'洗车工具',121,3,1,0,NULL,NULL,0),
(1115,'镀晶镀膜',121,3,1,0,NULL,NULL,0),
(1116,'打蜡机',121,3,1,0,NULL,NULL,0),
(1117,'洗车配件',121,3,1,0,NULL,NULL,0),
(1118,'洗车机',121,3,1,0,NULL,NULL,0),
(1119,'洗车水枪',121,3,1,0,NULL,NULL,0),
(1120,'毛巾掸子',121,3,1,0,NULL,NULL,0),
(1121,'脚垫',122,3,1,0,NULL,NULL,0),
(1122,'座垫',122,3,1,0,NULL,NULL,0),
(1123,'座套',122,3,1,0,NULL,NULL,0),
(1124,'后备箱垫',122,3,1,0,NULL,NULL,0),
(1125,'头枕腰靠',122,3,1,0,NULL,NULL,0),
(1126,'方向盘套',122,3,1,0,NULL,NULL,0),
(1127,'香水',122,3,1,0,NULL,NULL,0),
(1128,'空气净化',122,3,1,0,NULL,NULL,0),
(1129,'挂件摆件',122,3,1,0,NULL,NULL,0),
(1130,'功能小件',122,3,1,0,NULL,NULL,0),
(1131,'车身装饰件',122,3,1,0,NULL,NULL,0),
(1132,'车衣',122,3,1,0,NULL,NULL,0),
(1133,'安全座椅',123,3,1,0,NULL,NULL,0),
(1134,'胎压监测',123,3,1,0,NULL,NULL,0),
(1135,'防盗设备',123,3,1,0,NULL,NULL,0),
(1136,'应急救援',123,3,1,0,NULL,NULL,0),
(1137,'保温箱',123,3,1,0,NULL,NULL,0),
(1138,'地锁',123,3,1,0,NULL,NULL,0),
(1139,'摩托车',123,3,1,0,NULL,NULL,0),
(1140,'充气泵',123,3,1,0,NULL,NULL,0),
(1141,'储物箱',123,3,1,0,NULL,NULL,0),
(1142,'自驾野营',123,3,1,0,NULL,NULL,0),
(1143,'摩托车装备',123,3,1,0,NULL,NULL,0),
(1144,'清洗美容',124,3,1,0,NULL,NULL,0),
(1145,'功能升级',124,3,1,0,NULL,NULL,0),
(1146,'保养维修',124,3,1,0,NULL,NULL,0),
(1147,'油卡充值',124,3,1,0,NULL,NULL,0),
(1148,'车险',124,3,1,0,NULL,NULL,0),
(1149,'加油卡',124,3,1,0,NULL,NULL,0),
(1150,'ETC',124,3,1,0,NULL,NULL,0),
(1151,'驾驶培训',124,3,1,0,NULL,NULL,0),
(1152,'赛事服装',125,3,1,0,NULL,NULL,0),
(1153,'赛事用品',125,3,1,0,NULL,NULL,0),
(1154,'制动系统',125,3,1,0,NULL,NULL,0),
(1155,'悬挂系统',125,3,1,0,NULL,NULL,0),
(1156,'进气系统',125,3,1,0,NULL,NULL,0),
(1157,'排气系统',125,3,1,0,NULL,NULL,0),
(1158,'电子管理',125,3,1,0,NULL,NULL,0),
(1159,'车身强化',125,3,1,0,NULL,NULL,0),
(1160,'赛事座椅',125,3,1,0,NULL,NULL,0),
(1161,'跑步鞋',126,3,1,0,NULL,NULL,0),
(1162,'休闲鞋',126,3,1,0,NULL,NULL,0),
(1163,'篮球鞋',126,3,1,0,NULL,NULL,0),
(1164,'板鞋',126,3,1,0,NULL,NULL,0),
(1165,'帆布鞋',126,3,1,0,NULL,NULL,0),
(1166,'足球鞋',126,3,1,0,NULL,NULL,0),
(1167,'乒羽网鞋',126,3,1,0,NULL,NULL,0),
(1168,'专项运动鞋',126,3,1,0,NULL,NULL,0),
(1169,'训练鞋',126,3,1,0,NULL,NULL,0),
(1170,'拖鞋',126,3,1,0,NULL,NULL,0),
(1171,'运动包',126,3,1,0,NULL,NULL,0),
(1172,'羽绒服',127,3,1,0,NULL,NULL,0),
(1173,'棉服',127,3,1,0,NULL,NULL,0),
(1174,'运动裤',127,3,1,0,NULL,NULL,0),
(1175,'夹克/风衣',127,3,1,0,NULL,NULL,0),
(1176,'卫衣/套头衫',127,3,1,0,NULL,NULL,0),
(1177,'T恤',127,3,1,0,NULL,NULL,0),
(1178,'套装',127,3,1,0,NULL,NULL,0),
(1179,'乒羽网服',127,3,1,0,NULL,NULL,0),
(1180,'健身服',127,3,1,0,NULL,NULL,0),
(1181,'运动背心',127,3,1,0,NULL,NULL,0),
(1182,'毛衫/线衫',127,3,1,0,NULL,NULL,0),
(1183,'运动配饰',127,3,1,0,NULL,NULL,0),
(1184,'折叠车',128,3,1,0,NULL,NULL,0),
(1185,'山地车/公路车',128,3,1,0,NULL,NULL,0),
(1186,'电动车',128,3,1,0,NULL,NULL,0),
(1187,'其他整车',128,3,1,0,NULL,NULL,0),
(1188,'骑行服',128,3,1,0,NULL,NULL,0),
(1189,'骑行装备',128,3,1,0,NULL,NULL,0),
(1190,'平衡车',128,3,1,0,NULL,NULL,0),
(1191,'鱼竿鱼线',129,3,1,0,NULL,NULL,0),
(1192,'浮漂鱼饵',129,3,1,0,NULL,NULL,0),
(1193,'钓鱼桌椅',129,3,1,0,NULL,NULL,0),
(1194,'钓鱼配件',129,3,1,0,NULL,NULL,0),
(1195,'钓箱鱼包',129,3,1,0,NULL,NULL,0),
(1196,'其它',129,3,1,0,NULL,NULL,0),
(1197,'泳镜',130,3,1,0,NULL,NULL,0),
(1198,'泳帽',130,3,1,0,NULL,NULL,0),
(1199,'游泳包防水包',130,3,1,0,NULL,NULL,0),
(1200,'女士泳衣',130,3,1,0,NULL,NULL,0),
(1201,'男士泳衣',130,3,1,0,NULL,NULL,0),
(1202,'比基尼',130,3,1,0,NULL,NULL,0),
(1203,'其它',130,3,1,0,NULL,NULL,0),
(1204,'冲锋衣裤',131,3,1,0,NULL,NULL,0),
(1205,'速干衣裤',131,3,1,0,NULL,NULL,0),
(1206,'滑雪服',131,3,1,0,NULL,NULL,0),
(1207,'羽绒服/棉服',131,3,1,0,NULL,NULL,0),
(1208,'休闲衣裤',131,3,1,0,NULL,NULL,0),
(1209,'抓绒衣裤',131,3,1,0,NULL,NULL,0),
(1210,'软壳衣裤',131,3,1,0,NULL,NULL,0),
(1211,'T恤',131,3,1,0,NULL,NULL,0),
(1212,'户外风衣',131,3,1,0,NULL,NULL,0),
(1213,'功能内衣',131,3,1,0,NULL,NULL,0),
(1214,'军迷服饰',131,3,1,0,NULL,NULL,0),
(1215,'登山鞋',131,3,1,0,NULL,NULL,0),
(1216,'雪地靴',131,3,1,0,NULL,NULL,0),
(1217,'徒步鞋',131,3,1,0,NULL,NULL,0),
(1218,'越野跑鞋',131,3,1,0,NULL,NULL,0),
(1219,'休闲鞋',131,3,1,0,NULL,NULL,0),
(1220,'工装鞋',131,3,1,0,NULL,NULL,0),
(1221,'溯溪鞋',131,3,1,0,NULL,NULL,0),
(1222,'沙滩/凉拖',131,3,1,0,NULL,NULL,0),
(1223,'户外袜',131,3,1,0,NULL,NULL,0),
(1224,'帐篷/垫子',132,3,1,0,NULL,NULL,0),
(1225,'睡袋/吊床',132,3,1,0,NULL,NULL,0),
(1226,'登山攀岩',132,3,1,0,NULL,NULL,0),
(1227,'户外配饰',132,3,1,0,NULL,NULL,0),
(1228,'背包',132,3,1,0,NULL,NULL,0),
(1229,'户外照明',132,3,1,0,NULL,NULL,0),
(1230,'户外仪表',132,3,1,0,NULL,NULL,0),
(1231,'户外工具',132,3,1,0,NULL,NULL,0),
(1232,'望远镜',132,3,1,0,NULL,NULL,0),
(1233,'旅游用品',132,3,1,0,NULL,NULL,0),
(1234,'便携桌椅床',132,3,1,0,NULL,NULL,0),
(1235,'野餐烧烤',132,3,1,0,NULL,NULL,0),
(1236,'军迷用品',132,3,1,0,NULL,NULL,0),
(1237,'救援装备',132,3,1,0,NULL,NULL,0),
(1238,'滑雪装备',132,3,1,0,NULL,NULL,0),
(1239,'极限户外',132,3,1,0,NULL,NULL,0),
(1240,'冲浪潜水',132,3,1,0,NULL,NULL,0),
(1241,'综合训练器',133,3,1,0,NULL,NULL,0),
(1242,'其他大型器械',133,3,1,0,NULL,NULL,0),
(1243,'哑铃',133,3,1,0,NULL,NULL,0),
(1244,'仰卧板/收腹机',133,3,1,0,NULL,NULL,0),
(1245,'其他中小型器材',133,3,1,0,NULL,NULL,0),
(1246,'瑜伽舞蹈',133,3,1,0,NULL,NULL,0),
(1247,'甩脂机',133,3,1,0,NULL,NULL,0),
(1248,'踏步机',133,3,1,0,NULL,NULL,0),
(1249,'武术搏击',133,3,1,0,NULL,NULL,0),
(1250,'健身车/动感单车',133,3,1,0,NULL,NULL,0),
(1251,'跑步机',133,3,1,0,NULL,NULL,0),
(1252,'运动护具',133,3,1,0,NULL,NULL,0),
(1253,'羽毛球',134,3,1,0,NULL,NULL,0),
(1254,'乒乓球',134,3,1,0,NULL,NULL,0),
(1255,'篮球',134,3,1,0,NULL,NULL,0),
(1256,'足球',134,3,1,0,NULL,NULL,0),
(1257,'网球',134,3,1,0,NULL,NULL,0),
(1258,'排球',134,3,1,0,NULL,NULL,0),
(1259,'高尔夫',134,3,1,0,NULL,NULL,0),
(1260,'台球',134,3,1,0,NULL,NULL,0),
(1261,'棋牌麻将',134,3,1,0,NULL,NULL,0),
(1262,'轮滑滑板',134,3,1,0,NULL,NULL,0),
(1263,'其他',134,3,1,0,NULL,NULL,0),
(1264,'0-6个月',135,3,1,0,NULL,NULL,0),
(1265,'6-12个月',135,3,1,0,NULL,NULL,0),
(1266,'1-3岁',135,3,1,0,NULL,NULL,0),
(1267,'3-6岁',135,3,1,0,NULL,NULL,0),
(1268,'6-14岁',135,3,1,0,NULL,NULL,0),
(1269,'14岁以上',135,3,1,0,NULL,NULL,0),
(1270,'遥控车',136,3,1,0,NULL,NULL,0),
(1271,'遥控飞机',136,3,1,0,NULL,NULL,0),
(1272,'遥控船',136,3,1,0,NULL,NULL,0),
(1273,'机器人',136,3,1,0,NULL,NULL,0),
(1274,'轨道/助力',136,3,1,0,NULL,NULL,0),
(1275,'毛绒/布艺',137,3,1,0,NULL,NULL,0),
(1276,'靠垫/抱枕',137,3,1,0,NULL,NULL,0),
(1277,'芭比娃娃',138,3,1,0,NULL,NULL,0),
(1278,'卡通娃娃',138,3,1,0,NULL,NULL,0),
(1279,'智能娃娃',138,3,1,0,NULL,NULL,0),
(1280,'仿真模型',139,3,1,0,NULL,NULL,0),
(1281,'拼插模型',139,3,1,0,NULL,NULL,0),
(1282,'收藏爱好',139,3,1,0,NULL,NULL,0),
(1283,'炫舞毯',140,3,1,0,NULL,NULL,0),
(1284,'爬行垫/毯',140,3,1,0,NULL,NULL,0),
(1285,'户外玩具',140,3,1,0,NULL,NULL,0),
(1286,'戏水玩具',140,3,1,0,NULL,NULL,0),
(1287,'电影周边',141,3,1,0,NULL,NULL,0),
(1288,'卡通周边',141,3,1,0,NULL,NULL,0),
(1289,'网游周边',141,3,1,0,NULL,NULL,0),
(1290,'摇铃/床铃',142,3,1,0,NULL,NULL,0),
(1291,'健身架',142,3,1,0,NULL,NULL,0),
(1292,'早教启智',142,3,1,0,NULL,NULL,0),
(1293,'拖拉玩具',142,3,1,0,NULL,NULL,0),
(1294,'积木',143,3,1,0,NULL,NULL,0),
(1295,'拼图',143,3,1,0,NULL,NULL,0),
(1296,'磁力棒',143,3,1,0,NULL,NULL,0),
(1297,'立体拼插',143,3,1,0,NULL,NULL,0),
(1298,'手工彩泥',144,3,1,0,NULL,NULL,0),
(1299,'绘画工具',144,3,1,0,NULL,NULL,0),
(1300,'情景玩具',144,3,1,0,NULL,NULL,0),
(1301,'减压玩具',145,3,1,0,NULL,NULL,0),
(1302,'创意玩具',145,3,1,0,NULL,NULL,0),
(1303,'钢琴',146,3,1,0,NULL,NULL,0),
(1304,'电子琴/电钢琴',146,3,1,0,NULL,NULL,0),
(1305,'吉他/尤克里里',146,3,1,0,NULL,NULL,0),
(1306,'打击乐器',146,3,1,0,NULL,NULL,0),
(1307,'西洋管弦',146,3,1,0,NULL,NULL,0),
(1308,'民族管弦乐器',146,3,1,0,NULL,NULL,0),
(1309,'乐器配件',146,3,1,0,NULL,NULL,0),
(1310,'电脑音乐',146,3,1,0,NULL,NULL,0),
(1311,'工艺礼品乐器',146,3,1,0,NULL,NULL,0),
(1312,'口琴/口风琴/竖笛',146,3,1,0,NULL,NULL,0),
(1313,'手风琴',146,3,1,0,NULL,NULL,0),
(1314,'双色球',147,3,1,0,NULL,NULL,0),
(1315,'大乐透',147,3,1,0,NULL,NULL,0),
(1316,'福彩3D',147,3,1,0,NULL,NULL,0),
(1317,'排列三',147,3,1,0,NULL,NULL,0),
(1318,'排列五',147,3,1,0,NULL,NULL,0),
(1319,'七星彩',147,3,1,0,NULL,NULL,0),
(1320,'七乐彩',147,3,1,0,NULL,NULL,0),
(1321,'竞彩足球',147,3,1,0,NULL,NULL,0),
(1322,'竞彩篮球',147,3,1,0,NULL,NULL,0),
(1323,'新时时彩',147,3,1,0,NULL,NULL,0),
(1324,'国内机票',148,3,1,0,NULL,NULL,0),
(1325,'国内酒店',149,3,1,0,NULL,NULL,0),
(1326,'酒店团购',149,3,1,0,NULL,NULL,0),
(1327,'度假',150,3,1,0,NULL,NULL,0),
(1328,'景点',150,3,1,0,NULL,NULL,0),
(1329,'租车',150,3,1,0,NULL,NULL,0),
(1330,'火车票',150,3,1,0,NULL,NULL,0),
(1331,'旅游团购',150,3,1,0,NULL,NULL,0),
(1332,'手机充值',151,3,1,0,NULL,NULL,0),
(1333,'游戏点卡',152,3,1,0,NULL,NULL,0),
(1334,'QQ充值',152,3,1,0,NULL,NULL,0),
(1335,'电影票',153,3,1,0,NULL,NULL,0),
(1336,'演唱会',153,3,1,0,NULL,NULL,0),
(1337,'话剧歌剧',153,3,1,0,NULL,NULL,0),
(1338,'音乐会',153,3,1,0,NULL,NULL,0),
(1339,'体育赛事',153,3,1,0,NULL,NULL,0),
(1340,'舞蹈芭蕾',153,3,1,0,NULL,NULL,0),
(1341,'戏曲综艺',153,3,1,0,NULL,NULL,0),
(1342,'东北',154,3,1,0,NULL,NULL,0),
(1343,'华北',154,3,1,0,NULL,NULL,0),
(1344,'西北',154,3,1,0,NULL,NULL,0),
(1345,'华中',154,3,1,0,NULL,NULL,0),
(1346,'华东',154,3,1,0,NULL,NULL,0),
(1347,'华南',154,3,1,0,NULL,NULL,0),
(1348,'西南',154,3,1,0,NULL,NULL,0),
(1349,'苹果',155,3,1,0,NULL,NULL,0),
(1350,'橙子',155,3,1,0,NULL,NULL,0),
(1351,'奇异果/猕猴桃',155,3,1,0,NULL,NULL,0),
(1352,'车厘子/樱桃',155,3,1,0,NULL,NULL,0),
(1353,'芒果',155,3,1,0,NULL,NULL,0),
(1354,'蓝莓',155,3,1,0,NULL,NULL,0),
(1355,'火龙果',155,3,1,0,NULL,NULL,0),
(1356,'葡萄/提子',155,3,1,0,NULL,NULL,0),
(1357,'柚子',155,3,1,0,NULL,NULL,0),
(1358,'香蕉',155,3,1,0,NULL,NULL,0),
(1359,'牛油果',155,3,1,0,NULL,NULL,0),
(1360,'梨',155,3,1,0,NULL,NULL,0),
(1361,'菠萝/凤梨',155,3,1,0,NULL,NULL,0),
(1362,'桔/橘',155,3,1,0,NULL,NULL,0),
(1363,'柠檬',155,3,1,0,NULL,NULL,0),
(1364,'草莓',155,3,1,0,NULL,NULL,0),
(1365,'桃/李/杏',155,3,1,0,NULL,NULL,0),
(1366,'更多水果',155,3,1,0,NULL,NULL,0),
(1367,'水果礼盒/券',155,3,1,0,NULL,NULL,0),
(1368,'牛肉',156,3,1,0,NULL,NULL,0),
(1369,'羊肉',156,3,1,0,NULL,NULL,0),
(1370,'猪肉',156,3,1,0,NULL,NULL,0),
(1371,'内脏类',156,3,1,0,NULL,NULL,0),
(1372,'鱼类',157,3,1,0,NULL,NULL,0),
(1373,'虾类',157,3,1,0,NULL,NULL,0),
(1374,'蟹类',157,3,1,0,NULL,NULL,0),
(1375,'贝类',157,3,1,0,NULL,NULL,0),
(1376,'海参',157,3,1,0,NULL,NULL,0),
(1377,'海产干货',157,3,1,0,NULL,NULL,0),
(1378,'其他水产',157,3,1,0,NULL,NULL,0),
(1379,'海产礼盒',157,3,1,0,NULL,NULL,0),
(1380,'鸡肉',158,3,1,0,NULL,NULL,0),
(1381,'鸭肉',158,3,1,0,NULL,NULL,0),
(1382,'蛋类',158,3,1,0,NULL,NULL,0),
(1383,'其他禽类',158,3,1,0,NULL,NULL,0),
(1384,'水饺/馄饨',159,3,1,0,NULL,NULL,0),
(1385,'汤圆/元宵',159,3,1,0,NULL,NULL,0),
(1386,'面点',159,3,1,0,NULL,NULL,0),
(1387,'火锅丸串',159,3,1,0,NULL,NULL,0),
(1388,'速冻半成品',159,3,1,0,NULL,NULL,0),
(1389,'奶酪黄油',159,3,1,0,NULL,NULL,0),
(1390,'熟食',160,3,1,0,NULL,NULL,0),
(1391,'腊肠/腊肉',160,3,1,0,NULL,NULL,0),
(1392,'火腿',160,3,1,0,NULL,NULL,0),
(1393,'糕点',160,3,1,0,NULL,NULL,0),
(1394,'礼品卡券',160,3,1,0,NULL,NULL,0),
(1395,'冷藏果蔬汁',161,3,1,0,NULL,NULL,0),
(1396,'冰激凌',161,3,1,0,NULL,NULL,0),
(1397,'其他',161,3,1,0,NULL,NULL,0),
(1398,'叶菜类',162,3,1,0,NULL,NULL,0),
(1399,'茄果瓜类',162,3,1,0,NULL,NULL,0),
(1400,'根茎类',162,3,1,0,NULL,NULL,0),
(1401,'鲜菌菇',162,3,1,0,NULL,NULL,0),
(1402,'葱姜蒜椒',162,3,1,0,NULL,NULL,0),
(1403,'半加工蔬菜',162,3,1,0,NULL,NULL,0),
(1404,'微型车',163,3,1,0,NULL,NULL,0),
(1405,'小型车',163,3,1,0,NULL,NULL,0),
(1406,'紧凑型车',163,3,1,0,NULL,NULL,0),
(1407,'中型车',163,3,1,0,NULL,NULL,0),
(1408,'中大型车',163,3,1,0,NULL,NULL,0),
(1409,'豪华车',163,3,1,0,NULL,NULL,0),
(1410,'MPV',163,3,1,0,NULL,NULL,0),
(1411,'SUV',163,3,1,0,NULL,NULL,0),
(1412,'跑车',163,3,1,0,NULL,NULL,0),
(1413,'微型车（二手）',164,3,1,0,NULL,NULL,0),
(1414,'小型车（二手）',164,3,1,0,NULL,NULL,0),
(1415,'紧凑型车（二手）',164,3,1,0,NULL,NULL,0),
(1416,'中型车（二手）',164,3,1,0,NULL,NULL,0),
(1417,'中大型车（二手）',164,3,1,0,NULL,NULL,0),
(1418,'豪华车（二手）',164,3,1,0,NULL,NULL,0),
(1419,'MPV（二手）',164,3,1,0,NULL,NULL,0),
(1420,'SUV（二手）',164,3,1,0,NULL,NULL,0),
(1421,'跑车（二手）',164,3,1,0,NULL,NULL,0),
(1422,'皮卡（二手）',164,3,1,0,NULL,NULL,0),
(1423,'面包车（二手）',164,3,1,0,NULL,NULL,0),
(1431,'dsa323',1,2,0,NULL,NULL,NULL,NULL),
(1432,'fdsffdsadddd大萨达',1431,3,1,NULL,NULL,NULL,NULL),
(1433,'123a',1,2,0,0,'','',NULL),
(1437,'11',2,2,0,0,'r','r',NULL),
(1438,'12',34,3,1,0,'r','1',NULL),
(1439,'12',2,2,0,0,'R','1',NULL),
(1440,'1',1439,3,0,0,'1','t',NULL),
(1441,'1',1439,3,0,0,'r','r',NULL),
(1442,'33',35,3,1,0,'33','t',NULL),
(1443,'1',2,2,0,3,'R','1',NULL),
(1444,'12',2,2,0,2,'T1','T',NULL),
(1445,'r4',1444,3,0,0,'e','r',NULL),
(1446,'RE',2,2,1,0,'E','1',NULL),
(1447,'Q',1446,3,0,0,'1','1',NULL),
(1448,'110',2,2,1,0,'1','1',NULL),
(1449,'00',1448,3,1,0,'0','0',NULL),
(1450,'u',1446,3,1,0,'u','1',NULL);

/*Table structure for table `pms_category_brand_relation` */

DROP TABLE IF EXISTS `pms_category_brand_relation`;

CREATE TABLE `pms_category_brand_relation` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `brand_id` bigint(20) DEFAULT NULL COMMENT '品牌id',
  `catelog_id` bigint(20) DEFAULT NULL COMMENT '分类id',
  `brand_name` varchar(255) DEFAULT NULL,
  `catelog_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COMMENT='品牌分类关联';

/*Data for the table `pms_category_brand_relation` */

insert  into `pms_category_brand_relation`(`id`,`brand_id`,`catelog_id`,`brand_name`,`catelog_name`) values 
(22,6,225,'oppo','手机'),
(23,7,225,'Apple','手机'),
(24,5,225,'小米','手机'),
(25,8,225,'华为','手机'),
(30,6,1450,'oppo','u'),
(31,5,449,'小米','笔记本'),
(32,17,251,'格力','空调'),
(33,17,225,'格力','手机'),
(34,18,225,'smartisan','手机'),
(35,19,225,'三星','手机'),
(36,20,225,'努比亚 nubia','手机'),
(37,21,225,'中兴','手机'),
(38,22,225,'诺基亚','手机'),
(39,23,225,'一加','手机'),
(40,24,225,'vivo','手机'),
(41,25,225,'魅族','手机'),
(42,5,227,'小米','合约机');

/*Table structure for table `pms_comment_replay` */

DROP TABLE IF EXISTS `pms_comment_replay`;

CREATE TABLE `pms_comment_replay` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `comment_id` bigint(20) DEFAULT NULL COMMENT '评论id',
  `reply_id` bigint(20) DEFAULT NULL COMMENT '回复id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品评价回复关系';

/*Data for the table `pms_comment_replay` */

/*Table structure for table `pms_product_attr_value` */

DROP TABLE IF EXISTS `pms_product_attr_value`;

CREATE TABLE `pms_product_attr_value` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `spu_id` bigint(20) DEFAULT NULL COMMENT '商品id',
  `attr_id` bigint(20) DEFAULT NULL COMMENT '属性id',
  `attr_name` varchar(200) DEFAULT NULL COMMENT '属性名',
  `attr_value` varchar(200) DEFAULT NULL COMMENT '属性值',
  `attr_sort` int(11) DEFAULT NULL COMMENT '顺序',
  `quick_show` tinyint(4) DEFAULT NULL COMMENT '快速展示【是否展示在介绍上；0-否 1-是】',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=158 DEFAULT CHARSET=utf8mb4 COMMENT='spu属性值';

/*Data for the table `pms_product_attr_value` */

insert  into `pms_product_attr_value`(`id`,`spu_id`,`attr_id`,`attr_name`,`attr_value`,`attr_sort`,`quick_show`) values 
(82,17,9,'入网型号','A2108',NULL,1),
(83,17,10,'上市年份','2020;2019;2018',NULL,0),
(84,17,11,'机身长度（mm）','150.9',NULL,0),
(85,17,16,'机身材质分类','玻璃搭配铝金属设计',NULL,0),
(86,17,17,'CPU品牌','A13',NULL,1),
(87,17,30,'GPU型号','以官网信息为准',NULL,0),
(88,17,35,'002R','。;1;v',NULL,0),
(95,15,9,'入网型号','TAS-AN00',NULL,1),
(96,15,10,'上市年份','2020',NULL,0),
(97,15,16,'机身材质分类','玻璃后盖;蓝宝石',NULL,0),
(98,15,17,'CPU品牌','麒麟990',NULL,1),
(99,15,30,'GPU型号','Qualcomm',NULL,0),
(100,15,35,'002R','。;1;v',NULL,0),
(101,19,9,'入网型号','移动',1,1),
(102,19,10,'上市年份','2020',1,0),
(103,19,11,'机身长度（mm）','123',1,0),
(104,19,16,'机身材质分类','玻璃后盖;蓝宝石',1,0),
(105,19,17,'CPU品牌','高通(Qualcomm)',1,1),
(106,19,35,'002R','。;1;v',1,0),
(107,20,9,'入网型号','小米 10 Pro (5G)',1,1),
(108,20,10,'上市年份','2020',1,0),
(109,20,11,'机身长度（mm）','162.6',1,0),
(110,20,16,'机身材质分类','玻璃后盖',1,0),
(111,20,17,'CPU品牌','高通(Qualcomm)',1,1),
(112,20,30,'GPU型号','高通(Qualcomm)',1,0),
(113,20,35,'002R','。;1;v',1,0),
(114,22,9,'入网型号','KB2000',1,1),
(115,22,10,'上市年份','2020',1,0),
(116,22,16,'机身材质分类','以官网信息为准',1,0),
(117,22,11,'机身长度（mm）','160.7',1,0),
(118,22,16,'机身材质分类','AMOLED',1,0),
(119,22,17,'CPU品牌','高通(Qualcomm)',1,1),
(120,22,30,'GPU型号','Adreno 650',1,0),
(121,22,35,'002R','。;1;v',1,0),
(122,23,9,'入网型号','SM-G9810',1,1),
(123,23,10,'上市年份','2020',1,0),
(124,23,16,'机身材质分类','以官网信息为准',1,0),
(125,23,11,'机身长度（mm）','151.7',1,0),
(126,23,16,'机身材质分类','玻璃后盖',1,0),
(127,23,17,'CPU品牌','高通(Qualcomm)',1,1),
(128,23,30,'GPU型号','以官网信息为准',1,0),
(129,23,35,'002R','。;1;v',1,0),
(130,24,9,'入网型号','DT1901A',1,1),
(131,24,10,'上市年份','2019',1,0),
(132,24,11,'机身长度（mm）','156.66',1,0),
(133,24,16,'机身材质分类','以官网信息为准',1,0),
(134,24,17,'CPU品牌','高通(Qualcomm)',1,1),
(135,24,30,'GPU型号','以官网信息为准',1,0),
(136,24,35,'002R','。;v;1',1,0),
(137,25,9,'入网型号','V1955A',1,1),
(138,25,10,'上市年份','2020',1,0),
(139,25,16,'机身材质分类','玻璃后盖',1,0),
(140,25,11,'机身长度（mm）','158.51',1,0),
(141,25,16,'机身材质分类','玻璃后盖',1,0),
(142,25,17,'CPU品牌','高通(Qualcomm)',1,1),
(143,25,35,'002R','主机（内置电池）*1、充电器*1、数据线*1、保护壳*1、取卡针*1、快速入门指南*1、重要信息和保修卡*1',1,0),
(144,26,9,'入网型号','RM-1187',1,1),
(145,26,10,'上市年份','2017',1,0),
(146,26,16,'机身材质分类','聚碳酸酯',1,0),
(147,26,11,'机身长度（mm）','118',1,0),
(148,26,17,'CPU品牌','其他',1,1),
(149,26,30,'GPU型号','其他',1,0),
(150,26,35,'002R','Nokia 216 双卡双待*1，用户指南*1，电池*1，USB数据线*1，充电器*1，耳机*1，保修卡*1',1,0),
(151,27,9,'入网型号','PDEM10',1,1),
(152,27,10,'上市年份','2020',1,0),
(153,27,16,'机身材质分类','皮革后盖',1,0),
(154,27,11,'机身长度（mm）','164.9',1,0),
(155,27,16,'机身材质分类','皮革后盖',1,0),
(156,27,17,'CPU品牌','高通(Qualcomm)',1,1),
(157,27,35,'002R','主机 x1、耳机x1、数据线 x1、充电器 x1、SIM卡通针x1、保护套x1、快速入门指南x1、保修卡x1',1,0);

/*Table structure for table `pms_sku_images` */

DROP TABLE IF EXISTS `pms_sku_images`;

CREATE TABLE `pms_sku_images` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sku_id` bigint(20) DEFAULT NULL COMMENT 'sku_id',
  `img_url` varchar(255) DEFAULT NULL COMMENT '图片地址',
  `img_sort` int(11) DEFAULT NULL COMMENT '排序',
  `default_img` int(11) DEFAULT NULL COMMENT '默认图[0 - 不是默认图，1 - 是默认图]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=443 DEFAULT CHARSET=utf8mb4 COMMENT='sku图片';

/*Data for the table `pms_sku_images` */

insert  into `pms_sku_images`(`id`,`sku_id`,`img_url`,`img_sort`,`default_img`) values 
(364,71,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//574b07ce-60d5-4e4d-85af-c0fd8e15a33b_0d40c24b264aa511.jpg',NULL,0),
(365,71,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//b2a33c62-826b-4f9a-86bf-81a11de427cc_1f15cdbcf9e1273c.jpg',NULL,0),
(366,71,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//b405e70f-b21c-48f1-81f0-e58fd401a4ac_a83bf5250e14caf2.jpg',NULL,1),
(367,74,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//574b07ce-60d5-4e4d-85af-c0fd8e15a33b_0d40c24b264aa511.jpg',NULL,0),
(368,74,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//b2a33c62-826b-4f9a-86bf-81a11de427cc_1f15cdbcf9e1273c.jpg',NULL,0),
(369,74,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//666d3f2d-7ee6-4f3c-8ffd-6bd611c4c5e8_d511faab82abb34b.jpg',NULL,0),
(370,75,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//574b07ce-60d5-4e4d-85af-c0fd8e15a33b_0d40c24b264aa511.jpg',NULL,0),
(371,75,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//b2a33c62-826b-4f9a-86bf-81a11de427cc_1f15cdbcf9e1273c.jpg',NULL,0),
(372,75,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//666d3f2d-7ee6-4f3c-8ffd-6bd611c4c5e8_d511faab82abb34b.jpg',NULL,1),
(373,76,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//574b07ce-60d5-4e4d-85af-c0fd8e15a33b_0d40c24b264aa511.jpg',NULL,0),
(374,76,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//b2a33c62-826b-4f9a-86bf-81a11de427cc_1f15cdbcf9e1273c.jpg',NULL,0),
(375,76,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//0ab8f9c7-e439-46f6-8fd8-90b4d6223e6c_8bf441260bffa42f.jpg',NULL,0),
(376,77,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//574b07ce-60d5-4e4d-85af-c0fd8e15a33b_0d40c24b264aa511.jpg',NULL,0),
(377,77,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//b2a33c62-826b-4f9a-86bf-81a11de427cc_1f15cdbcf9e1273c.jpg',NULL,0),
(378,77,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//ee76d365-06ca-4763-8ae3-f3939ca003fe_u=993186112,884576820&fm=179&app=42&f=JPEG.jpg',NULL,1),
(379,79,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//e1552b93-98bc-47e6-8623-26f93a30cc4f_23cd65077f12f7f5.jpg',NULL,0),
(380,79,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//1d5499bd-c422-45ea-8c3d-2b1a42fb2196_749d8efdff062fb0.jpg',NULL,1),
(381,80,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//e1552b93-98bc-47e6-8623-26f93a30cc4f_23cd65077f12f7f5.jpg',NULL,0),
(382,80,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//1d5499bd-c422-45ea-8c3d-2b1a42fb2196_749d8efdff062fb0.jpg',NULL,1),
(383,81,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//11ca19cf-b4e1-4352-8eef-cef3ff1e649f_7ae0120ec27dc3a7.jpg',NULL,0),
(384,81,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//a79942cb-ea1e-4baa-8775-6e0b01db62e7_a2c208410ae84d1f.jpg',NULL,1),
(385,83,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//0eb96f46-8fa3-4bec-803a-638a7b5d9643_u=2982524444,3110984391&fm=26&gp=0.jpg',NULL,1),
(386,89,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//f3cceea3-a36f-45f2-89c4-b69b52fe9952_u=2489139277,1741824967&fm=179&app=42&f=JPEG.jpg',NULL,1),
(387,89,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//6ca19e92-c6fc-4e80-875b-5e6784061330_Snipaste_2020-08-30_16-58-45.jpg',NULL,0),
(388,90,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//f3cceea3-a36f-45f2-89c4-b69b52fe9952_u=2489139277,1741824967&fm=179&app=42&f=JPEG.jpg',NULL,1),
(389,90,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//6ca19e92-c6fc-4e80-875b-5e6784061330_Snipaste_2020-08-30_16-58-45.jpg',NULL,0),
(390,91,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//b955e7ab-6fd2-4ff6-8252-55042f5590a4_u=4280710308,3355701145&fm=179&app=42&f=JPEG.jpg',NULL,1),
(391,91,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//6ca19e92-c6fc-4e80-875b-5e6784061330_Snipaste_2020-08-30_16-58-45.jpg',NULL,0),
(392,92,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//b955e7ab-6fd2-4ff6-8252-55042f5590a4_u=4280710308,3355701145&fm=179&app=42&f=JPEG.jpg',NULL,1),
(393,92,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//6ca19e92-c6fc-4e80-875b-5e6784061330_Snipaste_2020-08-30_16-58-45.jpg',NULL,0),
(394,93,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//0fec8197-fe2d-4049-89f3-563dad70b64a_1-m00-0b-05-rbqgjv9wns6azncfaah-1n-vcs4377_840_840.png',NULL,1),
(395,93,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//0c8183e2-8730-4ec8-8e98-57b6958867a3_1-m00-2b-b6-rbqgkv9wnu-aqe17aatyclvidym089_840_840.png',NULL,0),
(396,94,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//0fec8197-fe2d-4049-89f3-563dad70b64a_1-m00-0b-05-rbqgjv9wns6azncfaah-1n-vcs4377_840_840.png',NULL,1),
(397,94,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//0c8183e2-8730-4ec8-8e98-57b6958867a3_1-m00-2b-b6-rbqgkv9wnu-aqe17aatyclvidym089_840_840.png',NULL,0),
(398,95,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//60110842-143b-4766-8d0e-08575cdd1a99_1-m00-2b-b6-rbqgkv9wnxaadxtdaas_aiy4tci317_840_840.png',NULL,0),
(399,95,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//827723a1-16b3-4b8e-8405-d8f3f073c3dd_1-m00-2b-b6-rbqgkv9wntwaxg0gaagf8mrumno388_840_840.png',NULL,1),
(400,97,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//139bf568-d066-45a0-8d48-1ad8f1e3820f_1a9d17f64e96e022.jpg',NULL,0),
(401,97,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//5a1fcf08-cbb8-4a9e-8987-b66567976481_2e46e10c09df65e4.jpg',NULL,1),
(402,97,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//466fd3b9-c792-4028-80a2-5ff3cab065dc_680cbaaee0c39c8c.jpg',NULL,0),
(403,98,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//2571be37-765b-42f1-8298-2e1df25abf60_82613244f27ea153.jpg',NULL,0),
(404,98,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//2571be37-765b-42f1-8298-2e1df25abf60_82613244f27ea153.jpg',NULL,0),
(405,98,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//2571be37-765b-42f1-8298-2e1df25abf60_82613244f27ea153.jpg',NULL,0),
(406,98,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//08119ecf-455b-400e-84b7-47ca8a1fd654_b0d6f6084142c1cf.jpg',NULL,0),
(407,99,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//891c11ae-d5a1-469a-86fb-aa6f94eb54f5_68dc99bcdc5b4dde.jpg',NULL,1),
(408,99,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//fe29d75c-397c-4df0-86a3-c67b37368cc0_ffcdf654200fc4a2.jpg',NULL,0),
(409,100,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//dae0dd25-e4ad-4ef1-891b-13f5c78a2ad6_6cdb8f164e6871f4.jpg',NULL,1),
(410,100,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//5a265b66-cb84-4f2e-8ee9-78a62b6e76d7_6f793c798c31bf85.jpg',NULL,0),
(411,101,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//dae0dd25-e4ad-4ef1-891b-13f5c78a2ad6_6cdb8f164e6871f4.jpg',NULL,1),
(412,101,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//5a265b66-cb84-4f2e-8ee9-78a62b6e76d7_6f793c798c31bf85.jpg',NULL,0),
(413,102,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//dae0dd25-e4ad-4ef1-891b-13f5c78a2ad6_6cdb8f164e6871f4.jpg',NULL,0),
(414,102,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//5a265b66-cb84-4f2e-8ee9-78a62b6e76d7_6f793c798c31bf85.jpg',NULL,1),
(415,103,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//47c5401d-deaa-4b45-819e-7b91d5ceb352_e341545a41fef973.jpg',NULL,0),
(416,103,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//510db6ba-e84f-4d7a-8c18-4f0151485e71_b5ba88ae97983df7.jpg',NULL,1),
(417,104,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//47c5401d-deaa-4b45-819e-7b91d5ceb352_e341545a41fef973.jpg',NULL,0),
(418,104,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//510db6ba-e84f-4d7a-8c18-4f0151485e71_b5ba88ae97983df7.jpg',NULL,1),
(419,105,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//47c5401d-deaa-4b45-819e-7b91d5ceb352_e341545a41fef973.jpg',NULL,1),
(420,105,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//510db6ba-e84f-4d7a-8c18-4f0151485e71_b5ba88ae97983df7.jpg',NULL,0),
(421,107,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//3f3d0f9c-8973-484e-8666-8ff087a05217_5815ebfcN9ded2035.jpg',NULL,1),
(422,107,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//0a344807-65a8-4abf-8195-efc1726d9f8d_581716f2Nec885759.jpg',NULL,0),
(423,108,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//3f3d0f9c-8973-484e-8666-8ff087a05217_5815ebfcN9ded2035.jpg',NULL,0),
(424,108,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//0a344807-65a8-4abf-8195-efc1726d9f8d_581716f2Nec885759.jpg',NULL,1),
(425,110,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//2bfa9fbb-4920-4f6c-8196-74d23c423ffe_58171852N7e6daa17.jpg',NULL,1),
(426,110,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//37f6e422-2f93-416c-8468-f575f36ac7a2_5815eb65Na587b7ea.jpg',NULL,0),
(427,111,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//db392e9e-d359-48c5-8c9d-f4be1ae87d1c_0a16bf98b3b4c304.jpg',NULL,1),
(428,111,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//abce9e05-3344-4b9c-8276-c317b27fe32b_c1d15cda5ef18e56.jpg',NULL,0),
(429,112,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//db392e9e-d359-48c5-8c9d-f4be1ae87d1c_0a16bf98b3b4c304.jpg',NULL,1),
(430,112,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//abce9e05-3344-4b9c-8276-c317b27fe32b_c1d15cda5ef18e56.jpg',NULL,0),
(431,113,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//d0810fdb-ad19-4d1d-8001-49263d8c4e29_a3b5f9f520d45fd1.jpg',NULL,1),
(432,113,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//4d81bdcc-598b-41b8-867f-cd324a18c49e_d8034efd5048bed4.jpg',NULL,0),
(433,114,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//d0810fdb-ad19-4d1d-8001-49263d8c4e29_a3b5f9f520d45fd1.jpg',NULL,1),
(434,114,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//4d81bdcc-598b-41b8-867f-cd324a18c49e_d8034efd5048bed4.jpg',NULL,0),
(435,115,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//ed17aa26-67f4-4ac2-8fc9-bc156e631199_57ee5fc4b688c336.jpg',NULL,0),
(436,115,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//d8819fed-8fd2-4644-8c73-73109f5e5466_db5f2b3961c23751.jpg',NULL,0),
(437,116,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//ed17aa26-67f4-4ac2-8fc9-bc156e631199_57ee5fc4b688c336.jpg',NULL,0),
(438,116,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//d8819fed-8fd2-4644-8c73-73109f5e5466_db5f2b3961c23751.jpg',NULL,0),
(439,117,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//d8819fed-8fd2-4644-8c73-73109f5e5466_db5f2b3961c23751.jpg',NULL,1),
(440,117,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//95b0daa3-2b29-44ad-8169-bc30fd7017b4_96e5c3d697eed20d.jpg',NULL,0),
(441,118,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//d8819fed-8fd2-4644-8c73-73109f5e5466_db5f2b3961c23751.jpg',NULL,1),
(442,118,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//95b0daa3-2b29-44ad-8169-bc30fd7017b4_96e5c3d697eed20d.jpg',NULL,0);

/*Table structure for table `pms_sku_info` */

DROP TABLE IF EXISTS `pms_sku_info`;

CREATE TABLE `pms_sku_info` (
  `sku_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'skuId',
  `spu_id` bigint(20) DEFAULT NULL COMMENT 'spuId',
  `sku_name` varchar(255) DEFAULT NULL COMMENT 'sku名称',
  `sku_desc` varchar(2000) DEFAULT NULL COMMENT 'sku介绍描述',
  `catalog_id` bigint(20) DEFAULT NULL COMMENT '所属分类id',
  `brand_id` bigint(20) DEFAULT NULL COMMENT '品牌id',
  `sku_default_img` varchar(255) DEFAULT NULL COMMENT '默认图片',
  `sku_title` varchar(255) DEFAULT NULL COMMENT '标题',
  `sku_subtitle` varchar(2000) DEFAULT NULL COMMENT '副标题',
  `price` decimal(18,4) DEFAULT NULL COMMENT '价格',
  `sale_count` bigint(20) DEFAULT NULL COMMENT '销量',
  PRIMARY KEY (`sku_id`)
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COMMENT='sku信息';

/*Data for the table `pms_sku_info` */

insert  into `pms_sku_info`(`sku_id`,`spu_id`,`sku_name`,`sku_desc`,`catalog_id`,`brand_id`,`sku_default_img`,`sku_title`,`sku_subtitle`,`price`,`sale_count`) values 
(71,15,'华为 HUAWEI Mate 30   翡冷翠 8+128',NULL,225,8,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//b405e70f-b21c-48f1-81f0-e58fd401a4ac_a83bf5250e14caf2.jpg','华为 HUAWEI Mate 30   翡冷翠 8+128 5G 麒麟990 4000万超感光徕卡影像双超级快充','麒麟990芯片；4000万超感光徕卡电影四摄；P40系列享限时6期白条免息》','4999.0000',NULL),
(72,15,'华为 HUAWEI Mate 30   翡冷翠 8+256',NULL,225,8,NULL,'华为 HUAWEI Mate 30   翡冷翠 8+256 5G 麒麟990 4000万超感光徕卡影像双超级快充','麒麟990芯片；4000万超感光徕卡电影四摄；P40系列享限时6期白条免息》','5999.0000',NULL),
(73,15,'华为 HUAWEI Mate 30   星河银 8+128',NULL,225,8,NULL,'华为 HUAWEI Mate 30   星河银 8+128 5G 麒麟990 4000万超感光徕卡影像双超级快充','麒麟990芯片；4000万超感光徕卡电影四摄；P40系列享限时6期白条免息》','4999.0000',NULL),
(74,15,'华为 HUAWEI Mate 30   星河银 8+256',NULL,225,8,NULL,'华为 HUAWEI Mate 30   星河银 8+256 5G 麒麟990 4000万超感光徕卡影像双超级快充','麒麟990芯片；4000万超感光徕卡电影四摄；P40系列享限时6期白条免息》','5999.0000',NULL),
(75,15,'华为 HUAWEI Mate 30  亮黑色 8+128',NULL,225,8,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//666d3f2d-7ee6-4f3c-8ffd-6bd611c4c5e8_d511faab82abb34b.jpg','华为 HUAWEI Mate 30  亮黑色 8+128 5G 麒麟990 4000万超感光徕卡影像双超级快充','麒麟990芯片；4000万超感光徕卡电影四摄；P40系列享限时6期白条免息》','4999.0000',NULL),
(76,15,'华为 HUAWEI Mate 30  亮黑色 8+256',NULL,225,8,NULL,'华为 HUAWEI Mate 30  亮黑色 8+256 5G 麒麟990 4000万超感光徕卡影像双超级快充','麒麟990芯片；4000万超感光徕卡电影四摄；P40系列享限时6期白条免息》','5999.0000',NULL),
(77,15,'华为 HUAWEI Mate 30  青山黛 8+128',NULL,225,8,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//ee76d365-06ca-4763-8ae3-f3939ca003fe_u=993186112,884576820&fm=179&app=42&f=JPEG.jpg','华为 HUAWEI Mate 30  青山黛 8+128 5G 麒麟990 4000万超感光徕卡影像双超级快充','麒麟990芯片；4000万超感光徕卡电影四摄；P40系列享限时6期白条免息》','4999.0000',NULL),
(78,15,'华为 HUAWEI Mate 30  青山黛 8+256',NULL,225,8,NULL,'华为 HUAWEI Mate 30  青山黛 8+256 5G 麒麟990 4000万超感光徕卡影像双超级快充','麒麟990芯片；4000万超感光徕卡电影四摄；P40系列享限时6期白条免息》','5999.0000',NULL),
(79,17,' Apple iPhone XR (A2108)  白色 8+256',NULL,225,7,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//1d5499bd-c422-45ea-8c3d-2b1a42fb2196_749d8efdff062fb0.jpg',' Apple iPhone XR (A2108)  白色 8+256  移动联通电信4G手机 双卡双待','嗨购秒杀节，iPhoneXR领券立减350元，iPhone11ProMax至高优惠2000元！更多优惠！','5000.0000',NULL),
(80,17,' Apple iPhone XR (A2108)  白色 6+128',NULL,225,7,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//1d5499bd-c422-45ea-8c3d-2b1a42fb2196_749d8efdff062fb0.jpg',' Apple iPhone XR (A2108)  白色 6+128  移动联通电信4G手机 双卡双待','嗨购秒杀节，iPhoneXR领券立减350元，iPhone11ProMax至高优惠2000元！更多优惠！','4000.0000',NULL),
(81,17,' Apple iPhone XR (A2108)  黑色 8+256',NULL,225,7,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//a79942cb-ea1e-4baa-8775-6e0b01db62e7_a2c208410ae84d1f.jpg',' Apple iPhone XR (A2108)  黑色 8+256  移动联通电信4G手机 双卡双待','嗨购秒杀节，iPhoneXR领券立减350元，iPhone11ProMax至高优惠2000元！更多优惠！','5000.0000',NULL),
(82,17,' Apple iPhone XR (A2108)  黑色 6+128',NULL,225,7,NULL,' Apple iPhone XR (A2108)  黑色 6+128  移动联通电信4G手机 双卡双待','嗨购秒杀节，iPhoneXR领券立减350元，iPhone11ProMax至高优惠2000元！更多优惠！','4000.0000',NULL),
(83,17,' Apple iPhone XR (A2108)  蓝色 8+256',NULL,225,7,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//0eb96f46-8fa3-4bec-803a-638a7b5d9643_u=2982524444,3110984391&fm=26&gp=0.jpg',' Apple iPhone XR (A2108)  蓝色 8+256  移动联通电信4G手机 双卡双待','嗨购秒杀节，iPhoneXR领券立减350元，iPhone11ProMax至高优惠2000元！更多优惠！','5000.0000',NULL),
(84,17,' Apple iPhone XR (A2108)  蓝色 6+128',NULL,225,7,NULL,' Apple iPhone XR (A2108)  蓝色 6+128  移动联通电信4G手机 双卡双待','嗨购秒杀节，iPhoneXR领券立减350元，iPhone11ProMax至高优惠2000元！更多优惠！','4000.0000',NULL),
(85,19,'123 蓝色 6+128',NULL,225,6,NULL,'123 蓝色 6+128','1111','1000.0000',NULL),
(86,19,'123 蓝色 8+256',NULL,225,6,NULL,'123 蓝色 8+256','111','2000.0000',NULL),
(87,19,'123 白色 6+128',NULL,225,6,NULL,'123 白色 6+128','111','1000.0000',NULL),
(88,19,'123 白色 8+256',NULL,225,6,NULL,'123 白色 8+256','11','2000.0000',NULL),
(89,20,'小米10pro  珍珠白 12G+128G',NULL,225,5,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//f3cceea3-a36f-45f2-89c4-b69b52fe9952_u=2489139277,1741824967&fm=179&app=42&f=JPEG.jpg','小米10pro  珍珠白 12G+128G 双模5G游戏手机【12期分期0首付可选】','【8+256蓝至高立减500元】赠：品牌无线充+音乐活塞耳机+一拖三数据线+手机保护膜+保护壳（自带）+10元晒单红包+运费险【小米10至尊版','5000.0000',NULL),
(90,20,'小米10pro  珍珠白 12G+256G',NULL,225,5,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//f3cceea3-a36f-45f2-89c4-b69b52fe9952_u=2489139277,1741824967&fm=179&app=42&f=JPEG.jpg','小米10pro  珍珠白 12G+256G 双模5G游戏手机【12期分期0首付可选】','【8+256蓝至高立减500元】赠：品牌无线充+音乐活塞耳机+一拖三数据线+手机保护膜+保护壳（自带）+10元晒单红包+运费险【小米10至尊版','6000.0000',NULL),
(91,20,'小米10pro  星空蓝 12G+128G',NULL,225,5,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//b955e7ab-6fd2-4ff6-8252-55042f5590a4_u=4280710308,3355701145&fm=179&app=42&f=JPEG.jpg','小米10pro  星空蓝 12G+128G 双模5G游戏手机【12期分期0首付可选】','【8+256蓝至高立减500元】赠：品牌无线充+音乐活塞耳机+一拖三数据线+手机保护膜+保护壳（自带）+10元晒单红包+运费险【小米10至尊版','5000.0000',NULL),
(92,20,'小米10pro  星空蓝 12G+256G',NULL,225,5,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//b955e7ab-6fd2-4ff6-8252-55042f5590a4_u=4280710308,3355701145&fm=179&app=42&f=JPEG.jpg','小米10pro  星空蓝 12G+256G 双模5G游戏手机【12期分期0首付可选】','【8+256蓝至高立减500元】赠：品牌无线充+音乐活塞耳机+一拖三数据线+手机保护膜+保护壳（自带）+10元晒单红包+运费险【小米10至尊版','6000.0000',NULL),
(93,22,'一加 银时 8G+128G',NULL,225,23,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//0fec8197-fe2d-4049-89f3-563dad70b64a_1-m00-0b-05-rbqgjv9wns6azncfaah-1n-vcs4377_840_840.png','一加 银时 8G+128G 5G旗舰 120Hz柔性直屏 65W闪充 高通骁龙865 超清四摄 拍照游戏手机','【旗舰新机首发,享12期免息】骁龙865,120Hz刷新率,65W闪充,火热抢购','3399.0000',NULL),
(94,22,'一加 银时 12G+256G',NULL,225,23,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//0fec8197-fe2d-4049-89f3-563dad70b64a_1-m00-0b-05-rbqgjv9wns6azncfaah-1n-vcs4377_840_840.png','一加 银时 12G+256G 5G旗舰 120Hz柔性直屏 65W闪充 高通骁龙865 超清四摄 拍照游戏手机','【旗舰新机首发,享12期免息】骁龙865,120Hz刷新率,65W闪充,火热抢购','3699.0000',NULL),
(95,22,'一加 青域 8G+128G',NULL,225,23,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//827723a1-16b3-4b8e-8405-d8f3f073c3dd_1-m00-2b-b6-rbqgkv9wntwaxg0gaagf8mrumno388_840_840.png','一加 青域 8G+128G 5G旗舰 120Hz柔性直屏 65W闪充 高通骁龙865 超清四摄 拍照游戏手机','【旗舰新机首发,享12期免息】骁龙865,120Hz刷新率,65W闪充,火热抢购','3399.0000',NULL),
(96,22,'一加 青域 12G+256G',NULL,225,23,NULL,'一加 青域 12G+256G 5G旗舰 120Hz柔性直屏 65W闪充 高通骁龙865 超清四摄 拍照游戏手机','【旗舰新机首发,享12期免息】骁龙865,120Hz刷新率,65W闪充,火热抢购','3699.0000',NULL),
(97,23,'三星 Galaxy S20 5G (SM-G9810)双模5G 骁龙865 120Hz超感屏 8K视频 游戏手机 12GB+128GB 意象白',NULL,225,19,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//5a1fcf08-cbb8-4a9e-8987-b66567976481_2e46e10c09df65e4.jpg','三星 Galaxy S20  意象白  12GB+128GB ','【直降1000元！成交价5999元！12期免息！】新品S20FE预售开启，现在参与享多重好礼！','5999.0000',NULL),
(98,23,'三星 Galaxy S20 5G (SM-G9810)双模5G 骁龙865 120Hz超感屏 8K视频 游戏手机 12GB+128GB 意象白',NULL,225,19,NULL,'三星 Galaxy S20  浮氧蓝  12GB+128GB ','【直降1000元！成交价5999元！12期免息！】新品S20FE预售开启，现在参与享多重好礼！','5999.0000',NULL),
(99,23,'三星 Galaxy S20 5G (SM-G9810)双模5G 骁龙865 120Hz超感屏 8K视频 游戏手机 12GB+128GB 意象白',NULL,225,19,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//891c11ae-d5a1-469a-86fb-aa6f94eb54f5_68dc99bcdc5b4dde.jpg','三星 Galaxy S20  遐想灰  12GB+128GB ','【直降1000元！成交价5999元！12期免息！】新品S20FE预售开启，现在参与享多重好礼！','5999.0000',NULL),
(100,24,'锤子(smartisan)  黑色 12G+256G',NULL,225,18,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//dae0dd25-e4ad-4ef1-891b-13f5c78a2ad6_6cdb8f164e6871f4.jpg','锤子(smartisan)  黑色 12G+256G','【京东快递】坚果手机，为你归来！【购机赠好礼】牙刷+三合一数据线+运动蓝牙耳机+多功能支架【购机保障】运费险+全国联保一年','3599.0000',NULL),
(101,24,'锤子(smartisan)  黑色 8G+256G',NULL,225,18,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//dae0dd25-e4ad-4ef1-891b-13f5c78a2ad6_6cdb8f164e6871f4.jpg','锤子(smartisan)  黑色 8G+256G','【京东快递】坚果手机，为你归来！【购机赠好礼】牙刷+三合一数据线+运动蓝牙耳机+多功能支架【购机保障】运费险+全国联保一年','3199.0000',NULL),
(102,24,'锤子(smartisan)  黑色 8G+128G',NULL,225,18,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//5a265b66-cb84-4f2e-8ee9-78a62b6e76d7_6f793c798c31bf85.jpg','锤子(smartisan)  黑色 8G+128G','【京东快递】坚果手机，为你归来！【购机赠好礼】牙刷+三合一数据线+运动蓝牙耳机+多功能支架【购机保障】运费险+全国联保一年','2899.0000',NULL),
(103,24,'锤子(smartisan)  绿色 12G+256G',NULL,225,18,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//510db6ba-e84f-4d7a-8c18-4f0151485e71_b5ba88ae97983df7.jpg','锤子(smartisan)  绿色 12G+256G','【京东快递】坚果手机，为你归来！【购机赠好礼】牙刷+三合一数据线+运动蓝牙耳机+多功能支架【购机保障】运费险+全国联保一年','3599.0000',NULL),
(104,24,'锤子(smartisan)  绿色 8G+256G',NULL,225,18,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//510db6ba-e84f-4d7a-8c18-4f0151485e71_b5ba88ae97983df7.jpg','锤子(smartisan)  绿色 8G+256G','【京东快递】坚果手机，为你归来！【购机赠好礼】牙刷+三合一数据线+运动蓝牙耳机+多功能支架【购机保障】运费险+全国联保一年','3199.0000',NULL),
(105,24,'锤子(smartisan)  绿色 8G+128G',NULL,225,18,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//47c5401d-deaa-4b45-819e-7b91d5ceb352_e341545a41fef973.jpg','锤子(smartisan)  绿色 8G+128G','【京东快递】坚果手机，为你归来！【购机赠好礼】牙刷+三合一数据线+运动蓝牙耳机+多功能支架【购机保障】运费险+全国联保一年','2899.0000',NULL),
(106,25,'vivo iQOO 3  流光银 6G+128G',NULL,225,24,NULL,'vivo iQOO 3  流光银 6G+128G','vivo iQOO 3 6GB+128GB 流光银 高通骁龙865 55W超快闪充 专业电竞游戏手机 双模5G全网通手机','3299.0000',NULL),
(107,26,'诺基亚 NOKIA  黑色 125M',NULL,225,22,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//3f3d0f9c-8973-484e-8666-8ff087a05217_5815ebfcN9ded2035.jpg','诺基亚 NOKIA  黑色 125M 直板按键 移动联通2G手机 双卡双待 老人老年手机 学生备用功能机 超长待机','新品225手机预售1元抵30元，移动联通电信4G全网通，大屏幕，大按键，超长待机，一年以换代修。戳一下了解更多','249.0000',NULL),
(108,26,'诺基亚 NOKIA  黑色 216M',NULL,225,22,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//0a344807-65a8-4abf-8195-efc1726d9f8d_581716f2Nec885759.jpg','诺基亚 NOKIA  黑色 216M 直板按键 移动联通2G手机 双卡双待 老人老年手机 学生备用功能机 超长待机','新品225手机预售1元抵30元，移动联通电信4G全网通，大屏幕，大按键，超长待机，一年以换代修。戳一下了解更多','269.0000',NULL),
(109,26,'诺基亚 NOKIA  蓝色 125M',NULL,225,22,NULL,'诺基亚 NOKIA  蓝色 125M 直板按键 移动联通2G手机 双卡双待 老人老年手机 学生备用功能机 超长待机','新品225手机预售1元抵30元，移动联通电信4G全网通，大屏幕，大按键，超长待机，一年以换代修。戳一下了解更多','249.0000',NULL),
(110,26,'诺基亚 NOKIA  蓝色 216M',NULL,225,22,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//2bfa9fbb-4920-4f6c-8196-74d23c423ffe_58171852N7e6daa17.jpg','诺基亚 NOKIA  蓝色 216M 直板按键 移动联通2G手机 双卡双待 老人老年手机 学生备用功能机 超长待机','新品225手机预售1元抵30元，移动联通电信4G全网通，大屏幕，大按键，超长待机，一年以换代修。戳一下了解更多','269.0000',NULL),
(111,26,'诺基亚 NOKIA  灰色 125M',NULL,225,22,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//db392e9e-d359-48c5-8c9d-f4be1ae87d1c_0a16bf98b3b4c304.jpg','诺基亚 NOKIA  灰色 125M 直板按键 移动联通2G手机 双卡双待 老人老年手机 学生备用功能机 超长待机','新品225手机预售1元抵30元，移动联通电信4G全网通，大屏幕，大按键，超长待机，一年以换代修。戳一下了解更多','249.0000',NULL),
(112,26,'诺基亚 NOKIA  灰色 216M',NULL,225,22,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//db392e9e-d359-48c5-8c9d-f4be1ae87d1c_0a16bf98b3b4c304.jpg','诺基亚 NOKIA  灰色 216M 直板按键 移动联通2G手机 双卡双待 老人老年手机 学生备用功能机 超长待机','新品225手机预售1元抵30元，移动联通电信4G全网通，大屏幕，大按键，超长待机，一年以换代修。戳一下了解更多','269.0000',NULL),
(113,27,'OPPO Find X2 茶橘 8G+256G',NULL,225,6,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//d0810fdb-ad19-4d1d-8001-49263d8c4e29_a3b5f9f520d45fd1.jpg','OPPO Find X2 茶橘 8G+256G 120Hz超感屏 3K分辨率 10亿色臻彩显示 65w闪充 双模5G手机','【10.19限时享6期免息日付低至25元】骁龙865，65w闪充【Findx2系列限时至高享6期免息】','4999.0000',NULL),
(114,27,'OPPO Find X2 茶橘 8G+128G',NULL,225,6,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//d0810fdb-ad19-4d1d-8001-49263d8c4e29_a3b5f9f520d45fd1.jpg','OPPO Find X2 茶橘 8G+128G 120Hz超感屏 3K分辨率 10亿色臻彩显示 65w闪充 双模5G手机','【10.19限时享6期免息日付低至25元】骁龙865，65w闪充【Findx2系列限时至高享6期免息】','4499.0000',NULL),
(115,27,'OPPO Find X2 碧波 8G+256G',NULL,225,6,NULL,'OPPO Find X2 碧波 8G+256G 120Hz超感屏 3K分辨率 10亿色臻彩显示 65w闪充 双模5G手机','【10.19限时享6期免息日付低至25元】骁龙865，65w闪充【Findx2系列限时至高享6期免息】','4999.0000',NULL),
(116,27,'OPPO Find X2 碧波 8G+128G',NULL,225,6,NULL,'OPPO Find X2 碧波 8G+128G 120Hz超感屏 3K分辨率 10亿色臻彩显示 65w闪充 双模5G手机','【10.19限时享6期免息日付低至25元】骁龙865，65w闪充【Findx2系列限时至高享6期免息】','4499.0000',NULL),
(117,27,'OPPO Find X2 夜海 8G+256G',NULL,225,6,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//d8819fed-8fd2-4644-8c73-73109f5e5466_db5f2b3961c23751.jpg','OPPO Find X2 夜海 8G+256G 120Hz超感屏 3K分辨率 10亿色臻彩显示 65w闪充 双模5G手机','【10.19限时享6期免息日付低至25元】骁龙865，65w闪充【Findx2系列限时至高享6期免息】','4999.0000',NULL),
(118,27,'OPPO Find X2 夜海 8G+128G',NULL,225,6,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//d8819fed-8fd2-4644-8c73-73109f5e5466_db5f2b3961c23751.jpg','OPPO Find X2 夜海 8G+128G 120Hz超感屏 3K分辨率 10亿色臻彩显示 65w闪充 双模5G手机','【10.19限时享6期	 0免息日付低至25元】骁龙865，65w闪充【Findx2系列限时至高享6期免息】','4499.0000',NULL);

/*Table structure for table `pms_sku_sale_attr_value` */

DROP TABLE IF EXISTS `pms_sku_sale_attr_value`;

CREATE TABLE `pms_sku_sale_attr_value` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sku_id` bigint(20) DEFAULT NULL COMMENT 'sku_id',
  `attr_id` bigint(20) DEFAULT NULL COMMENT 'attr_id',
  `attr_name` varchar(200) DEFAULT NULL COMMENT '销售属性名',
  `attr_value` varchar(200) DEFAULT NULL COMMENT '销售属性值',
  `attr_sort` int(11) DEFAULT NULL COMMENT '顺序',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=237 DEFAULT CHARSET=utf8mb4 COMMENT='sku销售属性&值';

/*Data for the table `pms_sku_sale_attr_value` */

insert  into `pms_sku_sale_attr_value`(`id`,`sku_id`,`attr_id`,`attr_name`,`attr_value`,`attr_sort`) values 
(141,71,18,'颜色',' 翡冷翠',NULL),
(142,71,28,'型号','8+128',NULL),
(143,72,18,'颜色',' 翡冷翠',NULL),
(144,72,28,'型号','8+256',NULL),
(145,73,18,'颜色',' 星河银',NULL),
(146,73,28,'型号','8+128',NULL),
(147,74,18,'颜色',' 星河银',NULL),
(148,74,28,'型号','8+256',NULL),
(149,75,18,'颜色','亮黑色',NULL),
(150,75,28,'型号','8+128',NULL),
(151,76,18,'颜色','亮黑色',NULL),
(152,76,28,'型号','8+256',NULL),
(153,77,18,'颜色','青山黛',NULL),
(154,77,28,'型号','8+128',NULL),
(155,78,18,'颜色','青山黛',NULL),
(156,78,28,'型号','8+256',NULL),
(157,79,18,'颜色','白色',NULL),
(158,79,28,'型号','8+256',NULL),
(159,80,18,'颜色','白色',NULL),
(160,80,28,'型号','6+128',NULL),
(161,81,18,'颜色','黑色',NULL),
(162,81,28,'型号','8+256',NULL),
(163,82,18,'颜色','黑色',NULL),
(164,82,28,'型号','6+128',NULL),
(165,83,18,'颜色','蓝色',NULL),
(166,83,28,'型号','8+256',NULL),
(167,84,18,'颜色','蓝色',NULL),
(168,84,28,'型号','6+128',NULL),
(169,85,18,'颜色','蓝色',NULL),
(170,85,28,'型号','6+128',NULL),
(171,86,18,'颜色','蓝色',NULL),
(172,86,28,'型号','8+256',NULL),
(173,87,18,'颜色','白色',NULL),
(174,87,28,'型号','6+128',NULL),
(175,88,18,'颜色','白色',NULL),
(176,88,28,'型号','8+256',NULL),
(177,89,18,'颜色','珍珠白',NULL),
(178,89,28,'型号','12G+128G',NULL),
(179,90,18,'颜色','珍珠白',NULL),
(180,90,28,'型号','12G+256G',NULL),
(181,91,18,'颜色','星空蓝',NULL),
(182,91,28,'型号','12G+128G',NULL),
(183,92,18,'颜色','星空蓝',NULL),
(184,92,28,'型号','12G+256G',NULL),
(185,93,18,'颜色','银时',NULL),
(186,93,28,'型号','8G+128G',NULL),
(187,94,18,'颜色','银时',NULL),
(188,94,28,'型号','12G+256G',NULL),
(189,95,18,'颜色','青域',NULL),
(190,95,28,'型号','8G+128G',NULL),
(191,96,18,'颜色','青域',NULL),
(192,96,28,'型号','12G+256G',NULL),
(193,97,18,'颜色','意象白',NULL),
(194,97,28,'型号',' 12GB+128GB ',NULL),
(195,98,18,'颜色','浮氧蓝',NULL),
(196,98,28,'型号',' 12GB+128GB ',NULL),
(197,99,18,'颜色','遐想灰',NULL),
(198,99,28,'型号',' 12GB+128GB ',NULL),
(199,100,18,'颜色','黑色',NULL),
(200,100,28,'型号','12G+256G',NULL),
(201,101,18,'颜色','黑色',NULL),
(202,101,28,'型号','8G+256G',NULL),
(203,102,18,'颜色','黑色',NULL),
(204,102,28,'型号','8G+128G',NULL),
(205,103,18,'颜色','绿色',NULL),
(206,103,28,'型号','12G+256G',NULL),
(207,104,18,'颜色','绿色',NULL),
(208,104,28,'型号','8G+256G',NULL),
(209,105,18,'颜色','绿色',NULL),
(210,105,28,'型号','8G+128G',NULL),
(211,106,18,'颜色','流光银',NULL),
(212,106,28,'型号','6G+128G',NULL),
(213,107,18,'颜色','黑色',NULL),
(214,107,28,'型号','125M',NULL),
(215,108,18,'颜色','黑色',NULL),
(216,108,28,'型号','216M',NULL),
(217,109,18,'颜色','蓝色',NULL),
(218,109,28,'型号','125M',NULL),
(219,110,18,'颜色','蓝色',NULL),
(220,110,28,'型号','216M',NULL),
(221,111,18,'颜色','灰色',NULL),
(222,111,28,'型号','125M',NULL),
(223,112,18,'颜色','灰色',NULL),
(224,112,28,'型号','216M',NULL),
(225,113,18,'颜色','茶橘',NULL),
(226,113,28,'型号','8G+256G',NULL),
(227,114,18,'颜色','茶橘',NULL),
(228,114,28,'型号','8G+128G',NULL),
(229,115,18,'颜色','碧波',NULL),
(230,115,28,'型号','8G+256G',NULL),
(231,116,18,'颜色','碧波',NULL),
(232,116,28,'型号','8G+128G',NULL),
(233,117,18,'颜色','夜海',NULL),
(234,117,28,'型号','8G+256G',NULL),
(235,118,18,'颜色','夜海',NULL),
(236,118,28,'型号','8G+128G',NULL);

/*Table structure for table `pms_spu_comment` */

DROP TABLE IF EXISTS `pms_spu_comment`;

CREATE TABLE `pms_spu_comment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `sku_id` bigint(20) DEFAULT NULL COMMENT 'sku_id',
  `spu_id` bigint(20) DEFAULT NULL COMMENT 'spu_id',
  `spu_name` varchar(255) DEFAULT NULL COMMENT '商品名字',
  `member_nick_name` varchar(255) DEFAULT NULL COMMENT '会员昵称',
  `star` tinyint(1) DEFAULT NULL COMMENT '星级',
  `member_ip` varchar(64) DEFAULT NULL COMMENT '会员ip',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `show_status` tinyint(1) DEFAULT NULL COMMENT '显示状态[0-不显示，1-显示]',
  `spu_attributes` varchar(255) DEFAULT NULL COMMENT '购买时属性组合',
  `likes_count` int(11) DEFAULT NULL COMMENT '点赞数',
  `reply_count` int(11) DEFAULT NULL COMMENT '回复数',
  `resources` varchar(1000) DEFAULT NULL COMMENT '评论图片/视频[json数据；[{type:文件类型,url:资源路径}]]',
  `content` text COMMENT '内容',
  `member_icon` varchar(255) DEFAULT NULL COMMENT '用户头像',
  `comment_type` tinyint(4) DEFAULT NULL COMMENT '评论类型[0 - 对商品的直接评论，1 - 对评论的回复]',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品评价';

/*Data for the table `pms_spu_comment` */

/*Table structure for table `pms_spu_images` */

DROP TABLE IF EXISTS `pms_spu_images`;

CREATE TABLE `pms_spu_images` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `spu_id` bigint(20) DEFAULT NULL COMMENT 'spu_id',
  `img_name` varchar(200) DEFAULT NULL COMMENT '图片名',
  `img_url` varchar(255) DEFAULT NULL COMMENT '图片地址',
  `img_sort` int(11) DEFAULT NULL COMMENT '顺序',
  `default_img` tinyint(4) DEFAULT NULL COMMENT '是否默认图',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=158 DEFAULT CHARSET=utf8mb4 COMMENT='spu图片';

/*Data for the table `pms_spu_images` */

insert  into `pms_spu_images`(`id`,`spu_id`,`img_name`,`img_url`,`img_sort`,`default_img`) values 
(96,15,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//574b07ce-60d5-4e4d-85af-c0fd8e15a33b_0d40c24b264aa511.jpg',NULL,1),
(97,15,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//b2a33c62-826b-4f9a-86bf-81a11de427cc_1f15cdbcf9e1273c.jpg',NULL,NULL),
(98,15,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//85a6489b-b071-4f52-8f6d-e4c0fd1e6fcf_919c850652e98031.jpg',NULL,NULL),
(99,15,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//666d3f2d-7ee6-4f3c-8ffd-6bd611c4c5e8_d511faab82abb34b.jpg',NULL,NULL),
(100,15,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//b405e70f-b21c-48f1-81f0-e58fd401a4ac_a83bf5250e14caf2.jpg',NULL,NULL),
(101,15,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//ee76d365-06ca-4763-8ae3-f3939ca003fe_u=993186112,884576820&fm=179&app=42&f=JPEG.jpg',NULL,NULL),
(102,15,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//0ab8f9c7-e439-46f6-8fd8-90b4d6223e6c_8bf441260bffa42f.jpg',NULL,NULL),
(110,17,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//22f1b280-98de-48c1-8432-bc18ebdb452a_5b5e74d0978360a1.jpg',NULL,1),
(111,17,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//e1552b93-98bc-47e6-8623-26f93a30cc4f_23cd65077f12f7f5.jpg',NULL,NULL),
(112,17,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//1d5499bd-c422-45ea-8c3d-2b1a42fb2196_749d8efdff062fb0.jpg',NULL,NULL),
(113,17,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//11ca19cf-b4e1-4352-8eef-cef3ff1e649f_7ae0120ec27dc3a7.jpg',NULL,NULL),
(114,17,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//a79942cb-ea1e-4baa-8775-6e0b01db62e7_a2c208410ae84d1f.jpg',NULL,NULL),
(115,17,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//0eb96f46-8fa3-4bec-803a-638a7b5d9643_u=2982524444,3110984391&fm=26&gp=0.jpg',NULL,NULL),
(119,19,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//f41143b8-e8d1-4b13-8e18-3e8cf65fa904_73ab4d2e818d2211.jpg',NULL,1),
(120,19,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//3b4c13e6-132c-404e-8a22-1d7753eae4de_919c850652e98031.jpg',NULL,NULL),
(121,20,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//b955e7ab-6fd2-4ff6-8252-55042f5590a4_u=4280710308,3355701145&fm=179&app=42&f=JPEG.jpg',NULL,1),
(122,20,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//f3cceea3-a36f-45f2-89c4-b69b52fe9952_u=2489139277,1741824967&fm=179&app=42&f=JPEG.jpg',NULL,NULL),
(123,20,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//6ca19e92-c6fc-4e80-875b-5e6784061330_Snipaste_2020-08-30_16-58-45.jpg',NULL,NULL),
(126,22,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//0fec8197-fe2d-4049-89f3-563dad70b64a_1-m00-0b-05-rbqgjv9wns6azncfaah-1n-vcs4377_840_840.png',NULL,1),
(127,22,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//60110842-143b-4766-8d0e-08575cdd1a99_1-m00-2b-b6-rbqgkv9wnxaadxtdaas_aiy4tci317_840_840.png',NULL,NULL),
(128,22,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//0c8183e2-8730-4ec8-8e98-57b6958867a3_1-m00-2b-b6-rbqgkv9wnu-aqe17aatyclvidym089_840_840.png',NULL,NULL),
(129,22,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//827723a1-16b3-4b8e-8405-d8f3f073c3dd_1-m00-2b-b6-rbqgkv9wntwaxg0gaagf8mrumno388_840_840.png',NULL,NULL),
(130,23,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//b11b6811-d673-4222-8044-33bd8dbe718c_00a862c06c024835.jpg',NULL,1),
(131,23,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//139bf568-d066-45a0-8d48-1ad8f1e3820f_1a9d17f64e96e022.jpg',NULL,NULL),
(132,23,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//0c8183e2-8730-4ec8-8e98-57b6958867a3_1-m00-2b-b6-rbqgkv9wnu-aqe17aatyclvidym089_840_840.png',NULL,NULL),
(133,23,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//827723a1-16b3-4b8e-8405-d8f3f073c3dd_1-m00-2b-b6-rbqgkv9wntwaxg0gaagf8mrumno388_840_840.png',NULL,NULL),
(134,23,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//2571be37-765b-42f1-8298-2e1df25abf60_82613244f27ea153.jpg',NULL,NULL),
(135,23,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//08119ecf-455b-400e-84b7-47ca8a1fd654_b0d6f6084142c1cf.jpg',NULL,NULL),
(136,23,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//5a1fcf08-cbb8-4a9e-8987-b66567976481_2e46e10c09df65e4.jpg',NULL,NULL),
(137,23,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//466fd3b9-c792-4028-80a2-5ff3cab065dc_680cbaaee0c39c8c.jpg',NULL,NULL),
(138,23,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//891c11ae-d5a1-469a-86fb-aa6f94eb54f5_68dc99bcdc5b4dde.jpg',NULL,NULL),
(139,23,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//fe29d75c-397c-4df0-86a3-c67b37368cc0_ffcdf654200fc4a2.jpg',NULL,NULL),
(140,24,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//dae0dd25-e4ad-4ef1-891b-13f5c78a2ad6_6cdb8f164e6871f4.jpg',NULL,1),
(141,24,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//5a265b66-cb84-4f2e-8ee9-78a62b6e76d7_6f793c798c31bf85.jpg',NULL,NULL),
(142,24,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//47c5401d-deaa-4b45-819e-7b91d5ceb352_e341545a41fef973.jpg',NULL,NULL),
(143,24,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//510db6ba-e84f-4d7a-8c18-4f0151485e71_b5ba88ae97983df7.jpg',NULL,NULL),
(144,25,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//4026f060-80a2-448a-8a34-8d3241858523_538f9fce05c6f743.jpg',NULL,NULL),
(145,25,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//ab5c839f-1f98-401d-8090-df449cf2ef75_af80523a346d6445.jpg',NULL,1),
(146,25,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//04a2c752-9036-4dca-80f5-00d0453fe761_b5e6b6cd985fed02.jpg',NULL,NULL),
(147,26,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//db392e9e-d359-48c5-8c9d-f4be1ae87d1c_0a16bf98b3b4c304.jpg',NULL,NULL),
(148,26,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//3f3d0f9c-8973-484e-8666-8ff087a05217_5815ebfcN9ded2035.jpg',NULL,1),
(149,26,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//0a344807-65a8-4abf-8195-efc1726d9f8d_581716f2Nec885759.jpg',NULL,NULL),
(150,26,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//2bfa9fbb-4920-4f6c-8196-74d23c423ffe_58171852N7e6daa17.jpg',NULL,NULL),
(151,26,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//37f6e422-2f93-416c-8468-f575f36ac7a2_5815eb65Na587b7ea.jpg',NULL,NULL),
(152,26,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//abce9e05-3344-4b9c-8276-c317b27fe32b_c1d15cda5ef18e56.jpg',NULL,NULL),
(153,27,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//ed17aa26-67f4-4ac2-8fc9-bc156e631199_57ee5fc4b688c336.jpg',NULL,1),
(154,27,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//d0810fdb-ad19-4d1d-8001-49263d8c4e29_a3b5f9f520d45fd1.jpg',NULL,NULL),
(155,27,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//4d81bdcc-598b-41b8-867f-cd324a18c49e_d8034efd5048bed4.jpg',NULL,NULL),
(156,27,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//d8819fed-8fd2-4644-8c73-73109f5e5466_db5f2b3961c23751.jpg',NULL,NULL),
(157,27,NULL,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//95b0daa3-2b29-44ad-8169-bc30fd7017b4_96e5c3d697eed20d.jpg',NULL,NULL);

/*Table structure for table `pms_spu_info` */

DROP TABLE IF EXISTS `pms_spu_info`;

CREATE TABLE `pms_spu_info` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '商品id',
  `spu_name` varchar(200) DEFAULT NULL COMMENT '商品名称',
  `spu_description` varchar(1000) DEFAULT NULL COMMENT '商品描述',
  `catalog_id` bigint(20) DEFAULT NULL COMMENT '所属分类id',
  `brand_id` bigint(20) DEFAULT NULL COMMENT '品牌id',
  `weight` decimal(18,4) DEFAULT NULL,
  `publish_status` tinyint(4) DEFAULT NULL COMMENT '上架状态[0 - 新建，1 - 上架，2 - 下架]',
  `create_time` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COMMENT='spu信息';

/*Data for the table `pms_spu_info` */

insert  into `pms_spu_info`(`id`,`spu_name`,`spu_description`,`catalog_id`,`brand_id`,`weight`,`publish_status`,`create_time`,`update_time`) values 
(15,'华为 HUAWEI Mate 30 ','华为 HUAWEI Mate 30 ',225,8,'0.1960',1,'2020-10-20 17:01:54','2020-10-20 17:01:54'),
(17,' Apple iPhone XR (A2108) ',' Apple iPhone XR (A2108) ',225,7,'0.1940',1,'2020-10-20 17:45:28','2020-10-20 17:45:27'),
(19,'123','123',225,6,'0.9880',0,'2020-09-14 16:20:04','2020-09-14 16:20:04'),
(20,'小米10pro ','小米10pro ',225,5,'0.2080',1,'2020-09-14 08:38:54','2020-09-14 08:38:54'),
(22,'一加','OnePlus 8T',225,23,'0.1880',0,'2020-10-19 20:19:45','2020-10-19 20:19:45'),
(23,'三星 Galaxy S20 ',' 三星 Galaxy S20  5G (SM-G9810)双模5G ',225,19,'0.1630',1,'2020-10-20 15:55:56','2020-10-20 15:55:55'),
(24,'锤子(smartisan) ','锤子(smartisan) 坚果Pro3 手机',225,18,'0.1850',0,'2020-10-19 20:47:38','2020-10-19 20:47:38'),
(25,'vivo iQOO 3 ','vivo iQOO 3 6GB+128GB 流光银 高通骁龙865 55W超快闪充 专业电竞游戏手机 双模5G全网通手机',225,24,'0.2140',0,'2020-10-19 20:54:02','2020-10-19 20:54:02'),
(26,'诺基亚 NOKIA ','诺基亚 NOKIA ',225,22,'0.2000',1,'2020-10-20 16:09:47','2020-10-20 16:09:47'),
(27,'OPPO Find X2','OPPO Find X2',225,6,'0.1890',1,'2020-10-20 12:41:11','2020-10-20 12:41:09');

/*Table structure for table `pms_spu_info_desc` */

DROP TABLE IF EXISTS `pms_spu_info_desc`;

CREATE TABLE `pms_spu_info_desc` (
  `spu_id` bigint(20) NOT NULL COMMENT '商品id',
  `decript` longtext COMMENT '商品介绍',
  PRIMARY KEY (`spu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='spu信息介绍';

/*Data for the table `pms_spu_info_desc` */

insert  into `pms_spu_info_desc`(`spu_id`,`decript`) values 
(15,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//10ccb1c4-cc58-4bfd-8960-dbdf18c8a780_b094601548ddcb1b.jpg,https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//97cc1f8f-b87b-4f39-836d-4cf1ffcefce9_528211b97272d88a.jpg'),
(17,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-06//42e5b444-327d-467b-84e6-c8c17c63ef1e_f205d9c99a2b4b01.jpg'),
(19,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//20f93003-06e0-480d-86a1-a8f5bb3a3d87_8bf441260bffa42f.jpg,https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//18e7d84a-4a5c-4d62-8bab-026dd0f367c6_23cd65077f12f7f5.jpg'),
(20,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//4437c59f-4298-44ec-8a00-5c36156c1cc9_Snipaste_2020-09-05_22-05-46.jpg,https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-09-14//d3c4c8e5-57ff-4cdb-8721-0675ef7537b4_Snipaste_2020-09-05_22-06-03.jpg'),
(22,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//884bb5f1-6734-4974-8f84-741426775367_79f2969afcfb2f92 (1).jpg'),
(23,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//14d8256f-56e9-46fc-86ee-3c8da35c0215_79f2969afcfb2f92 (1).jpg,https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//464238ae-5158-41b0-8cc2-3a09bcfe1246_Snipaste_2020-10-19_20-23-56.jpg,https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//cda7cc08-3f76-4f8d-84e6-72bfa938a85a_Snipaste_2020-10-19_20-24-18.jpg'),
(24,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//fc21d38b-2c1c-4781-810f-679aaf2f0d59_7976dacc17c90cd0.jpg,https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//f165549a-a33e-42ab-8b9c-b1cbc0f29177_Snipaste_2020-10-19_20-39-27.jpg,https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//3e2d3681-2e56-4f69-8422-5e72faed4337_Snipaste_2020-10-19_20-39-37.jpg,https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//9ed4514f-cd93-4946-808d-14f2228c1bd5_Snipaste_2020-10-19_20-39-51.jpg,https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//3a735e84-e65b-4bde-843c-68565ebbd09b_Snipaste_2020-10-19_20-40-03.jpg'),
(25,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//322d4c7f-df46-4438-8b8c-3c7a5bb51993_faf1df86d242ead1.jpg,https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//eaa3d09d-58b0-4c51-84c8-5268bcfe3a03_Snipaste_2020-10-19_20-49-38.jpg,https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//f0a25dcf-4b89-4694-8ba8-6d4079bba1e4_Snipaste_2020-10-19_20-49-46.jpg'),
(26,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//a592d55b-8203-401a-89c7-be5abeeba3d0_Snipaste_2020-10-19_20-55-49.jpg,https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//b9d87a0a-079e-404a-8f19-c26c5d6560ef_Snipaste_2020-10-19_20-55-58.jpg,https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//9eb6ca70-36fe-4586-8786-1cbdbde0007d_Snipaste_2020-10-19_20-56-07.jpg'),
(27,'https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//567215af-3f72-4246-8db5-032da3298038_Snipaste_2020-10-19_21-04-19.jpg,https://gulimall-uploadarea.oss-cn-hangzhou.aliyuncs.com/2020-10-19//3e87d29a-4dff-471d-82b1-5f23547f7985_Snipaste_2020-10-19_21-04-29.jpg');

/*Table structure for table `undo_log` */

DROP TABLE IF EXISTS `undo_log`;

CREATE TABLE `undo_log` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `branch_id` bigint(20) NOT NULL,
  `xid` varchar(100) NOT NULL,
  `context` varchar(128) NOT NULL,
  `rollback_info` longblob NOT NULL,
  `log_status` int(11) NOT NULL,
  `log_created` datetime NOT NULL,
  `log_modified` datetime NOT NULL,
  `ext` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ux_undo_log` (`xid`,`branch_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `undo_log` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
